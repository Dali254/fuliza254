<?php
// pay.php — M-Pesa STK Push + poll

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/mpesa/stk.php';

if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json');

$log = __DIR__ . '/mpesa/pay_log.txt';

$user = authUser();
if (!$user) { echo json_encode(['error'=>'Not logged in']); exit; }

$body   = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $body['action'] ?? $_GET['action'] ?? '';

// ── POLL ─────────────────────────────────────────────────────────────────────
if ($action === 'poll') {
    $payId = intval($body['pay_id'] ?? 0);
    $s = getDB()->prepare("SELECT status, mpesa_receipt FROM payments WHERE id=? AND user_id=? LIMIT 1");
    $s->execute([$payId, $user['id']]);
    echo json_encode($s->fetch() ?: ['status'=>'not_found']);
    exit;
}

// ── INITIATE ──────────────────────────────────────────────────────────────────
$siteId = intval($body['site_id'] ?? 0);
$type   = $body['type'] ?? 'download';
$rawPhone = $body['phone'] ?? $user['phone'] ?? '';
$phone  = normalizePhone($rawPhone);
$planId = intval($body['plan_id'] ?? 0);

file_put_contents($log, date('[Y-m-d H:i:s]') . " Pay request: site=$siteId type=$type phone=$phone planId=$planId\n", FILE_APPEND);

if (!$siteId) { echo json_encode(['error'=>'No site specified']); exit; }
if (strlen($phone) < 12) { echo json_encode(['error'=>'Invalid phone number: ' . $rawPhone]); exit; }

// Load site
$s = getDB()->prepare("SELECT * FROM sites WHERE id=? AND user_id=? LIMIT 1");
$s->execute([$siteId, $user['id']]);
$site = $s->fetch();
if (!$site) { echo json_encode(['error'=>'Site not found']); exit; }

// Already paid for download?
if ($site['status'] === 'paid' && $type === 'download') {
    echo json_encode(['already_paid'=>true, 'site_id'=>$siteId]);
    exit;
}

// Determine amount + plan days
$planDays = 30;
if ($type === 'hosting' && $planId) {
    $pl = getDB()->prepare("SELECT * FROM hosting_plans WHERE id=? AND is_active=1 LIMIT 1");
    $pl->execute([$planId]);
    $plan = $pl->fetch();
    if ($plan) {
        $amount   = intval($plan['price']);
        $planDays = intval($plan['duration_days']);
        file_put_contents($log, date('[Y-m-d H:i:s]') . " Plan: {$plan['name']} price=$amount days=$planDays\n", FILE_APPEND);
    } else {
        $amount = intval(getSetting('hosting_price', '299'));
        file_put_contents($log, date('[Y-m-d H:i:s]') . " Plan $planId not found, using default $amount\n", FILE_APPEND);
    }
} else {
    $amount = intval(getSetting($type === 'hosting' ? 'hosting_price' : 'download_price', '499'));
}

if ($amount < 1) { echo json_encode(['error'=>'Invalid amount: ' . $amount]); exit; }

$ref  = 'WB' . strtoupper(substr($type,0,1)) . $siteId . time();
$desc = substr($type === 'hosting' ? 'Hosting '.$planDays.'d' : 'Download', 0, 13);

// Insert pending payment — no meta column (use notes if column exists)
$db = getDB();

// Check if meta column exists, add it if not
try {
    $db->query("SELECT meta FROM payments LIMIT 1");
} catch (Exception $e) {
    // Column doesn't exist — add it
    try {
        $db->exec("ALTER TABLE payments ADD COLUMN meta TEXT DEFAULT NULL");
        file_put_contents($log, date('[Y-m-d H:i:s]') . " Added meta column to payments\n", FILE_APPEND);
    } catch (Exception $e2) {
        file_put_contents($log, date('[Y-m-d H:i:s]') . " Could not add meta column: " . $e2->getMessage() . "\n", FILE_APPEND);
    }
}

$metaJson = json_encode(['plan_id'=>$planId,'days'=>$planDays]);

try {
    $ins = $db->prepare("INSERT INTO payments (user_id, site_id, amount, phone, type, meta, status) VALUES (?,?,?,?,?,?,'pending')");
    $ins->execute([$user['id'], $siteId, $amount, $phone, $type, $metaJson]);
    $payId = $db->lastInsertId();
    file_put_contents($log, date('[Y-m-d H:i:s]') . " Payment #$payId inserted\n", FILE_APPEND);
} catch (Exception $e) {
    // meta column still missing — insert without it
    file_put_contents($log, date('[Y-m-d H:i:s]') . " Insert without meta: " . $e->getMessage() . "\n", FILE_APPEND);
    $ins = $db->prepare("INSERT INTO payments (user_id, site_id, amount, phone, type, status) VALUES (?,?,?,?,?,'pending')");
    $ins->execute([$user['id'], $siteId, $amount, $phone, $type]);
    $payId = $db->lastInsertId();
}

// ── STK Push ──────────────────────────────────────────────────────────────────
file_put_contents($log, date('[Y-m-d H:i:s]') . " Calling STK: phone=$phone amount=$amount ref=$ref\n", FILE_APPEND);

$result = mpesaStkPush($phone, $amount, $ref, $desc);

file_put_contents($log, date('[Y-m-d H:i:s]') . " STK result: " . json_encode($result) . "\n", FILE_APPEND);

if ($result['success']) {
    $db->prepare("UPDATE payments SET checkout_request_id=? WHERE id=?")
       ->execute([$result['CheckoutRequestID'], $payId]);
    echo json_encode(['success'=>true, 'pay_id'=>$payId, 'message'=>$result['message']]);
} else {
    $db->prepare("UPDATE payments SET status='failed' WHERE id=?")->execute([$payId]);
    $errMsg = $result['message'] ?? 'STK push failed';
    file_put_contents($log, date('[Y-m-d H:i:s]') . " STK FAILED: $errMsg\n", FILE_APPEND);
    echo json_encode(['error' => $errMsg]);
}