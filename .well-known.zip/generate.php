<?php
// generate.php — Generates one complete index.php with everything embedded inside
// Deploys to sites/slug/, creates MySQL DB, works immediately
require_once __DIR__ . '/config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$user = authUser();
if (!$user) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Session expired.']);
    exit;
}

$body   = json_decode(file_get_contents('php://input'), true) ?: [];
$prompt = trim($body['prompt'] ?? '');
$siteId = intval($body['site_id'] ?? 0);
$mode   = $body['mode'] ?? 'create';
$images = $body['images'] ?? [];

if (!$prompt) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No prompt provided']);
    exit;
}

$apiKey = defined('ANTHROPIC_KEY') && ANTHROPIC_KEY
    ? ANTHROPIC_KEY
    : getSetting('anthropic_api_key', '');

if (!$apiKey) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'API key not configured.']);
    exit;
}

// ── SSE ───────────────────────────────────────────────────────────────────────
while (ob_get_level()) ob_end_clean();
ob_implicit_flush(true);
if (function_exists('apache_setenv')) apache_setenv('no-gzip', '1');
@ini_set('zlib.output_compression', 'Off');
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache, no-store');
header('X-Accel-Buffering: no');
header('Connection: keep-alive');

function sse(string $e, array $d): void {
    echo "event:{$e}\ndata:" . json_encode($d) . "\n\n";
    if (ob_get_level()) ob_flush();
    flush();
}

// ── Load existing for edit ────────────────────────────────────────────────────
$existingCode = '';
if ($siteId && $mode === 'edit') {
    $s = getDB()->prepare("SELECT html_content FROM sites WHERE id=? AND user_id=? LIMIT 1");
    $s->execute([$siteId, $user['id']]);
    $row = $s->fetch();
    $existingCode = $row['html_content'] ?? '';
}

// ── Build vision content ──────────────────────────────────────────────────────
$userContent = [];
foreach (array_slice($images, 0, 2) as $img) {
    $b64 = $img['base64'] ?? '';
    $mt  = $img['type'] ?? 'image/jpeg';
    if ($b64 && in_array($mt, ['image/jpeg','image/png','image/webp','image/gif']))
        $userContent[] = ['type'=>'image','source'=>['type'=>'base64','media_type'=>$mt,'data'=>$b64]];
}

// ── System Prompt ─────────────────────────────────────────────────────────────
$systemPrompt = <<<'SYSPROMPT'
You are an expert PHP developer. You will generate ONE complete self-contained PHP file that is a fully working website.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
OUTPUT RULE — CRITICAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Output ONLY the raw PHP code. Start with <?php — nothing before it.
No markdown. No explanation. No code fences. Just pure PHP code.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ARCHITECTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ONE file: index.php — contains everything: PHP logic + HTML + CSS + JavaScript.

Structure:
<?php
// 1. PHP BACKEND — session, DB, routing, form handling
session_start();
$page = $_GET['page'] ?? 'home';

// SQLite database (no config needed)
$db = new PDO('sqlite:' . __DIR__ . '/site_data.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec('PRAGMA journal_mode=WAL');

// Create tables on first run
$db->exec("CREATE TABLE IF NOT EXISTS services (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, price TEXT, icon TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS gallery (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, image_url TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, phone TEXT, message TEXT, is_read INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS admin_users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");

// Seed sample data
$count = $db->query("SELECT COUNT(*) FROM services")->fetchColumn();
if ($count == 0) {
    // INSERT sample services, gallery, admin user here
}

// Handle POST forms
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    // ... handle contact, admin login, admin CRUD
}

// 2. HTML OUTPUT
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>/* ALL CSS embedded here */</style>
</head>
<body>
<?php // Navigation ?>
<?php if ($page === 'home'): ?>
    <!-- Hero, About, Services, Gallery, Testimonials, FAQ, CTA sections -->
<?php elseif ($page === 'about'): ?>
    <!-- About page content -->
<?php elseif ($page === 'services'): ?>
    <!-- Services from DB -->
<?php elseif ($page === 'gallery'): ?>
    <!-- Gallery from DB with lightbox -->
<?php elseif ($page === 'contact'): ?>
    <!-- Contact form -->
<?php elseif ($page === 'admin'): ?>
    <!-- Admin panel (login or dashboard) -->
<?php endif; ?>
<!-- Footer -->
<script>/* ALL JavaScript embedded here */</script>
</body>
</html>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DATABASE — USE SQLite ONLY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Use SQLite via PDO. Path: __DIR__ . '/site_data.db'
Create tables with CREATE TABLE IF NOT EXISTS at startup.
Insert sample data if table is empty (check COUNT first).
Tables needed: services, gallery, messages, testimonials, admin_users

Admin login: username=admin, password stored as password_hash('admin123', PASSWORD_DEFAULT)
Always check with password_verify() — never store plain text passwords.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PAGES (all in one file via $page variable)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
?page=home — Full landing page with:
  • Hero section: full-height, background image from Unsplash, headline, 2 CTA buttons
  • About section: 2 columns, business description + image
  • Services section: load from DB, responsive grid of cards with icon/title/desc/price
  • Stats section: 4 animated counters (clients, years, projects, satisfaction%)
  • Gallery preview: load 6 from DB, grid with lightbox
  • Testimonials: carousel/slider with 3+ reviews from DB
  • FAQ: accordion with 5+ questions relevant to the business
  • CTA section: colored background, headline, WhatsApp button

?page=about — About page: banner, story, team, values, why choose us

?page=services — All services from DB in grid layout, prices shown

?page=gallery — All gallery items from DB, masonry grid, lightbox popup on click

?page=contact — Contact form (saves to messages table), address, phone, map placeholder

?page=admin — Admin panel:
  • If not logged in: show login form (check admin_users table, password_verify)
  • If logged in: dashboard with stats, manage services (add/edit/delete), view messages, manage gallery
  • Logout link

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CSS REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ALL CSS in one <style> block in <head>
• CSS custom properties (variables) at :root level
• Choose colors that match the business type perfectly
• Professional Google Fonts (2 fonts, import via @import url())
• Fully responsive: mobile 480px, tablet 768px, desktop 1024px
• Sticky header with scroll effect (js adds 'scrolled' class)
• Mobile hamburger menu
• Smooth hover effects on cards
• CSS animations: fadeIn, slideUp
• .animate class that gets .visible added by JS (IntersectionObserver)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
JAVASCRIPT REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ALL JS in one <script> block before </body>
• Mobile menu toggle
• Sticky header on scroll
• IntersectionObserver for .animate elements
• Counter animation for stats (count up when visible)
• FAQ accordion
• Gallery lightbox (click image → full screen overlay → close on click/ESC)
• Testimonial auto-slide
• Back to top button
• Smooth scroll for anchor links

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BUSINESS-SPECIFIC CONTENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Real Unsplash images relevant to the business (use actual photo IDs)
• Real Kenyan context: KES prices, Nairobi addresses, 0700 000 000 phone format
• WhatsApp button linking to wa.me/254XXXXXXXXX
• 8-10 sample services with realistic prices
• 6-9 gallery images from Unsplash
• 3-5 testimonials with Kenyan names

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ADMIN PANEL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Simple but functional:
• Login: POST form → check admin_users table → session set → redirect
• Dashboard: count stats
• Services: list + add form + delete button
• Messages: table of contact form submissions
• Gallery: grid + add URL form + delete

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECURITY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• htmlspecialchars() on ALL user output
• PDO prepared statements for ALL queries
• Admin session check before showing admin pages
• PRG pattern for all form submissions
SYSPROMPT;

// ── Build user message ────────────────────────────────────────────────────────
if ($mode === 'edit' && $existingCode) {
    $text = "EXISTING WEBSITE CODE (current index.php):\n\n"
          . substr($existingCode, 0, 12000)
          . "\n\n---\nCHANGE REQUESTED: " . $prompt
          . "\n\nReturn the COMPLETE updated index.php with ALL changes applied.";
} else {
    $text = "BUILD A COMPLETE WEBSITE FOR:\n\n" . $prompt
          . "\n\nGenerate the complete index.php following all requirements. Make it professional and fully working.";
}
if (!empty($userContent)) $text = "Use uploaded image as design reference. " . $text;
$userContent[] = ['type' => 'text', 'text' => $text];

$messages[] = count($userContent) === 1
    ? ['role' => 'user', 'content' => $userContent[0]['text']]
    : ['role' => 'user', 'content' => $userContent];

// ── Stream from Claude ────────────────────────────────────────────────────────
sse('status', ['msg' => 'Generating your website...']);
sse('filegen', ['file' => 'index.php', 'index' => 1, 'total' => 1]);

$code   = '';
$chunks = 0;

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_RETURNTRANSFER => false,
    CURLOPT_TIMEOUT        => 180,
    CURLOPT_POSTFIELDS     => json_encode([
        'model'      => 'claude-haiku-4-5',
        'max_tokens' => 8000,
        'stream'     => true,
        'system'     => $systemPrompt,
        'messages'   => $messages,
    ]),
    CURLOPT_HTTPHEADER    => [
        'Content-Type: application/json',
        'x-api-key: ' . $apiKey,
        'anthropic-version: 2023-06-01',
    ],
    CURLOPT_WRITEFUNCTION => function($ch, $data) use (&$code, &$chunks) {
        foreach (explode("\n", $data) as $line) {
            $line = trim($line);
            if (strpos($line, 'data: ') !== 0) continue;
            $j = substr($line, 6);
            if ($j === '[DONE]') continue;
            $ev = json_decode($j, true);
            $t  = $ev['delta']['text'] ?? '';
            if (!$t) continue;
            $code .= $t;
            $chunks++;
            if ($chunks % 30 === 0) {
                sse('progress', ['chars' => strlen($code)]);
            }
        }
        return strlen($data);
    },
]);
curl_exec($ch);
$curlErr  = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($curlErr) { sse('error', ['message' => 'Connection failed: ' . $curlErr]); exit; }
if ($httpCode !== 200) {
    $e = json_decode($code, true);
    sse('error', ['message' => $e['error']['message'] ?? 'API error ' . $httpCode]);
    exit;
}

// ── Clean output ──────────────────────────────────────────────────────────────
$code = trim($code);
$code = preg_replace('/^```php\s*/i', '', $code);
$code = preg_replace('/^```\s*/m', '', $code);
$code = rtrim($code, '`');

// Must start with <?php
$pos = stripos($code, '<?php');
if ($pos === false) {
    sse('error', ['message' => 'Generated code is invalid — does not start with <?php. Try again.']);
    exit;
}
if ($pos > 0) $code = substr($code, $pos);

if (strlen($code) < 1000) {
    sse('error', ['message' => 'Response too short — generation failed. Try again.']);
    exit;
}

// Fix any DB_HOST conflicts (in case AI used them)
$code = preg_replace('/(?<!\w)DB_HOST(?!\w)/', 'SITE_DB_HOST', $code);
$code = preg_replace('/(?<!\w)DB_NAME(?!\w)/', 'SITE_DB_NAME', $code);
$code = preg_replace('/(?<!\w)DB_USER(?!\w)/', 'SITE_DB_USER', $code);
$code = preg_replace('/(?<!\w)DB_PASS(?!\w)/', 'SITE_DB_PASS', $code);

// ── Deploy to sites/slug/ ─────────────────────────────────────────────────────
sse('status', ['msg' => 'Deploying to server...']);

// Generate slug
$words = preg_split('/\s+/', strtolower(preg_replace('/[^a-z0-9\s]/i', '', $prompt)));
$stop  = ['a','an','the','and','or','for','in','on','at','to','of','with','is','website','site'];
$words = array_filter($words, fn($w) => strlen($w) > 2 && !in_array($w, $stop));
$slug  = implode('-', array_slice(array_values($words), 0, 3)) ?: 'site';

$ourDb = getDB();
foreach (['project_files LONGTEXT DEFAULT NULL', 'project_db_name VARCHAR(64) DEFAULT NULL', 'project_db_user VARCHAR(64) DEFAULT NULL'] as $col) {
    $cn = explode(' ', $col)[0];
    try { $ourDb->query("SELECT {$cn} FROM sites LIMIT 1"); }
    catch (Exception $e) { try { $ourDb->exec("ALTER TABLE sites ADD COLUMN {$col}"); } catch (Exception $e2) {} }
}

$base = $slug; $i = 1;
if ($siteId && $mode === 'edit') {
    $rs = $ourDb->prepare("SELECT slug FROM sites WHERE id=? LIMIT 1");
    $rs->execute([$siteId]);
    if ($r = $rs->fetch()) $slug = $r['slug'];
} else {
    while (true) {
        $chk = $ourDb->prepare("SELECT id FROM sites WHERE slug=? LIMIT 1");
        $chk->execute([$slug]);
        if (!$chk->fetch()) break;
        $slug = $base . '-' . (++$i);
    }
}

$siteDir = __DIR__ . '/sites/' . $slug . '/';
if (!is_dir($siteDir)) mkdir($siteDir, 0755, true);

// Write the single index.php
file_put_contents($siteDir . 'index.php', $code);

// Write .htaccess — pass ALL ?page= query strings to index.php
file_put_contents($siteDir . '.htaccess',
    "DirectoryIndex index.php\nOptions -Indexes\n" .
    "<IfModule mod_rewrite.c>\n" .
    "    RewriteEngine On\n" .
    "    RewriteCond %{REQUEST_FILENAME} !-f\n" .
    "    RewriteCond %{REQUEST_FILENAME} !-d\n" .
    "    RewriteRule ^ index.php [QSA,L]\n" .
    "</IfModule>\n" .
    "<FilesMatch \"\\.db$\">\n    Order allow,deny\n    Deny from all\n</FilesMatch>\n"
);

// ── Save to our DB ────────────────────────────────────────────────────────────
$siteName = ucwords(str_replace('-', ' ', $slug));
$siteUrl  = rtrim(getSetting('site_url', SITE_URL), '/') . '/sites/' . $slug . '/';

if ($siteId && $mode === 'edit') {
    $ourDb->prepare("UPDATE sites SET name=?, html_content=?, project_files=NULL, status='published', updated_at=NOW() WHERE id=? AND user_id=?")
          ->execute([$siteName, $code, $siteId, $user['id']]);
    $newId = $siteId;
} else {
    $ourDb->prepare("INSERT INTO sites (user_id, name, slug, prompt, html_content, status) VALUES (?,?,?,?,?,'published')")
          ->execute([$user['id'], $siteName, $slug, $prompt, $code]);
    $newId = $ourDb->lastInsertId();
}

try {
    $ourDb->prepare("INSERT INTO chat_history (site_id,role,content) VALUES (?,?,?)")->execute([$newId,'user',$prompt]);
    $ourDb->prepare("INSERT INTO chat_history (site_id,role,content) VALUES (?,?,?)")->execute([$newId,'assistant','Generated: '.strlen($code).' chars']);
} catch (Exception $e) {}

sse('done', [
    'site_id'   => $newId,
    'slug'      => $slug,
    'url'       => $siteUrl,
    'admin_url' => $siteUrl . '?page=admin',
    'chars'     => strlen($code),
    'is_php'    => true,
]);