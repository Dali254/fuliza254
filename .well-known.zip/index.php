<?php
require_once __DIR__ . '/config/db.php';
if (authUser()) { header('Location: ' . SITE_URL . '/dashboard.php'); exit; }
$siteName = getSetting('site_name', 'BuildKE');
$dlPrice  = getSetting('download_price', '499');
$hostPrice= getSetting('hosting_price', '299');
$siteUrl  = rtrim(SITE_URL, '/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
<title><?= htmlspecialchars($siteName) ?> — Build Websites with AI in Kenya</title>
<meta name="description" content="Build professional websites in minutes using AI. Pay with M-Pesa. No coding required.">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#07070e;--bg2:#0f0f18;--bg3:#161622;--bg4:#1c1c2a;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.12);
  --text:#eeeef6;--text2:rgba(238,238,246,.55);--text3:rgba(238,238,246,.3);
  --p:#7c3aed;--b:#3b82f6;--g:#10b981;--o:#f59e0b;
  --grad:linear-gradient(135deg,#7c3aed,#3b82f6);
}
html{scroll-behavior:smooth}
body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;-webkit-font-smoothing:antialiased;overflow-x:hidden}

/* ── NAV ── */
nav{
  position:fixed;top:0;left:0;right:0;z-index:200;
  height:60px;display:flex;align-items:center;padding:0 clamp(16px,5vw,48px);gap:12px;
  transition:background .3s,border-color .3s;
}
nav.scrolled{background:rgba(7,7,14,.88);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);border-bottom:1px solid var(--border)}
.nav-logo{font-size:17px;font-weight:900;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;letter-spacing:-.2px;flex-shrink:0}
.nav-gap{flex:1}
.nav-links{display:flex;align-items:center;gap:24px}
.nav-link{font-size:13px;font-weight:600;color:var(--text2);text-decoration:none;transition:.15s}
.nav-link:hover{color:var(--text)}
@media(max-width:600px){.nav-links{display:none}}
.nbtn{height:36px;padding:0 16px;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;border:none;transition:all .2s;text-decoration:none;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;-webkit-tap-highlight-color:transparent}
.nbtn-ghost{background:rgba(255,255,255,.07);color:var(--text2);border:1px solid var(--border2)}
.nbtn-ghost:hover{background:rgba(255,255,255,.12);color:var(--text)}
.nbtn-grad{background:var(--grad);color:#fff;box-shadow:0 3px 14px rgba(124,58,237,.38)}
.nbtn-grad:hover{filter:brightness(1.1);transform:translateY(-1px)}

/* ── HERO ── */
.hero{
  min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;
  text-align:center;padding:100px clamp(16px,5vw,48px) 60px;position:relative;overflow:hidden;
}
.hero-glow{position:absolute;top:-20%;left:50%;transform:translateX(-50%);width:min(900px,130vw);height:min(700px,100vw);background:radial-gradient(ellipse,rgba(124,58,237,.22) 0%,rgba(59,130,246,.08) 45%,transparent 70%);pointer-events:none;z-index:0}
.hero-glow2{position:absolute;bottom:-10%;left:20%;width:400px;height:300px;background:radial-gradient(ellipse,rgba(59,130,246,.1) 0%,transparent 65%);pointer-events:none}
.hero-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;background:rgba(124,58,237,.12);border:1px solid rgba(124,58,237,.28);border-radius:30px;font-size:12px;font-weight:700;color:#c4b5fd;margin-bottom:22px;position:relative;z-index:1}
.hero-t{font-size:clamp(32px,8vw,72px);font-weight:900;letter-spacing:-2px;line-height:1.06;position:relative;z-index:1;margin-bottom:20px}
.hero-t .grad-t{background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.hero-s{font-size:clamp(15px,2.5vw,19px);color:var(--text2);max-width:560px;line-height:1.65;position:relative;z-index:1;margin:0 auto 36px}
.hero-btns{display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;position:relative;z-index:1;margin-bottom:48px}
.hbtn{height:clamp(46px,6vw,56px);padding:0 clamp(20px,4vw,32px);border-radius:13px;font-size:clamp(13px,2vw,16px);font-weight:800;cursor:pointer;border:none;transition:all .22s;text-decoration:none;display:inline-flex;align-items:center;gap:8px;white-space:nowrap;-webkit-tap-highlight-color:transparent}
.hbtn-primary{background:var(--grad);color:#fff;box-shadow:0 6px 28px rgba(124,58,237,.45)}
.hbtn-primary:hover{transform:translateY(-3px);box-shadow:0 12px 40px rgba(124,58,237,.6);filter:brightness(1.08)}
.hbtn-secondary{background:rgba(255,255,255,.07);color:var(--text2);border:1px solid var(--border2)}
.hbtn-secondary:hover{background:rgba(255,255,255,.12);color:var(--text);transform:translateY(-2px)}

/* trust strip */
.trust{display:flex;align-items:center;justify-content:center;gap:clamp(16px,4vw,28px);flex-wrap:wrap;position:relative;z-index:1}
.trust-item{display:flex;align-items:center;gap:6px;font-size:12.5px;color:var(--text3);font-weight:600}
.trust-item i{font-size:13px;color:rgba(167,139,250,.7)}

/* ── DEMO PREVIEW ── */
.demo{padding:clamp(40px,8vw,80px) clamp(16px,5vw,48px);text-align:center;position:relative}
.demo-inner{max-width:900px;margin:0 auto}
.demo-label{font-size:11.5px;font-weight:800;text-transform:uppercase;letter-spacing:1px;color:rgba(167,139,250,.7);margin-bottom:14px}
.demo-t{font-size:clamp(24px,5vw,38px);font-weight:900;letter-spacing:-.8px;margin-bottom:14px}
.demo-s{font-size:15px;color:var(--text2);margin-bottom:40px;line-height:1.65}

.browser{background:var(--bg3);border:1px solid var(--border2);border-radius:16px;overflow:hidden;box-shadow:0 30px 80px rgba(0,0,0,.5)}
.browser-bar{height:42px;background:var(--bg4);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 14px;gap:8px}
.browser-dots{display:flex;gap:5px}
.dot{width:11px;height:11px;border-radius:50%}
.dot.r{background:rgba(239,68,68,.6)}
.dot.y{background:rgba(245,158,11,.6)}
.dot.g{background:rgba(16,185,129,.6)}
.browser-url{flex:1;height:26px;background:var(--bg3);border-radius:6px;margin:0 10px;display:flex;align-items:center;padding:0 10px;font-size:11px;color:var(--text3);font-family:monospace}
.browser-body{padding:0;background:#fff;min-height:260px;position:relative;overflow:hidden}
.browser-body iframe{width:100%;height:clamp(220px,40vw,360px);border:none;display:block;pointer-events:none}

/* ── STEPS ── */
.steps{padding:clamp(40px,8vw,80px) clamp(16px,5vw,48px);max-width:1100px;margin:0 auto}
.sec-badge{display:inline-block;padding:5px 14px;background:rgba(124,58,237,.1);border:1px solid rgba(124,58,237,.25);border-radius:20px;font-size:11.5px;font-weight:700;color:#c4b5fd;margin-bottom:14px}
.steps-head{text-align:center;margin-bottom:50px}
.steps-t{font-size:clamp(24px,5vw,38px);font-weight:900;letter-spacing:-.8px;margin-bottom:12px}
.steps-s{font-size:15px;color:var(--text2);max-width:500px;margin:0 auto;line-height:1.65}
.steps-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,240px),1fr));gap:clamp(12px,3vw,20px)}
.step{background:var(--bg2);border:1px solid var(--border);border-radius:18px;padding:clamp(20px,4vw,28px);transition:all .22s;position:relative;overflow:hidden}
.step::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--grad);transform:scaleX(0);transition:.3s;transform-origin:left}
.step:hover::before{transform:scaleX(1)}
.step:hover{border-color:rgba(124,58,237,.28);transform:translateY(-4px);box-shadow:0 20px 50px rgba(0,0,0,.3)}
.step-n{width:40px;height:40px;border-radius:12px;background:rgba(124,58,237,.12);border:1px solid rgba(124,58,237,.25);display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:900;color:#a78bfa;margin-bottom:16px}
.step-t{font-size:16px;font-weight:800;margin-bottom:8px}
.step-s{font-size:13px;color:var(--text2);line-height:1.65}

/* ── PRICING ── */
.pricing{padding:clamp(40px,8vw,80px) clamp(16px,5vw,48px);text-align:center;background:linear-gradient(to bottom,transparent,rgba(124,58,237,.04),transparent)}
.pricing-inner{max-width:780px;margin:0 auto}
.pricing-t{font-size:clamp(24px,5vw,38px);font-weight:900;letter-spacing:-.8px;margin-bottom:12px}
.pricing-s{font-size:15px;color:var(--text2);margin-bottom:44px;line-height:1.65}
.pricing-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));gap:16px;margin-bottom:40px}
.plan{background:var(--bg2);border:1px solid var(--border2);border-radius:20px;padding:clamp(24px,5vw,32px);text-align:left;position:relative;transition:all .22s}
.plan:hover{transform:translateY(-4px);box-shadow:0 24px 56px rgba(0,0,0,.35)}
.plan.featured{border-color:rgba(124,58,237,.4);background:linear-gradient(145deg,rgba(124,58,237,.08),rgba(59,130,246,.05))}
.plan-tag{display:inline-block;padding:3px 10px;background:var(--grad);color:#fff;border-radius:20px;font-size:10.5px;font-weight:800;margin-bottom:16px}
.plan-name{font-size:15px;font-weight:800;margin-bottom:6px;color:var(--text2);text-transform:uppercase;letter-spacing:.5px}
.plan-price{font-size:clamp(36px,7vw,52px);font-weight:900;letter-spacing:-2px;margin-bottom:4px;line-height:1}
.plan-price sup{font-size:18px;font-weight:700;vertical-align:top;margin-top:8px;letter-spacing:0}
.plan-cycle{font-size:12px;color:var(--text3);margin-bottom:20px}
.plan-feats{list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:24px}
.plan-feats li{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text2)}
.plan-feats li i{color:var(--g);font-size:12px;flex-shrink:0}
.plan-btn{display:block;width:100%;height:46px;border-radius:11px;font-size:14px;font-weight:800;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:7px;transition:all .2s;border:none;cursor:pointer;-webkit-tap-highlight-color:transparent}
.plan-btn.ghost{background:rgba(255,255,255,.07);color:var(--text2);border:1px solid var(--border2)}
.plan-btn.ghost:hover{background:rgba(255,255,255,.12);color:var(--text)}
.plan-btn.grad{background:var(--grad);color:#fff;box-shadow:0 4px 16px rgba(124,58,237,.4)}
.plan-btn.grad:hover{filter:brightness(1.1);transform:translateY(-1px)}

/* ── CTA ── */
.cta{padding:clamp(60px,10vw,100px) clamp(16px,5vw,48px);text-align:center;position:relative;overflow:hidden}
.cta-glow{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:600px;height:400px;background:radial-gradient(ellipse,rgba(124,58,237,.2) 0%,transparent 65%);pointer-events:none}
.cta-t{font-size:clamp(26px,6vw,52px);font-weight:900;letter-spacing:-1.5px;margin-bottom:14px;position:relative;z-index:1}
.cta-s{font-size:clamp(14px,2vw,17px);color:var(--text2);margin-bottom:36px;max-width:480px;margin-inline:auto;line-height:1.65;position:relative;z-index:1}

/* ── FOOTER ── */
footer{border-top:1px solid var(--border);padding:clamp(20px,4vw,28px) clamp(16px,5vw,48px);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.foot-logo{font-size:15px;font-weight:900;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.foot-copy{font-size:12px;color:var(--text3)}
.foot-links{display:flex;gap:20px}
.foot-link{font-size:12px;color:var(--text3);text-decoration:none;transition:.15s}
.foot-link:hover{color:var(--text2)}

/* DEMO SITE preview */
.demo-site{font-family:'Segoe UI',sans-serif;background:#fff;min-height:260px}
</style>
</head>
<body>

<!-- NAV -->
<nav id="nav">
  <div class="nav-logo">⚡ <?= htmlspecialchars($siteName) ?></div>
  <div class="nav-gap"></div>
  <div class="nav-links">
    <a href="#how" class="nav-link">How it works</a>
    <a href="#pricing" class="nav-link">Pricing</a>
  </div>
  <a href="<?= $siteUrl ?>/auth.php?mode=login" class="nbtn nbtn-ghost">Sign In</a>
  <a href="<?= $siteUrl ?>/auth.php?mode=register" class="nbtn nbtn-grad"><i class="fa-solid fa-bolt"></i> Get Started</a>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-glow"></div>
  <div class="hero-glow2"></div>
  <div class="hero-badge"><i class="fa-solid fa-bolt"></i> AI-Powered · M-Pesa Payments</div>
  <h1 class="hero-t">
    Build Professional<br>
    <span class="grad-t">Websites in Minutes</span>
  </h1>
  <p class="hero-s">Just describe your business and our AI builds a complete, stunning website for you. No coding. No designers. Pay with M-Pesa.</p>
  <div class="hero-btns">
    <a href="<?= $siteUrl ?>/auth.php?mode=register" class="hbtn hbtn-primary">
      <i class="fa-solid fa-wand-magic-sparkles"></i> Start Building Free
    </a>
    <a href="#how" class="hbtn hbtn-secondary">
      <i class="fa-solid fa-play"></i> See How It Works
    </a>
  </div>
  <div class="trust">
    <div class="trust-item"><i class="fa-solid fa-check-circle"></i> No coding required</div>
    <div class="trust-item"><i class="fa-solid fa-check-circle"></i> M-Pesa payment</div>
    <div class="trust-item"><i class="fa-solid fa-check-circle"></i> Mobile responsive</div>
    <div class="trust-item"><i class="fa-solid fa-check-circle"></i> Ready in 60 seconds</div>
  </div>
</section>

<!-- DEMO -->
<section class="demo" id="demo">
  <div class="demo-inner">
    <div class="demo-label">Live Preview</div>
    <h2 class="demo-t">Watch it build in real time</h2>
    <p class="demo-s">Type a description, hit send — your website appears instantly in the preview panel, ready to edit or publish.</p>
    <div class="browser">
      <div class="browser-bar">
        <div class="browser-dots">
          <div class="dot r"></div><div class="dot y"></div><div class="dot g"></div>
        </div>
        <div class="browser-url">m.lipawin.com/builder</div>
      </div>
      <div class="browser-body">
        <iframe srcdoc="<?= htmlspecialchars('<!DOCTYPE html><html><head><meta charset=UTF-8><meta name=viewport content="width=device-width,initial-scale=1"><style>*{box-sizing:border-box;margin:0;padding:0;font-family:Segoe UI,sans-serif}body{background:#fff;min-height:260px}nav{height:60px;background:linear-gradient(135deg,#7c3aed,#3b82f6);display:flex;align-items:center;padding:0 30px;justify-content:space-between}.logo{color:#fff;font-weight:900;font-size:18px}.nav-btn{background:rgba(255,255,255,.2);color:#fff;border:none;padding:8px 18px;border-radius:8px;font-weight:700;font-size:13px;cursor:pointer}.hero{padding:60px 30px;text-align:center;background:linear-gradient(135deg,#f8f6ff,#eff6ff)}.hero h1{font-size:36px;font-weight:900;color:#1a1a2e;margin-bottom:14px}.hero p{font-size:16px;color:#555;margin-bottom:28px;max-width:500px;margin-inline:auto}.btn{display:inline-block;background:linear-gradient(135deg,#7c3aed,#3b82f6);color:#fff;padding:14px 32px;border-radius:12px;font-weight:800;font-size:15px;text-decoration:none;box-shadow:0 6px 20px rgba(124,58,237,.4)}.services{padding:48px 30px;display:grid;grid-template-columns:repeat(3,1fr);gap:20px;background:#fff}.service{text-align:center;padding:24px;border:1px solid #e8e8f0;border-radius:16px}.service-ico{font-size:32px;margin-bottom:12px}.service-t{font-weight:800;font-size:15px;margin-bottom:6px;color:#1a1a2e}.service-s{font-size:13px;color:#888;line-height:1.6}@media(max-width:600px){.services{grid-template-columns:1fr}.hero h1{font-size:26px}}</style></head><body><nav><div class="logo">✂ GlamourSalon</div><button class="nav-btn">Book Now</button></nav><div class="hero"><h1>Transform Your Look Today</h1><p>Professional hair & beauty services in Nairobi. Book your appointment online.</p><a class="btn" href="#">Book Appointment</a></div><div class="services"><div class="service"><div class="service-ico">💇</div><div class="service-t">Hair Styling</div><div class="service-s">Expert cuts, color, and treatment for all hair types</div></div><div class="service"><div class="service-ico">💅</div><div class="service-t">Nail Art</div><div class="service-s">Beautiful manicure and pedicure services</div></div><div class="service"><div class="service-ico">✨</div><div class="service-t">Beauty Treatment</div><div class="service-s">Facials, threading, and full body care</div></div></div></body></html>') ?>"></iframe>
      </div>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section class="steps" id="how">
  <div class="steps-head">
    <div class="sec-badge">How it works</div>
    <h2 class="steps-t">3 steps to your website</h2>
    <p class="steps-s">From description to live website in under 2 minutes — no technical skills needed.</p>
  </div>
  <div class="steps-grid">
    <div class="step">
      <div class="step-n">1</div>
      <div class="step-t">Describe Your Business</div>
      <div class="step-s">Type what your business does, your preferred colors and style. You can even upload a photo as design reference.</div>
    </div>
    <div class="step">
      <div class="step-n">2</div>
      <div class="step-t">AI Builds It Instantly</div>
      <div class="step-s">Our AI generates a complete, professional website with your branding, content, and design — ready to view live.</div>
    </div>
    <div class="step">
      <div class="step-n">3</div>
      <div class="step-t">Pay & Go Live</div>
      <div class="step-s">Download the code or let us host it for you. Pay easily with M-Pesa. Your site goes live immediately.</div>
    </div>
    <div class="step">
      <div class="step-n">4</div>
      <div class="step-t">Keep Editing Anytime</div>
      <div class="step-s">Come back and make changes anytime — "change the colors", "add a gallery", "update the prices". AI applies them instantly.</div>
    </div>
  </div>
</section>

<!-- PRICING -->
<section class="pricing" id="pricing">
  <div class="pricing-inner">
    <div class="sec-badge">Simple Pricing</div>
    <h2 class="pricing-t">Start free, pay when ready</h2>
    <p class="pricing-s">Build and edit for free. Only pay when you're happy and want to download or go live.</p>
    <div class="pricing-grid">
      <div class="plan">
        <div class="plan-name">Download</div>
        <div class="plan-price"><sup>KES</sup><?= number_format(intval($dlPrice)) ?></div>
        <div class="plan-cycle">One-time payment</div>
        <ul class="plan-feats">
          <li><i class="fa-solid fa-check"></i> Complete HTML/CSS/JS code</li>
          <li><i class="fa-solid fa-check"></i> Download ZIP file</li>
          <li><i class="fa-solid fa-check"></i> Host anywhere you want</li>
          <li><i class="fa-solid fa-check"></i> Full ownership</li>
          <li><i class="fa-solid fa-check"></i> Unlimited edits before paying</li>
        </ul>
        <a href="<?= $siteUrl ?>/auth.php?mode=register" class="plan-btn ghost">Get Started</a>
      </div>
      <div class="plan featured">
        <div class="plan-tag">⚡ Most Popular</div>
        <div class="plan-name">Hosting</div>
        <div class="plan-price"><sup>KES</sup><?= number_format(intval($hostPrice)) ?></div>
        <div class="plan-cycle">per month · live on our servers</div>
        <ul class="plan-feats">
          <li><i class="fa-solid fa-check"></i> We host your site for you</li>
          <li><i class="fa-solid fa-check"></i> Instant live URL to share</li>
          <li><i class="fa-solid fa-check"></i> Mobile-friendly & fast</li>
          <li><i class="fa-solid fa-check"></i> Keep editing anytime</li>
          <li><i class="fa-solid fa-check"></i> Renew monthly or yearly</li>
        </ul>
        <a href="<?= $siteUrl ?>/auth.php?mode=register" class="plan-btn grad"><i class="fa-solid fa-rocket"></i> Start Free</a>
      </div>
    </div>
    <p style="font-size:13px;color:var(--text3)">All prices in Kenyan Shillings · Pay securely with M-Pesa</p>
  </div>
</section>

<!-- CTA -->
<section class="cta">
  <div class="cta-glow"></div>
  <h2 class="cta-t">Ready to build your<br>website today?</h2>
  <p class="cta-s">Join hundreds of Kenyan businesses who built their websites in minutes with AI. No technical skills required.</p>
  <a href="<?= $siteUrl ?>/auth.php?mode=register" class="hbtn hbtn-primary" style="font-size:16px;height:56px;padding:0 36px">
    <i class="fa-solid fa-wand-magic-sparkles"></i> Build My Website Free
  </a>
</section>

<!-- FOOTER -->
<footer>
  <div class="foot-logo">⚡ <?= htmlspecialchars($siteName) ?></div>
  <div class="foot-copy">© <?= date('Y') ?> <?= htmlspecialchars($siteName) ?> · Built with AI in Kenya 🇰🇪</div>
  <div class="foot-links">
    <a href="#" class="foot-link">Privacy</a>
    <a href="#" class="foot-link">Terms</a>
    <a href="<?= $siteUrl ?>/auth.php" class="foot-link">Login</a>
  </div>
</footer>

<script>
// Sticky nav scroll effect
var nav = document.getElementById('nav');
window.addEventListener('scroll', function(){
  nav.classList.toggle('scrolled', window.scrollY > 40);
}, {passive:true});

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(function(a){
  a.addEventListener('click', function(e){
    var id = this.getAttribute('href').slice(1);
    var el = document.getElementById(id);
    if(el){ e.preventDefault(); el.scrollIntoView({behavior:'smooth',block:'start'}); }
  });
});

// Intersection observer for step animations
if('IntersectionObserver' in window){
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if(en.isIntersecting) en.target.style.opacity='1', en.target.style.transform='translateY(0)';
    });
  },{threshold:.15});
  document.querySelectorAll('.step,.plan').forEach(function(el){
    el.style.opacity='0';el.style.transform='translateY(24px)';el.style.transition='opacity .5s ease,transform .5s ease';
    io.observe(el);
  });
}
</script>
</body>
</html>