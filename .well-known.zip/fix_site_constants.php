<?php
// fix_site_constants.php — fixes DB_HOST/DB_NAME constant conflicts in deployed sites
// Run once, then DELETE this file
require_once __DIR__ . '/config/db.php';

$sitesDir = __DIR__ . '/sites/';
$fixed    = [];
$errors   = [];

foreach (glob($sitesDir . '*/') as $siteDir) {
    $dbConfig = $siteDir . 'config/db.php';
    if (!file_exists($dbConfig)) continue;

    $content  = file_get_contents($dbConfig);
    $original = $content;

    // Rename constants
    $content = preg_replace('/\bdefine\s*\(\s*["\']DB_HOST["\']/i',  'define("SITE_DB_HOST"', $content);
    $content = preg_replace('/\bdefine\s*\(\s*["\']DB_NAME["\']/i',  'define("SITE_DB_NAME"', $content);
    $content = preg_replace('/\bdefine\s*\(\s*["\']DB_USER["\']/i',  'define("SITE_DB_USER"', $content);
    $content = preg_replace('/\bdefine\s*\(\s*["\']DB_PASS["\']/i',  'define("SITE_DB_PASS"', $content);

    // Update usages in same file
    $content = preg_replace('/\bDB_HOST\b/', 'SITE_DB_HOST', $content);
    $content = preg_replace('/\bDB_NAME\b/', 'SITE_DB_NAME', $content);
    $content = preg_replace('/\bDB_USER\b/', 'SITE_DB_USER', $content);
    $content = preg_replace('/\bDB_PASS\b/', 'SITE_DB_PASS', $content);

    // Wrap in defined() checks
    $content = preg_replace(
        '/define\("SITE_DB_(HOST|NAME|USER|PASS)"\s*,\s*([^)]+)\)/i',
        'defined("SITE_DB_$1") || define("SITE_DB_$1", $2)',
        $content
    );

    if ($content !== $original) {
        if (file_put_contents($dbConfig, $content) !== false) {
            $fixed[] = $siteDir;
        } else {
            $errors[] = "Could not write: $dbConfig";
        }
    }

    // Also fix usages in ALL php files in this site
    $phpFiles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($siteDir));
    foreach ($phpFiles as $phpFile) {
        if ($phpFile->getExtension() !== 'php') continue;
        if ($phpFile->getRealPath() === realpath($dbConfig)) continue; // already fixed above

        $c = file_get_contents($phpFile->getRealPath());
        $orig = $c;
        $c = preg_replace('/\bDB_HOST\b/', 'SITE_DB_HOST', $c);
        $c = preg_replace('/\bDB_NAME\b/', 'SITE_DB_NAME', $c);
        $c = preg_replace('/\bDB_USER\b/', 'SITE_DB_USER', $c);
        $c = preg_replace('/\bDB_PASS\b/', 'SITE_DB_PASS', $c);
        if ($c !== $orig) file_put_contents($phpFile->getRealPath(), $c);
    }
}

echo "<pre>";
echo "✅ Fixed " . count($fixed) . " site(s):\n";
foreach ($fixed as $s) echo "  - $s\n";
if ($errors) {
    echo "\n❌ Errors:\n";
    foreach ($errors as $e) echo "  - $e\n";
}
echo "\n⚠️  DELETE this file now: fix_site_constants.php\n";
echo "</pre>";