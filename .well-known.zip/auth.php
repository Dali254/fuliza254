<?php
require_once __DIR__ . '/config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

if (authUser()) { header('Location: ' . SITE_URL . '/dashboard.php'); exit; }

$mode  = $_GET['mode'] ?? 'login';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        $name  = clean($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $phone = normalizePhone($_POST['phone'] ?? '');
        $pass  = $_POST['password'] ?? '';

        if (!$name || !$email || !$phone || !$pass) { $error = 'All fields are required.'; }
        elseif (strlen($pass) < 6)                  { $error = 'Password must be at least 6 characters.'; }
        else {
            $chk = getDB()->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
            $chk->execute([$email]);
            if ($chk->fetch()) {
                $error = 'Email already registered. Please login instead.';
            } else {
                getDB()->prepare("INSERT INTO users (name,email,phone,password) VALUES (?,?,?,?)")
                       ->execute([$name, $email, $phone, password_hash($pass, PASSWORD_DEFAULT)]);
                $uid = getDB()->lastInsertId();
                loginUser(['id'=>$uid,'name'=>$name]);
                header('Location: ' . SITE_URL . '/builder.php'); exit;
            }
        }
    }

    if ($action === 'login') {
        $email = strtolower(trim($_POST['email'] ?? ''));
        $pass  = $_POST['password'] ?? '';
        $s = getDB()->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
        $s->execute([$email]);
        $u = $s->fetch();
        if ($u && password_verify($pass, $u['password'])) {
            loginUser($u);
            header('Location: ' . SITE_URL . '/' . ltrim($_GET['redirect'] ?? 'dashboard.php', '/')); exit;
        } else {
            $error = 'Invalid email or password.';
        }
    }
}

$siteName = getSetting('site_name', 'BuildKE');
$siteUrl  = rtrim(SITE_URL, '/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
<title><?= $mode==='register'?'Create Account':'Sign In' ?> — <?= htmlspecialchars($siteName) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#07070e;--bg2:#0f0f18;--bg3:#161622;--bg4:#1c1c2a;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
  --text:#eeeef6;--text2:rgba(238,238,246,.54);--text3:rgba(238,238,246,.3);
  --p:#7c3aed;--b:#3b82f6;--g:#10b981;--r:#ef4444;
  --grad:linear-gradient(135deg,#7c3aed,#3b82f6);
}
html,body{min-height:100%;-webkit-font-smoothing:antialiased}
body{
  background:var(--bg);color:var(--text);
  font-family:'Segoe UI',system-ui,sans-serif;
  min-height:100vh;display:flex;flex-direction:column;
  background-image:
    radial-gradient(ellipse 130% 70% at 50% -10%,rgba(124,58,237,.15) 0%,transparent 60%),
    radial-gradient(ellipse 60% 50% at 90% 110%,rgba(59,130,246,.08) 0%,transparent 55%);
}

/* BACK LINK */
.back{padding:16px clamp(16px,5vw,32px);display:flex;align-items:center}
.back a{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:var(--text3);text-decoration:none;font-weight:600;transition:.15s}
.back a:hover{color:var(--text2)}

/* MAIN */
.main{flex:1;display:flex;align-items:center;justify-content:center;padding:16px clamp(16px,5vw,32px) 40px}
.card{
  width:100%;max-width:440px;
  background:var(--bg2);border:1px solid var(--border);border-radius:24px;
  padding:clamp(26px,6vw,40px) clamp(22px,6vw,38px);
  box-shadow:0 40px 100px rgba(0,0,0,.5),0 0 0 1px rgba(124,58,237,.06);
  position:relative;overflow:hidden;
}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--grad)}

/* LOGO */
.logo{text-align:center;margin-bottom:6px}
.logo-mark{font-size:28px;font-weight:900;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;letter-spacing:-.5px}
.logo-sub{font-size:13px;color:var(--text2);text-align:center;margin-bottom:28px;line-height:1.5}

/* TABS */
.tabs{display:grid;grid-template-columns:1fr 1fr;background:var(--bg3);border-radius:13px;padding:4px;gap:3px;margin-bottom:24px;border:1px solid var(--border)}
.tab{height:38px;border-radius:10px;border:none;background:transparent;color:var(--text2);font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;-webkit-tap-highlight-color:transparent}
.tab.on{background:var(--bg4);color:var(--text);box-shadow:0 2px 10px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.07)}

/* FORM */
.fgrp{margin-bottom:15px}
.flbl{display:flex;align-items:center;gap:5px;font-size:11px;font-weight:800;color:var(--text3);text-transform:uppercase;letter-spacing:.7px;margin-bottom:7px}
.finp-wrap{position:relative}
.finp-ico{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--text3);font-size:14px;pointer-events:none;transition:.2s}
.finp{
  width:100%;height:50px;background:var(--bg3);
  border:1.5px solid var(--border2);border-radius:12px;
  padding:0 14px 0 42px;color:var(--text);font-size:14px;
  outline:none;transition:all .2s;font-family:inherit;
  -webkit-appearance:none;
}
.finp:focus{border-color:var(--p);background:rgba(124,58,237,.06);box-shadow:0 0 0 3px rgba(124,58,237,.12)}
.finp:focus~.finp-ico,.finp-wrap:focus-within .finp-ico{color:#a78bfa}
.finp::placeholder{color:var(--text3)}

/* PW TOGGLE */
.pw-toggle{position:absolute;right:14px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text3);cursor:pointer;font-size:14px;padding:4px;transition:.15s}
.pw-toggle:hover{color:var(--text2)}

/* SUBMIT */
.submit{
  width:100%;height:52px;border-radius:13px;border:none;cursor:pointer;
  font-size:15px;font-weight:800;color:#fff;margin-top:8px;
  background:var(--grad);box-shadow:0 6px 24px rgba(124,58,237,.45);
  transition:all .2s;display:flex;align-items:center;justify-content:center;gap:9px;
  -webkit-tap-highlight-color:transparent;
}
.submit:hover{transform:translateY(-2px);box-shadow:0 10px 32px rgba(124,58,237,.6);filter:brightness(1.08)}
.submit:active{transform:translateY(0)}

/* ALERT */
.alert{padding:12px 14px;border-radius:11px;font-size:13px;margin-bottom:18px;display:flex;align-items:flex-start;gap:8px;line-height:1.5}
.alert.err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#fca5a5}

/* FOOTER */
.foot{font-size:11.5px;color:var(--text3);text-align:center;margin-top:18px;line-height:1.6}
.foot a{color:rgba(167,139,250,.8);text-decoration:none}
.foot a:hover{color:#c4b5fd}

/* FEATURES STRIP */
.feats{display:flex;align-items:center;justify-content:center;gap:clamp(14px,4vw,28px);margin-top:32px;flex-wrap:wrap}
.feat{display:flex;align-items:center;gap:6px;font-size:11.5px;color:var(--text3);font-weight:600}
.feat i{font-size:12px;color:rgba(124,58,237,.7)}
</style>
</head>
<body>

<div class="back">
  <a href="<?= $siteUrl ?>"><i class="fa-solid fa-arrow-left"></i> Back to Home</a>
</div>

<div class="main">
  <div class="card">
    <div class="logo">
      <div class="logo-mark">⚡ <?= htmlspecialchars($siteName) ?></div>
    </div>
    <div class="logo-sub" id="cardSub"><?= $mode==='register' ? 'Create your free account and start building' : 'Welcome back! Sign in to your account' ?></div>

    <div class="tabs">
      <button class="tab <?= $mode==='login'?'on':'' ?>" onclick="switchMode('login')">Sign In</button>
      <button class="tab <?= $mode==='register'?'on':'' ?>" onclick="switchMode('register')">Create Account</button>
    </div>

    <?php if ($error): ?>
    <div class="alert err"><i class="fa-solid fa-circle-exclamation" style="flex-shrink:0;margin-top:1px"></i><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- LOGIN -->
    <form method="POST" id="loginForm" style="display:<?= $mode==='login'?'block':'none' ?>">
      <input type="hidden" name="action" value="login">
      <div class="fgrp">
        <label class="flbl"><i class="fa-solid fa-envelope"></i> Email</label>
        <div class="finp-wrap">
          <i class="fa-solid fa-envelope finp-ico"></i>
          <input type="email" name="email" class="finp" placeholder="you@example.com" required autocomplete="email">
        </div>
      </div>
      <div class="fgrp">
        <label class="flbl"><i class="fa-solid fa-lock"></i> Password</label>
        <div class="finp-wrap">
          <i class="fa-solid fa-lock finp-ico"></i>
          <input type="password" name="password" id="lpw" class="finp" placeholder="••••••••" required autocomplete="current-password">
          <button type="button" class="pw-toggle" onclick="togglePw('lpw',this)"><i class="fa-solid fa-eye"></i></button>
        </div>
      </div>
      <button type="submit" class="submit"><i class="fa-solid fa-arrow-right-to-bracket"></i> Sign In</button>
      <div class="foot">Don't have an account? <a href="#" onclick="switchMode('register');return false">Create one free →</a></div>
    </form>

    <!-- REGISTER -->
    <form method="POST" id="regForm" style="display:<?= $mode==='register'?'block':'none' ?>">
      <input type="hidden" name="action" value="register">
      <div class="fgrp">
        <label class="flbl"><i class="fa-solid fa-user"></i> Full Name</label>
        <div class="finp-wrap">
          <i class="fa-solid fa-user finp-ico"></i>
          <input type="text" name="name" class="finp" placeholder="Jane Wanjiku" required autocomplete="name">
        </div>
      </div>
      <div class="fgrp">
        <label class="flbl"><i class="fa-solid fa-envelope"></i> Email</label>
        <div class="finp-wrap">
          <i class="fa-solid fa-envelope finp-ico"></i>
          <input type="email" name="email" class="finp" placeholder="you@example.com" required autocomplete="email">
        </div>
      </div>
      <div class="fgrp">
        <label class="flbl"><i class="fa-brands fa-safari"></i> M-Pesa Number</label>
        <div class="finp-wrap">
          <i class="fa-solid fa-mobile-screen finp-ico"></i>
          <input type="tel" name="phone" class="finp" placeholder="07XX XXX XXX" required autocomplete="tel">
        </div>
      </div>
      <div class="fgrp">
        <label class="flbl"><i class="fa-solid fa-lock"></i> Password</label>
        <div class="finp-wrap">
          <i class="fa-solid fa-lock finp-ico"></i>
          <input type="password" name="password" id="rpw" class="finp" placeholder="Min 6 characters" required minlength="6" autocomplete="new-password">
          <button type="button" class="pw-toggle" onclick="togglePw('rpw',this)"><i class="fa-solid fa-eye"></i></button>
        </div>
      </div>
      <button type="submit" class="submit"><i class="fa-solid fa-rocket"></i> Create Free Account</button>
      <div class="foot">Already have an account? <a href="#" onclick="switchMode('login');return false">Sign in →</a></div>
    </form>
  </div>
</div>

<div class="feats">
  <div class="feat"><i class="fa-solid fa-bolt"></i> Build in minutes</div>
  <div class="feat"><i class="fa-solid fa-mobile-screen"></i> Pay with M-Pesa</div>
  <div class="feat"><i class="fa-solid fa-lock"></i> Secure & private</div>
</div>

<script>
function switchMode(m){
  document.getElementById('loginForm').style.display = m==='login'?'block':'none';
  document.getElementById('regForm').style.display   = m==='register'?'block':'none';
  document.querySelectorAll('.tab').forEach(function(t,i){t.classList.toggle('on',(i===0&&m==='login')||(i===1&&m==='register'));});
  document.getElementById('cardSub').textContent = m==='register'?'Create your free account and start building':'Welcome back! Sign in to your account';
  history.replaceState(null,'','?mode='+m);
}
function togglePw(id, btn){
  var inp=document.getElementById(id);
  var show=inp.type==='password';
  inp.type=show?'text':'password';
  btn.querySelector('i').className='fa-solid fa-eye'+(show?'-slash':'');
}
</script>
</body>
</html>