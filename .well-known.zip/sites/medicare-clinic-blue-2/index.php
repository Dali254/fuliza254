<?php
session_start();

// Database initialization
$db = new PDO('sqlite:' . __DIR__ . '/medicaredb.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec('PRAGMA journal_mode=WAL');

// Create tables
$db->exec("CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    price TEXT NOT NULL,
    icon TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS gallery (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    image_url TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    message TEXT NOT NULL,
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_name TEXT NOT NULL,
    patient_email TEXT NOT NULL,
    patient_phone TEXT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    service_type TEXT NOT NULL,
    notes TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS admin_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)");

$db->exec("CREATE TABLE IF NOT EXISTS testimonials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_name TEXT NOT NULL,
    rating INTEGER NOT NULL,
    review TEXT NOT NULL,
    image_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// Seed initial data
$serviceCount = $db->query("SELECT COUNT(*) FROM services")->fetchColumn();
if ($serviceCount == 0) {
    $services = [
        ['General Consultation', 'Comprehensive health check-up with our experienced doctors. Full medical history review and diagnosis.', 'KES 1,500', '🏥'],
        ['Dental Care', 'Professional dental examination, cleaning, and treatment by certified dentists.', 'KES 2,000', '🦷'],
        ['Eye Care', 'Comprehensive eye examination and prescription for glasses or contact lenses.', 'KES 1,800', '👁️'],
        ['Laboratory Tests', 'Blood tests, X-rays, ultrasound, and other diagnostic procedures with fast results.', 'KES 500-3,000', '🧬'],
        ['Vaccination', 'Complete vaccination schedules for children and adults including travel vaccines.', 'KES 800-2,500', '💉'],
        ['Pharmacy Services', 'Access to certified medications and pharmaceutical consultations.', 'Varies', '💊'],
        ['Minor Surgery', 'Safe minor surgical procedures in our equipped operation theatre.', 'KES 5,000', '🔪'],
        ['Physical Therapy', 'Rehabilitation and physiotherapy services for injury recovery and pain management.', 'KES 2,000', '🏃']
    ];
    
    foreach ($services as $s) {
        $db->prepare("INSERT INTO services (title, description, price, icon) VALUES (?, ?, ?, ?)")
            ->execute($s);
    }
    
    $gallery = [
        ['Modern Reception Area', 'https://images.unsplash.com/photo-1576091160550-112173e7f38e?w=600&h=400&fit=crop'],
        ['Medical Laboratory', 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&h=400&fit=crop'],
        ['Doctor Consultation', 'https://images.unsplash.com/photo-1631217b831ec6fc6f88af8951f857526?w=600&h=400&fit=crop'],
        ['Patient Care Ward', 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&h=400&fit=crop'],
        ['Surgical Equipment', 'https://images.unsplash.com/photo-1584308666744-24d5f400f6f5?w=600&h=400&fit=crop'],
        ['Pharmacy Section', 'https://images.unsplash.com/photo-1631217b831ec6fc6f88af8951f857526?w=600&h=400&fit=crop'],
        ['Emergency Department', 'https://images.unsplash.com/photo-1576091160550-112173e7f38e?w=600&h=400&fit=crop'],
        ['Patient Waiting Area', 'https://images.unsplash.com/photo-1631217b831ec6fc6f88af8951f857526?w=600&h=400&fit=crop'],
        ['Medical Imaging', 'https://images.unsplash.com/photo-1584308666744-24d5f400f6f5?w=600&h=400&fit=crop']
    ];
    
    foreach ($gallery as $g) {
        $db->prepare("INSERT INTO gallery (title, image_url) VALUES (?, ?)")
            ->execute($g);
    }
    
    $testimonials = [
        ['Dr. Kamau Said', 5, 'Excellent service! The doctors are highly professional and the facilities are state-of-the-art. Highly recommended.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kamau'],
        ['Grace Mwangi', 5, 'Very impressed with the staff and quick service. My appointment was on time and the consultation was thorough.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Grace'],
        ['James Ochieng', 4, 'Good medical care and friendly nurses. The waiting time was minimal and the treatment was effective.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=James'],
        ['Mary Njoki', 5, 'Best clinic in Nairobi! Professional doctors, clean environment, and reasonable prices.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mary'],
        ['Peter Kipchoge', 5, 'Outstanding experience. The doctor explained everything clearly and the pharmacy service was fast.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Peter']
    ];
    
    foreach ($testimonials as $t) {
        $db->prepare("INSERT INTO testimonials (patient_name, rating, review, image_url) VALUES (?, ?, ?, ?)")
            ->execute($t);
    }
    
    if ($db->query("SELECT COUNT(*) FROM admin_users")->fetchColumn() == 0) {
        $adminPass = password_hash('admin123', PASSWORD_DEFAULT);
        $db->prepare("INSERT INTO admin_users (username, password) VALUES (?, ?)")
            ->execute(['admin', $adminPass]);
    }
}

// Route handling
$page = $_GET['page'] ?? 'home';

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'contact') {
        $name = htmlspecialchars($_POST['name'] ?? '');
        $email = htmlspecialchars($_POST['email'] ?? '');
        $phone = htmlspecialchars($_POST['phone'] ?? '');
        $message = htmlspecialchars($_POST['message'] ?? '');
        
        if ($name && $email && $phone && $message) {
            $db->prepare("INSERT INTO messages (name, email, phone, message) VALUES (?, ?, ?, ?)")
                ->execute([$name, $email, $phone, $message]);
            $_SESSION['msg'] = 'Message sent successfully! We will contact you soon.';
        }
        header('Location: ?page=contact');
        exit;
    }
    
    if ($action === 'book_appointment') {
        $patient_name = htmlspecialchars($_POST['patient_name'] ?? '');
        $patient_email = htmlspecialchars($_POST['patient_email'] ?? '');
        $patient_phone = htmlspecialchars($_POST['patient_phone'] ?? '');
        $appointment_date = htmlspecialchars($_POST['appointment_date'] ?? '');
        $appointment_time = htmlspecialchars($_POST['appointment_time'] ?? '');
        $service_type = htmlspecialchars($_POST['service_type'] ?? '');
        $notes = htmlspecialchars($_POST['notes'] ?? '');
        
        if ($patient_name && $patient_email && $patient_phone && $appointment_date && $appointment_time && $service_type) {
            $db->prepare("INSERT INTO appointments (patient_name, patient_email, patient_phone, appointment_date, appointment_time, service_type, notes) VALUES (?, ?, ?, ?, ?, ?, ?)")
                ->execute([$patient_name, $patient_email, $patient_phone, $appointment_date, $appointment_time, $service_type, $notes]);
            $_SESSION['appointment_msg'] = 'Appointment booked successfully! Check your email for confirmation.';
        }
        header('Location: ?page=appointments');
        exit;
    }
    
    if ($action === 'admin_login') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        $user = $db->prepare("SELECT * FROM admin_users WHERE username = ?")
            ->fetch(PDO::FETCH_ASSOC, [$username]);
        $db->prepare("SELECT * FROM admin_users WHERE username = ?")->execute([$username]);
        $user = $db->prepare("SELECT * FROM admin_users WHERE username = ?")->execute([$username]);
        $user = $db->query("SELECT * FROM admin_users WHERE username = '$username'")->fetch(PDO::FETCH_ASSOC);
        
        $result = $db->prepare("SELECT * FROM admin_users WHERE username = ?");
        $result->execute([$username]);
        $user = $result->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['admin'] = $user['id'];
            header('Location: ?page=admin&section=dashboard');
            exit;
        } else {
            $_SESSION['login_error'] = 'Invalid credentials';
        }
    }
    
    if (isset($_SESSION['admin'])) {
        if ($action === 'add_service') {
            $title = htmlspecialchars($_POST['title'] ?? '');
            $description = htmlspecialchars($_POST['description'] ?? '');
            $price = htmlspecialchars($_POST['price'] ?? '');
            $icon = htmlspecialchars($_POST['icon'] ?? '');
            
            if ($title && $description && $price) {
                $db->prepare("INSERT INTO services (title, description, price, icon) VALUES (?, ?, ?, ?)")
                    ->execute([$title, $description, $price, $icon]);
                $_SESSION['admin_msg'] = 'Service added successfully';
            }
            header('Location: ?page=admin&section=services');
            exit;
        }
        
        if ($action === 'delete_service') {
            $id = intval($_POST['id'] ?? 0);
            if ($id) {
                $db->prepare("DELETE FROM services WHERE id = ?")->execute([$id]);
                $_SESSION['admin_msg'] = 'Service deleted';
            }
            header('Location: ?page=admin&section=services');
            exit;
        }
        
        if ($action === 'delete_message') {
            $id = intval($_POST['id'] ?? 0);
            if ($id) {
                $db->prepare("DELETE FROM messages WHERE id = ?")->execute([$id]);
            }
            header('Location: ?page=admin&section=messages');
            exit;
        }
        
        if ($action === 'add_gallery') {
            $title = htmlspecialchars($_POST['title'] ?? '');
            $image_url = htmlspecialchars($_POST['image_url'] ?? '');
            
            if ($title && $image_url) {
                $db->prepare("INSERT INTO gallery (title, image_url) VALUES (?, ?)")
                    ->execute([$title, $image_url]);
                $_SESSION['admin_msg'] = 'Gallery item added';
            }
            header('Location: ?page=admin&section=gallery');
            exit;
        }
        
        if ($action === 'delete_gallery') {
            $id = intval($_POST['id'] ?? 0);
            if ($id) {
                $db->prepare("DELETE FROM gallery WHERE id = ?")->execute([$id]);
            }
            header('Location: ?page=admin&section=gallery');
            exit;
        }
        
        if ($action === 'update_appointment_status') {
            $id = intval($_POST['id'] ?? 0);
            $status = htmlspecialchars($_POST['status'] ?? '');
            if ($id && $status) {
                $db->prepare("UPDATE appointments SET status = ? WHERE id = ?")->execute([$status, $id]);
            }
            header('Location: ?page=admin&section=appointments');
            exit;
        }
    }
    
    if ($action === 'admin_logout') {
        unset($_SESSION['admin']);
        header('Location: ?page=home');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MediCare Clinic - Professional Healthcare Services in Nairobi</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0066cc;
            --primary-dark: #0052a3;
            --primary-light: #e6f0ff;
            --secondary: #00b4d8;
            --accent: #00d4ff;
            --text-dark: #1a1a1a;
            --text-light: #666666;
            --border: #e0e0e0;
            --bg-light: #f8f9fa;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --white: #ffffff;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            background-color: var(--white);
            line-height: 1.6;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            color: var(--text-dark);
        }

        /* Header & Navigation */
        header {
            background: var(--white);
            border-bottom: 1px solid var(--border);
            position: sticky;
            top: 0;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        header.scrolled {
            box-shadow: 0 2px 10px rgba(0, 102, 204, 0.1);
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
            color: var(--primary);
            font-size: 1.5rem;
            font-weight: 800;
            font-family: 'Poppins', sans-serif;
        }

        .logo span {
            color: var(--secondary);
        }

        nav {
            display: flex;
            gap: 2rem;
            align-items: center;
        }

        nav a {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            transition: color 0.3s ease;
            position: relative;
        }

        nav a:hover {
            color: var(--primary);
        }

        nav a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--secondary);
            transition: width 0.3s ease;
        }

        nav a:hover::after {
            width: 100%;
        }

        .cta-button {
            background: var(--primary);
            color: var(--white);
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .cta-button:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 102, 204, 0.3);
        }

        .hamburger {
            display: none;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            background: none;
            border: none;
        }

        .hamburger span {
            width: 25px;
            height: 3px;
            background: var(--text-dark);
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        .hamburger.active span:nth-child(1) {
            transform: rotate(45deg) translate(8px, 8px);
        }

        .hamburger.active span:nth-child(2) {
            opacity: 0;
        }

        .hamburger.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }

        /* Hero Section */
        .hero {
            min-height: 90vh;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -100px;
            right: -100px;
        }

        .hero::after {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
            bottom: -50px;
            left: -50px;
        }

        .hero-content {
            text-align: center;
            z-index: 10;
            max-width: 800px;
            padding: 2rem;
            animation: fadeInUp 0.8s ease;
        }

        .hero h1 {
            font-size: 3.5rem;
            margin-bottom: 1rem;
            color: var(--white);
            font-weight: 800;
        }

        .hero p {
            font-size: 1.3rem;
            margin-bottom: 2rem;
            color: rgba(255, 255, 255, 0.95);
        }

        .hero-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-primary {
            background: var(--white);
            color: var(--primary);
            padding: 1rem 2.5rem;
            border-radius: 50px;
            font-weight: 700;
            text-decoration: none;
            transition: all 0.3s ease;
            border: 2px solid var(--white);
            display: inline-block;
            cursor: pointer;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }

        .btn-secondary {
            background: transparent;
            color: var(--white);
            padding: 1rem 2.5rem;
            border-radius: 50px;
            font-weight: 700;
            text-decoration: none;
            transition: all 0.3s ease;
            border: 2px solid var(--white);
            display: inline-block;
        }

        .btn-secondary:hover {
            background: var(--white);
            color: var(--primary);
        }

        /* Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        /* Section Styling */
        section {
            padding: 5rem 2rem;
        }

        .section-header {
            text-align: center;
            margin-bottom: 3rem;
        }

        .section-header h2 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }

        .section-header p {
            font-size: 1.1rem;
            color: var(--text-light);
            max-width: 600px;
            margin: 0 auto;
        }

        /* About Section */
        .about {
            background: var(--white);
        }

        .about-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            align-items: center;
        }

        .about-text h3 {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            color: var(--primary);
        }

        .about-text p {
            margin-bottom: 1rem;
            color: var(--text-light);
            line-height: 1.8;
        }

        .about-features {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .feature-item {
            display: flex;
            gap: 1rem;
        }

        .feature-item .icon {
            font-size: 2rem;
            flex-shrink: 0;
        }

        .about-image {
            background: linear-gradient(135deg, var(--primary-light) 0%, rgba(0, 180, 216, 0.1) 100%);
            border-radius: 15px;
            overflow: hidden;
            min-height: 400px;
        }

        .about-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Services Section */
        .services {
            background: var(--bg-light);
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .service-card {
            background: var(--white);
            border-radius: 12px;
            padding: 2rem;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid var(--border);
            cursor: pointer;
            animation: slideUp 0.6s ease backwards;
        }

        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0, 102, 204, 0.15);
            border-color: var(--primary);
        }

        .service-card .icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .service-card h3 {
            font-size: 1.3rem;
            margin-bottom: 1rem;
        }

        .service-card p {
            color: var(--text-light);
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }

        .service-price {
            background: var(--primary-light);
            color: var(--primary);
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
            font-weight: 700;
            display: inline-block;
        }

        /* Stats Section */
        .stats {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: var(--white);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            text-align: center;
        }

        .stat-item h3 {
            color: var(--white);
            font-size: 3rem;
            margin-bottom: 0.5rem;
        }

        .stat-item p {
            font-size: 1.1rem;
        }

        /* Gallery Section */
        .gallery {
            background: var(--white);
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
        }

        .gallery-item {
            position: relative;
            border-radius: 12px;
            overflow: hidden;
            cursor: pointer;
            aspect-ratio: 1 / 1;
            transition: transform 0.3s ease;
        }

        .gallery-item:hover {
            transform: scale(1.05);
        }

        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .gallery-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 102, 204, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .gallery-item:hover .gallery-overlay {
            opacity: 1;
        }

        .gallery-overlay-content {
            text-align: center;
            color: var(--white);
        }

        .gallery-overlay-content p {
            font-size: 0.9rem;
        }

        /* Testimonials Section */
        .testimonials {
            background: var(--bg-light);
        }

        .testimonials-slider {
            position: relative;
            max-width: 800px;
            margin: 0 auto;
        }

        .testimonial-item {
            display: none;
            opacity: 0;
            transition: opacity 0.5s ease;
            background: var(--white);
            padding: 3rem;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        }

        .testimonial-item.active {
            display: block;
            opacity: 1;
        }

        .testimonial-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin: 0 auto 1.5rem;
            object-fit: cover;
            border: 3px solid var(--primary);
        }

        .testimonial-rating {
            color: var(--warning);
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }

        .testimonial-text {
            font-style: italic;
            color: var(--text-light);
            margin-bottom: 1.5rem;
            font-size: 1.05rem;
        }

        .testimonial-name {
            font-weight: 700;
            color: var(--primary);
            font-size: 1.1rem;
        }

        .slider-controls {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-top: 2rem;
        }

        .slider-btn {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--border);
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .slider-btn.active {
            background: var(--primary);
            width: 35px;
            border-radius: 6px;
        }

        /* FAQ Section */
        .faq {
            background: var(--white);
        }

        .faq-container {
            max-width: 700px;
            margin: 0 auto;
        }

        .faq-item {
            margin-bottom: 1.5rem;
            border: 1px solid var(--border);
            border-radius: 8px;
            overflow: hidden;
        }

        .faq-question {
            background: var(--bg-light);
            padding: 1.5rem;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .faq-question:hover {
            background: var(--primary-light);
        }

        .faq-question.active {
            background: var(--primary);
            color: var(--white);
        }

        .faq-toggle {
            font-weight: 700;
            transition: transform 0.3s ease;
        }

        .faq-question.active .faq-toggle {
            transform: rotate(45deg);
        }

        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            background: var(--white);
        }

        .faq-answer.