<?php
session_start();
$page = $_GET["page"] ?? "home";
$action = $_POST["action"] ?? "";

// Database connection using SQLite
try {
    $db = new PDO('sqlite:' . dirname(__DIR__,2) . '/data/simple-connection-that.db' . __DIR__ . "/database.db");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create tables if they don't exist
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        phone TEXT,
        message TEXT,
        user_type TEXT,
        password TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    $db->exec("CREATE TABLE IF NOT EXISTS admin_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        site_name TEXT DEFAULT 'UserHub',
        site_phone TEXT DEFAULT '+254712345678',
        site_email TEXT DEFAULT 'info@userhub.com',
        site_address TEXT DEFAULT 'Nairobi, Kenya',
        whatsapp TEXT DEFAULT '254712345678',
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Seed admin settings if empty
    $settingsCheck = $db->query("SELECT COUNT(*) FROM admin_settings")->fetchColumn();
    if ($settingsCheck == 0) {
        $db->exec("INSERT INTO admin_settings (site_name, site_phone, site_email, site_address, whatsapp) 
                   VALUES ('UserHub', '+254712345678', 'info@userhub.com', 'Nairobi, Kenya', '254712345678')");
    }
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get site settings
$settings = $db->query("SELECT * FROM admin_settings LIMIT 1")->fetch(PDO::FETCH_ASSOC);

// Handle form submissions
$flash_message = "";
$flash_type = "";

if ($action === "register") {
    $name = htmlspecialchars($_POST["name"] ?? "");
    $email = htmlspecialchars($_POST["email"] ?? "");
    $phone = htmlspecialchars($_POST["phone"] ?? "");
    $message = htmlspecialchars($_POST["message"] ?? "");
    $user_type = htmlspecialchars($_POST["user_type"] ?? "member");
    $password = htmlspecialchars($_POST["password"] ?? "");
    
    if (!empty($name) && !empty($email) && !empty($password) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $db->prepare("INSERT INTO users (name, email, phone, message, user_type, password) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $email, $phone, $message, $user_type, $hashed_password]);
            $_SESSION["flash_message"] = "? Registration successful! You can now login.";
            $_SESSION["flash_type"] = "success";
            header("Location: ?page=login");
            exit;
        } catch (PDOException $e) {
            $flash_message = "? Email already registered. Try another.";
            $flash_type = "error";
        }
    } else {
        $flash_message = "? Please fill all required fields correctly.";
        $flash_type = "error";
    }
}

if ($action === "user_login") {
    $email = htmlspecialchars($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    
    if (!empty($email) && !empty($password)) {
        try {
            $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user["password"])) {
                $_SESSION["user_logged_in"] = true;
                $_SESSION["user_id"] = $user["id"];
                $_SESSION["user_name"] = $user["name"];
                $_SESSION["user_email"] = $user["email"];
                $_SESSION["flash_message"] = "? Login successful! Welcome " . $user["name"] . ".";
                $_SESSION["flash_type"] = "success";
                header("Location: ?page=dashboard");
                exit;
            } else {
                $flash_message = "? Invalid email or password.";
                $flash_type = "error";
            }
        } catch (PDOException $e) {
            $flash_message = "? Login error. Please try again.";
            $flash_type = "error";
        }
    } else {
        $flash_message = "? Please fill all fields.";
        $flash_type = "error";
    }
}

if ($action === "user_logout") {
    session_destroy();
    $_SESSION = array();
    header("Location: ?page=home");
    exit;
}

if ($action === "admin_login") {
    $password = $_POST["password"] ?? "";
    if ($password === "admin123") {
        $_SESSION["admin_logged_in"] = true;
        $_SESSION["flash_message"] = "? Admin login successful.";
        $_SESSION["flash_type"] = "success";
        header("Location: ?page=admin");
        exit;
    } else {
        $_SESSION["flash_message"] = "? Invalid password.";
        $_SESSION["flash_type"] = "error";
    }
}

if ($action === "admin_logout") {
    unset($_SESSION["admin_logged_in"]);
    $_SESSION["flash_message"] = "? Logged out successfully.";
    $_SESSION["flash_type"] = "success";
    header("Location: ?page=home");
    exit;
}

if ($action === "delete_user" && isset($_SESSION["admin_logged_in"])) {
    $user_id = (int)($_POST["user_id"] ?? 0);
    if ($user_id > 0) {
        $db->prepare("DELETE FROM users WHERE id = ?")->execute([$user_id]);
        $_SESSION["flash_message"] = "? User deleted successfully.";
        $_SESSION["flash_type"] = "success";
        header("Location: ?page=admin&view=users");
        exit;
    }
}

if ($action === "update_settings" && isset($_SESSION["admin_logged_in"])) {
    $site_name = htmlspecialchars($_POST["site_name"] ?? "");
    $site_phone = htmlspecialchars($_POST["site_phone"] ?? "");
    $site_email = htmlspecialchars($_POST["site_email"] ?? "");
    $site_address = htmlspecialchars($_POST["site_address"] ?? "");
    $whatsapp = htmlspecialchars($_POST["whatsapp"] ?? "");
    
    $db->prepare("UPDATE admin_settings SET site_name = ?, site_phone = ?, site_email = ?, site_address = ?, whatsapp = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1")->execute([$site_name, $site_phone, $site_email, $site_address, $whatsapp]);
    $settings = $db->query("SELECT * FROM admin_settings LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $_SESSION["flash_message"] = "? Settings updated successfully.";
    $_SESSION["flash_type"] = "success";
    header("Location: ?page=admin&view=settings");
    exit;
}

// Get flash messages from session
if (isset($_SESSION["flash_message"])) {
    $flash_message = $_SESSION["flash_message"];
    $flash_type = $_SESSION["flash_type"];
    unset($_SESSION["flash_message"], $_SESSION["flash_type"]);
}

// Get statistics
$total_users = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$users_list = $db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
$view = $_GET["view"] ?? "dashboard";

// Redirect logged-in users trying to access login/register
if (isset($_SESSION["user_logged_in"]) && in_array($page, ["login", "register"])) {
    header("Location: ?page=dashboard");
    exit;
}

// Redirect non-logged-in users trying to access dashboard
if (!isset($_SESSION["user_logged_in"]) && $page === "dashboard") {
    header("Location: ?page=login");
    exit;
}

// Redirect non-admin users trying to access admin panel
if ($page === "admin" && !isset($_SESSION["admin_logged_in"])) {
    header("Location: ?page=admin-login");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="UserHub - Simple user registration and login platform. Save and manage user information securely.">
    <meta property="og:title" content="UserHub - User Registration Platform">
    <meta property="og:description" content="Register and login to manage your account securely">
    <meta property="og:image" content="https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&q=80">
    
    <title><?php echo htmlspecialchars($settings["site_name"]); ?> - User Registration Platform</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #1a2b4d;
            --primary-dark: #0f1821;
            --secondary: #00d4ff;
            --accent: #ff006e;
            --success: #00d084;
            --warning: #ffa500;
            --error: #ff0066;
            --bg: #0a0e27;
            --bg-2: #141b2f;
            --bg-3: #1e2749;
            --text: #f5f5f5;
            --text-muted: #b0b8c1;
            --border: #2a3a5a;
            --shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            --shadow-lg: 0 30px 100px rgba(0, 0, 0, 0.7);
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: "Space Grotesk", sans-serif;
            background: linear-gradient(135deg, var(--bg) 0%, var(--primary) 100%);
            color: var(--text);
            line-height: 1.6;
            overflow-x: hidden;
            min-height: 100vh;
        }

        /* Loading Screen */
        .loading-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            animation: slideOut 1.5s ease-out forwards;
        }

        @keyframes slideOut {
            0% { opacity: 1; transform: translateY(0); }
            90% { opacity: 1; }
            100% { opacity: 0; pointer-events: none; transform: translateY(-100%); }
        }

        .loading-content {
            text-align: center;
        }

        .loading-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, var(--secondary) 0%, var(--accent) 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }

        .loading-text {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, var(--secondary) 0%, var(--accent) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-family: "Playfair Display", serif;
        }

        /* Header & Navigation */
        header {
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(10, 14, 39, 0.8);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--border);
            transition: all 0.3s ease;
        }

        header.scrolled {
            padding: 8px 0;
            box-shadow: var(--shadow);
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px 40px;
        }

        .logo {
            font-family: "Playfair Display", serif;
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, var(--secondary) 0%, var(--accent) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--secondary) 0%, var(--accent) 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        nav ul {
            display: flex;
            gap: 40px;
            list-style: none;
        }

        nav a {
            color: var(--text-muted);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
        }

        nav a:hover,
        nav a.active {
            color: var(--secondary);
        }

        nav a.active::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--secondary) 0%, var(--accent) 100%);
            border-radius: 2px;
        }

        .nav-right {
            display: flex;
            gap: 20px;
            align-items: center;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--secondary) 0%, var(--accent) 100%);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-block;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(0, 212, 255, 0.3);
        }

        .btn-secondary {
            background: transparent;
            color: var(--secondary);
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            border: 2px solid var(--secondary);
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-block;
        }

        .btn-secondary:hover {
            background: var(--secondary);
            color: var(--bg);
        }

        .hamburger {
            display: none;
            flex-direction: column;
            gap: 6px;
            background: none;
            border: none;
            cursor: pointer;
            padding: 0;
        }

        .hamburger span {
            width: 25px;
            height: 3px;
            background: var(--secondary);
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        /* Flash Messages */
        .flash-message {
            position: fixed;
            top: 100px;
            right: 20px;
            padding: 16px 24px;
            border-radius: 12px;
            font-weight: 600;
            z-index: 1000;
            animation: slideIn 0.4s ease-out;
            max-width: 500px;
        }

        .flash-message.success {
            background: var(--success);
            color: white;
        }

        .flash-message.error {
            background: var(--error);
            color: white;
        }

        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        /* Forms */
        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text);
        }

        input, textarea, select {
            width: 100%;
            padding: 12px 16px;
            background: var(--bg-2);
            border: 2px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-family: inherit;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: var(--secondary);
            background: var(--bg-3);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .form-error {
            color: var(--error);
            font-size: 12px;
            margin-top: 4px;
        }

        /* Main Content */
        main {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px;
        }

        .container {
            background: var(--bg-2);
            border-radius: 16px;
            padding: 40px;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
        }

        h1, h2, h3 {
            font-family: "Playfair Display", serif;
            margin-bottom: 20px;
            background: linear-gradient(135deg, var(--secondary) 0%, var(--accent) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .welcome-section {
            text-align: center;
            margin-bottom: 40px;
        }

        .welcome-hero {
            background: linear-gradient(135deg, rgba(0, 212, 255, 0.1) 0%, rgba(255, 0, 110, 0.1) 100%);
            border-radius: 16px;
            padding: 60px 40px;
            border: 1px solid var(--border);
            margin-bottom: 40px;
            animation: fadeIn 0.6s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .welcome-hero h1 {
            font-size: 48px;
            margin-bottom: 10px;
        }

        .welcome-hero p {
            font-size: 18px;
            color: var(--text-muted);
            margin-bottom: 30px;
        }

        .user-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: linear-gradient(135deg, var(--bg-3) 0%, rgba(0, 212, 255, 0.05) 100%);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            text-align: center;
        }

        .stat-card h3 {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .stat-card p {
            color: var(--text-muted);
            font-size: 14px;
        }

        .form-container {
            max-width: 500px;
            margin: 0 auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }

        th {
            background: var(--bg-3);
            font-weight: 600;
            color: var(--secondary);
        }

        tr:hover {
            background: rgba(0, 212, 255, 0.05);
        }

        .btn-danger {
            background: var(--error);
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-size: 12px;
            transition: all 0.3s ease;
        }

        .btn-danger:hover {
            background: #ff0055;
        }

        .btn-secondary-small {
            background: var(--bg-3);
            color: var(--secondary);
            padding: 8px 16px;
            border-radius: 6px;
            border: 1px solid var(--secondary);
            cursor: pointer;
            font-weight: 600;
            font-size: 12px;
            transition: all 0.3s ease;
        }

        .btn-secondary-small:hover {
            background: var(--secondary);
            color: var(--bg);
        }

        /* Admin Panel */
        .admin-nav {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 20px;
        }

        .admin-nav button {
            background: transparent;
            color: var(--text-muted);
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            font-weight: 600;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
        }

        .admin-nav button.active {
            color: var(--secondary);
            border-bottom-color: var(--secondary);
        }

        .admin-section {
            display: none;
        }

        .admin-section.active {
            display: block;
            animation: fadeIn 0.3s ease-out;
        }

        /* Responsive */
        @media (max-width: 768px) {
            nav {
                padding: 15px 20px;
            }

            nav ul {
                display: none;
            }

            .hamburger {
                display: flex;
            }

            nav ul.active {
                display: flex;
                flex-direction: column;
                position: absolute;
                top: 60px;
                left: 0;
                right: 0;
                background: var(--bg-2);
                border-bottom: 1px solid var(--border);
                padding: 20px;
                gap: 15px;
            }

            main {
                padding: 20px;
            }

            .container {
                padding: 20px;
            }

            .welcome-hero {
                padding: 30px 20px;
            }

            .welcome-hero h1 {
                font-size: 32px;
            }

            .user-stats {
                grid-template-columns: 1fr;
            }

            table {
                font-size: 12px;
            }

            th, td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="loading-screen">
        <div class="loading-content">
            <div class="loading-logo">?</div>
            <div class="loading-text"><?php echo htmlspecialchars($settings["site_name"]); ?></div>
        </div>
    </div>

    <?php if (!empty($flash_message)): ?>
    <div class="flash-message <?php echo $flash_type; ?>">
        <?php echo htmlspecialchars($flash_message); ?>
    </div>
    <?php endif; ?>

    <header>
        <nav>
            <a href="?page=home" class="logo">
                <div class="logo-icon">?</div>
                <?php echo htmlspecialchars($settings["site_name"]); ?>
            </a>
            <ul>
                <li><a href="?page=home" class="<?php echo $page === 'home' ? 'active' : ''; ?>">Home</a></li>
                <li><a href="?page=about" class="<?php echo $page === 'about' ? 'active' : ''; ?>">About</a></li>
                <li><a href="?page=contact" class="<?php echo $page === 'contact' ? 'active' : ''; ?>">Contact</a></li>
                <?php if (isset($_SESSION["user_logged_in"])): ?>
                <li><a href="?page=dashboard" class="<?php echo $page === 'dashboard' ? 'active' : ''; ?>">Dashboard</a></li>
                <?php else: ?>
                <li><a href="?page=login" class="<?php echo $page === 'login' ? 'active' : ''; ?>">Login</a></li>
                <?php endif; ?>
                <li><a href="?page=admin-login" class="<?php echo $page === 'admin-login' ? 'active' : ''; ?>">Admin</a></li>
            </ul>
            <div class="nav-right">
                <?php if (isset($_SESSION["user_logged_in"])): ?>
                <span style="color: var(--secondary); font-weight: 600;">Welcome, <?php echo htmlspecialchars($_SESSION["user_name"]); ?></span>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="user_logout">
                    <button type="submit" class="btn-secondary">Logout</button>
                </form>
                <?php elseif (isset($_SESSION["admin_logged_in"])): ?>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="admin_logout">
                    <button type="submit" class="btn-secondary">Logout Admin</button>
                </form>
                <?php else: ?>
                <a href="?page=register" class="btn-primary">Register</a>
                <a href="?page=login" class="btn-secondary">Login</a>
                <?php endif; ?>
            </div>
            <button class="hamburger" onclick="toggleMenu()">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </nav>
    </header>

    <main>
        <?php if ($page === "home"): ?>
        <div class="welcome-section">
            <div class="welcome-hero">
                <h1>Welcome to <?php echo htmlspecialchars($settings["site_name"]); ?></h1>
                <p>Your secure user registration and management platform</p>
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <a href="?page=register" class="btn-primary">Get Started</a>
                    <a href="?page=about" class="btn-secondary">Learn More</a>
                </div>
            </div>

            <div class="user-stats">
                <div class="stat-card">
                    <h3><?php echo $total_users; ?></h3>
                    <p>Total Users</p>
                </div>
                <div class="stat-card">
                    <h3>24/7</h3>
                    <p>Available Service</p>
                </div>
                <div class="stat-card">
                    <h3>100%</h3>
                    <p>Data Security</p>
                </div>
                <div class="stat-card">
                    <h3>Free</h3>
                    <p>To Register</p>
                </div>
            </div>
        </div>

        <div class="container">
            <h2>Features</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 20px;">
                <div style="padding: 20px; background: var(--bg-3); border-radius: 12px; border-left: 4px solid var(--secondary);">
                    <h3 style="color: var(--secondary); margin-bottom: 10px;">? Secure</h3>
                    <p>Your data is encrypted and stored securely in our database.</p>
                </div>
                <div style="padding: 20px; background: var(--bg-3); border-radius: 12px; border-left: 4px solid var(--accent);">
                    <h3 style="color: var(--accent); margin-bottom: 10px;">? Fast</h3>
                    <p>Lightning-fast registration and login process.</p>
                </div>
                <div style="padding: 20px; background: var(--bg-3); border-radius: 12px; border-left: 4px solid var(--success);">
                    <h3 style="color: var(--success); margin-bottom: 10px;">? Responsive</h3>
                    <p>Works perfectly on all devices and screen sizes.</p>
                </div>
            </div>
        </div>

        <?php elseif ($page === "register"): ?>
        <div class="container" style="max-width: 500px; margin: 0 auto;">
            <h1>Create Account</h1>
            <form method="POST" class="form-container">
                <input type="hidden" name="action" value="register">
                
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="name" required placeholder="Enter your full name">
                </div>

                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required placeholder="Enter your email">
                </div>

                <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" name="phone" placeholder="Enter your phone number">
                </div>

                <div class="form-group">
                    <label>Password *</label>
                    <input type="password" name="password" required placeholder="Create a strong password">
                </div>

                <div class="form-group">
                    <label>User Type</label>
                    <select name="user_type">
                        <option value="member">Member</option>
                        <option value="business">Business</option>
                        <option value="organization">Organization</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Message</label>
                    <textarea name="message" rows="4" placeholder="Tell us about yourself..."></textarea>
                </div>

                <button type="submit" class="btn-primary" style="width: 100%;">Register</button>

                <p style="text-align: center; margin-top: 20px; color: var(--text-muted);">
                    Already have an account? <a href="?page=login" style="color: var(--secondary);">Login here</a>
                </p>
            </form>
        </div>

        <?php elseif ($page === "login"): ?>
        <div class="container" style="max-width: 500px; margin: 0 auto;">
            <h1>Login</h1>
            <form method="POST" class="form-container">
                <input type="hidden" name="action" value="user_login">
                
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required placeholder="Enter your email">
                </div>

                <div class="form-group">
                    <label>Password *</label>
                    <input type="password" name="password" required placeholder="Enter your password">
                </div>

                <button type="submit" class="btn-primary" style="width: 100%;">Login</button>

                <p style="text-align: center; margin-top: 20px; color: var(--text-muted);">
                    Don't have an account? <a href="?page=register" style="color: var(--secondary);">Register here</a>
                </p>
            </form>
        </div>

        <?php elseif ($page === "dashboard"): ?>
        <div class="welcome-section">
            <div class="welcome-hero">
                <h1>Welcome to Your Dashboard</h1>
                <p><?php echo htmlspecialchars($_SESSION["user_name"]); ?></p>
                <p style="color: var(--text-muted); margin-top: 10px;"><?php echo htmlspecialchars($_SESSION["user_email"]); ?></p>
            </div>
        </div>

        <div class="container">
            <h2>Account Information</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-top: 20px;">
                <div style="padding: 20px; background: var(--bg-3); border-radius: 12px;">
                    <p style="color: var(--text-muted); font-size: 12px;">Full Name</p>
                    <h3 style="color: var(--secondary); margin-top: 5px;"><?php echo htmlspecialchars($_SESSION["user_name"]); ?></h3>
                </div>
                <div style="padding: 20px; background: var(--bg-3); border-radius: 12px;">
                    <p style="color: var(--text-muted); font-size: 12px;">Email Address</p>
                    <h3 style="color: var(--secondary); margin-top: 5px;"><?php echo htmlspecialchars($_SESSION["user_email"]); ?></h3>
                </div>
                <div style="padding: 20px; background: var(--bg-3); border-radius: 12px;">
                    <p style="color: var(--text-muted); font-size: 12px;">User ID</p>
                    <h3 style="color: var(--secondary); margin-top: 5px;"><?php echo htmlspecialchars($_SESSION["user_id"]); ?></h3>
                </div>
            </div>
        </div>

        <div class="container" style="margin-top: 30px;">
            <h2>Quick Actions</h2>
            <div style="display: flex; gap: 15px; margin-top: 20px; flex-wrap: wrap;">
                <a href="?page=contact" class="btn-primary">Send Message</a>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="user_logout">
                    <button type="submit" class="btn-secondary">Logout</button>
                </form>
            </div>
        </div>

        <?php elseif ($page === "admin-login"): ?>
        <div class="container" style="max-width: 500px; margin: 0 auto;">
            <h1>Admin Login</h1>
            <form method="POST" class="form-container">
                <input type="hidden" name="action" value="admin_login">
                
                <div class="form-group">
                    <label>Admin Password *</label>
                    <input type="password" name="password" required placeholder="Enter admin password">
                </div>

                <button type="submit" class="btn-primary" style="width: 100%;">Login as Admin</button>

                <p style="text-align: center; margin-top: 20px; color: var(--text-muted); font-size: 12px;">
                    Default password: <strong>admin123</strong>
                </p>
            </form>
        </div>

        <?php elseif ($page === "admin" && isset($_SESSION["admin_logged_in"])): ?>
        <div class="container">
            <h1>Admin Dashboard</h1>

            <div class="user-stats" style="margin: 30px 0;">
                <div class="stat-card">
                    <h3><?php echo $total_users; ?></h3>
                    <p>Total Users</p>
                </div>
                <div class="stat-card">
                    <h3><?php echo count(array_filter($users_list, fn($u) => $u["user_type"] === "member")); ?></h3>
                    <p>Members</p>
                </div>
                <div class="stat-card">
                    <h3><?php echo count(array_filter($users_list, fn($u) => $u["user_type"] === "business")); ?></h3>
                    <p>Businesses</p>
                </div>
                <div class="stat-card">
                    <h3><?php echo count(array_filter($users_list, fn($u) => $u["user_type"] === "organization")); ?></h3>
                    <p>Organizations</p>
                </div>
            </div>

            <div class="admin-nav">
                <button onclick="switchAdminTab('dashboard')" class="active">Dashboard</button>
                <button onclick="switchAdminTab('users')">Manage Users</button>
                <button onclick="switchAdminTab('settings')">Settings</button>
            </div>

            <!-- Dashboard Section -->
            <div id="dashboard" class="admin-section active">
                <h2>Dashboard Overview</h2>
                <p style="color: var(--text-muted); margin: 20px 0;">Welcome to the admin panel. Manage all users and system settings below.</p>
            </div>

            <!-- Users Section -->
            <div id="users" class="admin-section">
                <h2>Manage Users</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Type</th>
                            <th>Phone</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users_list as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user["id"]); ?></td>
                            <td><?php echo htmlspecialchars($user["name"]); ?></td>
                            <td><?php echo htmlspecialchars($user["email"]); ?></td>
                            <td><?php echo htmlspecialchars($user["user_type"]); ?></td>
                            <td><?php echo htmlspecialchars($user["phone"] ?? "N/A"); ?></td>
                            <td>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this user?');">
                                    <input type="hidden" name="action" value="delete_user">
                                    <input type="hidden" name="user_id" value="<?php echo $user["id"]; ?>">
                                    <button type="submit" class="btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Settings Section -->
            <div id="settings" class="admin-section">
                <h2>Site Settings</h2>
                <form method="POST" style="max-width: 600px;">
                    <input type="hidden" name="action" value="update_settings">
                    
                    <div class="form-group">
                        <label>Site Name</label>
                        <input type="text" name="site_name" value="<?php echo htmlspecialchars($settings["site_name"]); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="site_phone" value="<?php echo htmlspecialchars($settings["site_phone"]); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="site_email" value="<?php echo htmlspecialchars($settings["site_email"]); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" name="site_address" value="<?php echo htmlspecialchars($settings["site_address"]); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>WhatsApp Number</label>
                        <input type="text" name="whatsapp" value="<?php echo htmlspecialchars($settings["whatsapp"]); ?>" placeholder="254712345678" required>
                    </div>

                    <button type="submit" class="btn-primary">Save Settings</button>
                </form>
            </div>
        </div>

        <?php elseif ($page === "about"): ?>
        <div class="container">
            <h1>About Us</h1>
            <p style="font-size: 16px; line-height: 1.8; color: var(--text-muted); margin: 20px 0;">
                <?php echo htmlspecialchars($settings["site_name"]); ?> is a secure, user-friendly platform designed to simplify user registration and data management. Our platform prioritizes security, speed, and ease of use.
            </p>

            <h2 style="margin-top: 40px;">Contact Information</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 20px 0;">
                <div style="padding: 20px; background: var(--bg-3); border-radius: 12px;">
                    <h3 style="color: var(--secondary); margin-bottom: 10px;">? Phone</h3>
                    <p><?php echo htmlspecialchars($settings["site_phone"]); ?></p>
                </div>
                <div style="padding: 20px; background: var(--bg-3); border-radius: 12px;">
                    <h3 style="color: var(--secondary); margin-bottom: 10px;">? Email</h3>
                    <p><?php echo htmlspecialchars($settings["site_email"]); ?></p>
                </div>
                <div style="padding: 20px; background: var(--bg-3); border-radius: 12px;">
                    <h3 style="color: var(--secondary); margin-bottom: 10px;">? Location</h3>
                    <p><?php echo htmlspecialchars($settings["site_address"]); ?></p>
                </div>
            </div>
        </div>

        <?php elseif ($page === "contact"): ?>
        <div class="container" style="max-width: 600px; margin: 0 auto;">
            <h1>Contact Us</h1>
            <p style="color: var(--text-muted); margin-bottom: 30px;">Have a question or suggestion? We'd love to hear from you. Fill out the form below and we'll get back to you as soon as possible.</p>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 40px;">
                <div style="text-align: center;">
                    <p style="color: var(--text-muted); font-size: 12px; margin-bottom: 5px;">Phone</p>
                    <h3 style="color: var(--secondary);"><?php echo htmlspecialchars($settings["site_phone"]); ?></h3>
                </div>
                <div style="text-align: center;">
                    <p style="color: var(--text-muted); font-size: 12px; margin-bottom: 5px;">Email</p>
                    <h3 style="color: var(--secondary);"><?php echo htmlspecialchars($settings["site_email"]); ?></h3>
                </div>
                <div style="text-align: center;">
                    <p style="color: var(--text-muted); font-size: 12px; margin-bottom: 5px;">Location</p>
                    <h3 style="color: var(--secondary);"><?php echo htmlspecialchars($settings["site_address"]); ?></h3>
                </div>
            </div>

            <h2>Send us a Message</h2>
            <div style="padding: 20px; background: linear-gradient(135deg, rgba(0, 212, 255, 0.05) 0%, rgba(255, 0, 110, 0.05) 100%); border-radius: 12px; border: 1px solid var(--border); margin: 30px 0;">
                <p style="color: var(--text-muted); text-align: center;">
                    Or chat with us on WhatsApp: <br>
                    <a href="https://wa.me/<?php echo htmlspecialchars($settings["whatsapp"]); ?>" target="_blank" class="btn-primary" style="margin-top: 15px;">Open WhatsApp</a>
                </p>
            </div>
        </div>

        <?php else: ?>
        <div class="container">
            <h1>Page Not Found</h1>
            <p>The page you're looking for doesn't exist.</p>
            <a href="?page=home" class="btn-primary">Go Home</a>
        </div>
        <?php endif; ?>
    </main>

    <footer style="background: var(--bg-2); border-top: 1px solid var(--border); padding: 40px; text-align: center; margin-top: 60px; color: var(--text-muted);">
        <p>&copy; 2024 <?php echo htmlspecialchars($settings["site_name"]); ?>. All rights reserved.</p>
        <p style="font-size: 12px; margin-top: 10px;">
            <a href="?page=home" style="color: var(--secondary); text-decoration: none;">Home</a> | 
            <a href="?page=about" style="color: var(--secondary); text-decoration: none;">About</a> | 
            <a href="?page=contact" style="color: var(--secondary); text-decoration: none;">Contact</a> | 
            <a href="?page=admin-login" style="color: var(--secondary); text-decoration: none;">Admin</a>
        </p>
    </footer>

    <script>
        // Mobile menu toggle
        function toggleMenu() {
            const nav = document.querySelector('nav ul');
            nav.classList.toggle('active');
        }

        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });

        // Admin tab switching
        function switchAdminTab(tabName) {
            const sections = document.querySelectorAll('.admin-section');
            sections.forEach(section => section.classList.remove('active'));
            
            const buttons = document.querySelectorAll('.admin-nav button');
            buttons.forEach(btn => btn.classList.remove('active'));
            
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }

        // Auto-hide flash messages after 5 seconds
        setTimeout(function() {
            const flash = document.querySelector('.flash-message');
            if (flash) {
                flash.style.animation = 'slideOut 0.4s ease-out forwards';
                setTimeout(() => flash.remove(), 400);
            }
        }, 5000);

        // Active link highlighting
        document.addEventListener('DOMContentLoaded', function() {
            const currentPage = new URLSearchParams(window.location.search).get('page') || 'home';
            document.querySelectorAll('nav a').forEach(link => {
                if (link.href.includes('page=' + currentPage)) {
                    link.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>
