<?php
session_start();
$page = $_GET['page'] ?? 'home';

// SQLite database
$db = new PDO('sqlite:' . __DIR__ . '/site_data.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec('PRAGMA journal_mode=WAL');

// Create tables
$db->exec("CREATE TABLE IF NOT EXISTS menu_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT,
  name TEXT,
  description TEXT,
  price TEXT,
  spice_level TEXT,
  image_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS gallery (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT,
  image_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  email TEXT,
  phone TEXT,
  message TEXT,
  is_read INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS testimonials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  role TEXT,
  message TEXT,
  rating INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS admin_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE,
  password TEXT
)");

// Seed data on first run
$count = $db->query("SELECT COUNT(*) FROM menu_items")->fetchColumn();
if ($count == 0) {
  // Menu items
  $menuItems = [
    ['Appetizers', 'Samosa Trio', 'Crispy pastries with potato, pea & meat filling', '450 KES', 'Medium', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500&h=500&fit=crop'],
    ['Appetizers', 'Paneer Tikka', 'Marinated cottage cheese with Indian spices', '550 KES', 'Medium', 'https://images.unsplash.com/photo-1599599810694-b5ac4dd0c4b7?w=500&h=500&fit=crop'],
    ['Appetizers', 'Tandoori Prawns', 'Succulent prawns cooked in tandoor', '750 KES', 'High', 'https://images.unsplash.com/photo-1580959375944-abd7e991f971?w=500&h=500&fit=crop'],
    ['Appetizers', 'Onion Bhajia', 'Golden fried onion fritters', '350 KES', 'Low', 'https://images.unsplash.com/photo-1585238341710-4b8b44e6e413?w=500&h=500&fit=crop'],
    
    ['Main Courses', 'Butter Chicken', 'Tender chicken in creamy tomato sauce', '850 KES', 'Medium', 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=500&h=500&fit=crop'],
    ['Main Courses', 'Lamb Biryani', 'Fragrant rice with tender lamb pieces', '950 KES', 'Medium', 'https://images.unsplash.com/photo-1585937421456-de714db1639a?w=500&h=500&fit=crop'],
    ['Main Courses', 'Malai Kofta', 'Creamy cottage cheese dumplings in sauce', '750 KES', 'Low', 'https://images.unsplash.com/photo-1596899261852-6383f95caea6?w=500&h=500&fit=crop'],
    ['Main Courses', 'Fish Tikka Masala', 'Spiced fish in coconut-tomato gravy', '1050 KES', 'High', 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&h=500&fit=crop'],
    ['Main Courses', 'Chole Bhature', 'Chickpea curry with fried bread', '550 KES', 'Medium', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500&h=500&fit=crop'],
    
    ['Breads', 'Naan', 'Traditional Indian bread', '120 KES', 'Low', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500&h=500&fit=crop'],
    ['Breads', 'Garlic Naan', 'Naan with garlic & herb butter', '150 KES', 'Low', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500&h=500&fit=crop'],
    ['Breads', 'Puri', 'Light fried bread', '100 KES', 'Low', 'https://images.unsplash.com/photo-1585938389850-a91f2f146e6d?w=500&h=500&fit=crop'],
    
    ['Desserts', 'Gulab Jamun', 'Milk solids in rose syrup', '300 KES', 'Low', 'https://images.unsplash.com/photo-1585314062340-f80a5a684b0a?w=500&h=500&fit=crop'],
    ['Desserts', 'Kheer', 'Rice pudding with cardamom', '280 KES', 'Low', 'https://images.unsplash.com/photo-1571115764595-644a262f3f3d?w=500&h=500&fit=crop'],
    ['Desserts', 'Mango Kulfi', 'Frozen Indian dessert', '250 KES', 'Low', 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=500&h=500&fit=crop'],
    
    ['Beverages', 'Mango Lassi', 'Yogurt drink with fresh mango', '220 KES', 'Low', 'https://images.unsplash.com/photo-1553530889-e6cf89d29f6b?w=500&h=500&fit=crop'],
    ['Beverages', 'Chai Masala', 'Spiced Indian tea', '150 KES', 'Medium', 'https://images.unsplash.com/photo-1597318972826-0b7d949cf662?w=500&h=500&fit=crop'],
  ];

  $stmt = $db->prepare("INSERT INTO menu_items (category, name, description, price, spice_level, image_url) VALUES (?, ?, ?, ?, ?, ?)");
  foreach ($menuItems as $item) {
    $stmt->execute($item);
  }

  // Gallery
  $gallery = [
    ['Ambiance', 'https://images.unsplash.com/photo-1514432324607-2e467f4af445?w=800&h=600&fit=crop'],
    ['Signature Dishes', 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&h=600&fit=crop'],
    ['Chef Preparation', 'https://images.unsplash.com/photo-1556910103-1c02745aefb4?w=800&h=600&fit=crop'],
    ['Fine Dining', 'https://images.unsplash.com/photo-1504674900927-8d64d4469a1d?w=800&h=600&fit=crop'],
    ['Food Art', 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&h=600&fit=crop'],
    ['Restaurant Interior', 'https://images.unsplash.com/photo-1517991104123-ae2fc214000d?w=800&h=600&fit=crop'],
    ['Cocktails', 'https://images.unsplash.com/photo-1608715649722-c1a4b61e7a3a?w=800&h=600&fit=crop'],
    ['Plating Details', 'https://images.unsplash.com/photo-1495898403636-c1d632066055?w=800&h=600&fit=crop'],
  ];

  $stmt = $db->prepare("INSERT INTO gallery (title, image_url) VALUES (?, ?)");
  foreach ($gallery as $item) {
    $stmt->execute($item);
  }

  // Testimonials
  $testimonials = [
    ['Kariuki Mwangi', 'Food Critic', 'The best Indian cuisine in Nairobi. Authentic flavors, exquisite presentation, and impeccable service. A culinary masterpiece!', 5],
    ['Sarah Njoroge', 'Business Executive', 'Perfect place for business dinners and special occasions. The ambiance is luxurious and the food is absolutely divine.', 5],
    ['David Kipchoge', 'Chef', 'Exceptional spice blending and technique. The tandoor preparation is outstanding. Highly recommend to all spice lovers.', 5],
    ['Mary Ochieng', 'Food Blogger', 'Every dish tells a story of the Spice Route. The butter chicken is perfection, and their mango lassi is refreshing.', 4],
    ['James Koech', 'Tourism Guide', 'Brings the authentic taste of India to Nairobi. Visitors from all over the world love this place!', 5],
  ];

  $stmt = $db->prepare("INSERT INTO testimonials (name, role, message, rating) VALUES (?, ?, ?, ?)");
  foreach ($testimonials as $item) {
    $stmt->execute($item);
  }

  // Admin user
  $adminPass = password_hash('admin123', PASSWORD_DEFAULT);
  $db->prepare("INSERT INTO admin_users (username, password) VALUES (?, ?)")->execute(['admin', $adminPass]);
}

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  // Admin login
  if ($action === 'admin_login') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $db->prepare("SELECT password FROM admin_users WHERE username = ?");
    $stmt->execute([$username]);
    $result = $stmt->fetch();

    if ($result && password_verify($password, $result['password'])) {
      $_SESSION['admin_logged_in'] = true;
      header('Location: ?page=admin');
      exit;
    } else {
      $error_message = 'Invalid credentials';
    }
  }

  // Contact form
  if ($action === 'contact') {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');
    $phone = htmlspecialchars($_POST['phone'] ?? '');
    $message = htmlspecialchars($_POST['message'] ?? '');

    if ($name && $email && $message) {
      $stmt = $db->prepare("INSERT INTO messages (name, email, phone, message) VALUES (?, ?, ?, ?)");
      $stmt->execute([$name, $email, $phone, $message]);
      $success_message = 'Thank you! We will be in touch soon.';
    } else {
      $error_message = 'Please fill in all required fields.';
    }
  }

  // Admin: Add menu item
  if ($action === 'add_menu_item' && ($_SESSION['admin_logged_in'] ?? false)) {
    $category = htmlspecialchars($_POST['category'] ?? '');
    $name = htmlspecialchars($_POST['name'] ?? '');
    $description = htmlspecialchars($_POST['description'] ?? '');
    $price = htmlspecialchars($_POST['price'] ?? '');
    $spice_level = htmlspecialchars($_POST['spice_level'] ?? '');
    $image_url = htmlspecialchars($_POST['image_url'] ?? '');

    if ($category && $name && $price) {
      $stmt = $db->prepare("INSERT INTO menu_items (category, name, description, price, spice_level, image_url) VALUES (?, ?, ?, ?, ?, ?)");
      $stmt->execute([$category, $name, $description, $price, $spice_level, $image_url]);
      $success_message = 'Menu item added successfully';
    }
  }

  // Admin: Delete menu item
  if ($action === 'delete_menu_item' && ($_SESSION['admin_logged_in'] ?? false)) {
    $id = (int)($_POST['id'] ?? 0);
    $db->prepare("DELETE FROM menu_items WHERE id = ?")->execute([$id]);
    $success_message = 'Menu item deleted';
  }

  // Admin: Add gallery
  if ($action === 'add_gallery' && ($_SESSION['admin_logged_in'] ?? false)) {
    $title = htmlspecialchars($_POST['title'] ?? '');
    $image_url = htmlspecialchars($_POST['image_url'] ?? '');

    if ($title && $image_url) {
      $stmt = $db->prepare("INSERT INTO gallery (title, image_url) VALUES (?, ?)");
      $stmt->execute([$title, $image_url]);
      $success_message = 'Gallery image added';
    }
  }

  // Admin: Delete gallery
  if ($action === 'delete_gallery' && ($_SESSION['admin_logged_in'] ?? false)) {
    $id = (int)($_POST['id'] ?? 0);
    $db->prepare("DELETE FROM gallery WHERE id = ?")->execute([$id]);
    $success_message = 'Gallery image deleted';
  }
}

// Load data
$menuItems = $db->query("SELECT * FROM menu_items ORDER BY category, name")->fetchAll(PDO::FETCH_ASSOC);
$galleryItems = $db->query("SELECT * FROM gallery ORDER BY id DESC LIMIT 9")->fetchAll(PDO::FETCH_ASSOC);
$testimonials = $db->query("SELECT * FROM testimonials ORDER BY rating DESC")->fetchAll(PDO::FETCH_ASSOC);
$messages = $db->query("SELECT * FROM messages ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Spice Route Restaurant - Premium Indian Cuisine in Nairobi</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Montserrat:wght@400;500;600;700&display=swap');

    :root {
      --primary: #d4af37;
      --dark: #0a0a0a;
      --darker: #1a1a1a;
      --card-bg: #2a2a2a;
      --text: #e8e8e8;
      --text-light: #b0b0b0;
      --accent-red: #c41e3a;
      --accent-orange: #ff6b35;
      --success: #2ecc71;
      --danger: #e74c3c;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      background: var(--dark);
      color: var(--text);
      line-height: 1.6;
    }

    /* Header */
    header {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      background: rgba(10, 10, 10, 0.95);
      z-index: 1000;
      padding: 1rem 2rem;
      border-bottom: 1px solid rgba(212, 175, 55, 0.1);
      transition: all 0.3s ease;
    }

    header.scrolled {
      padding: 0.5rem 2rem;
      border-bottom: 1px solid var(--primary);
    }

    .header-container {
      max-width: 1400px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo {
      font-family: 'Playfair Display', serif;
      font-size: 1.8rem;
      color: var(--primary);
      text-decoration: none;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .logo::before {
      content: '🌶️';
      font-size: 1.5rem;
    }

    nav {
      display: flex;
      gap: 2rem;
      align-items: center;
    }

    nav a {
      color: var(--text);
      text-decoration: none;
      font-size: 0.95rem;
      font-weight: 500;
      transition: color 0.3s;
      position: relative;
    }

    nav a:hover,
    nav a.active {
      color: var(--primary);
    }

    nav a::after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 0;
      height: 2px;
      background: var(--primary);
      transition: width 0.3s;
    }

    nav a:hover::after,
    nav a.active::after {
      width: 100%;
    }

    .cta-btn {
      background: linear-gradient(135deg, var(--accent-red), var(--accent-orange));
      color: white;
      padding: 0.7rem 1.5rem;
      border-radius: 50px;
      text-decoration: none;
      font-weight: 600;
      transition: transform 0.3s, box-shadow 0.3s;
      display: inline-block;
      border: none;
      cursor: pointer;
    }

    .cta-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 25px rgba(196, 30, 58, 0.4);
    }

    .mobile-menu-btn {
      display: none;
      background: none;
      border: none;
      color: var(--primary);
      font-size: 1.5rem;
      cursor: pointer;
    }

    /* Hero */
    .hero {
      margin-top: 80px;
      min-height: 100vh;
      background: linear-gradient(135deg, rgba(10, 10, 10, 0.7), rgba(26, 26, 26, 0.7)), url('https://images.unsplash.com/photo-1504674900927-8d64d4469a1d?w=1600&h=900&fit=crop');
      background-size: cover;
      background-position: center;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .hero::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: radial-gradient(circle at 20% 50%, rgba(212, 175, 55, 0.1), transparent 50%);
      pointer-events: none;
    }

    .hero-content {
      position: relative;
      z-index: 2;
      max-width: 800px;
      animation: fadeInUp 1s ease-out;
    }

    .hero h1 {
      font-family: 'Playfair Display', serif;
      font-size: 4.5rem;
      font-weight: 900;
      margin-bottom: 1rem;
      color: var(--primary);
      text-shadow: 2px 2px 20px rgba(0, 0, 0, 0.8);
    }

    .hero .subtitle {
      font-size: 1.3rem;
      color: var(--text);
      margin-bottom: 2rem;
      font-weight: 300;
    }

    .hero-buttons {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
    }

    .btn-primary {
      background: linear-gradient(135deg, var(--accent-red), var(--accent-orange));
      color: white;
      padding: 1rem 2.5rem;
      border-radius: 50px;
      text-decoration: none;
      font-weight: 600;
      border: none;
      cursor: pointer;
      font-size: 1rem;
      transition: all 0.3s;
    }

    .btn-primary:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 40px rgba(196, 30, 58, 0.4);
    }

    .btn-secondary {
      background: transparent;
      color: var(--primary);
      padding: 1rem 2.5rem;
      border-radius: 50px;
      text-decoration: none;
      font-weight: 600;
      border: 2px solid var(--primary);
      cursor: pointer;
      font-size: 1rem;
      transition: all 0.3s;
    }

    .btn-secondary:hover {
      background: var(--primary);
      color: var(--dark);
      transform: translateY(-5px);
    }

    /* Container */
    .container {
      max-width: 1400px;
      margin: 0 auto;
      padding: 0 2rem;
    }

    /* Sections */
    section {
      padding: 5rem 2rem;
    }

    section.dark {
      background: var(--darker);
    }

    section.light {
      background: var(--dark);
    }

    .section-title {
      font-family: 'Playfair Display', serif;
      font-size: 3rem;
      font-weight: 900;
      text-align: center;
      margin-bottom: 1rem;
      color: var(--primary);
    }

    .section-subtitle {
      text-align: center;
      color: var(--text-light);
      margin-bottom: 3rem;
      font-size: 1.1rem;
    }

    /* About */
    .about-container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 3rem;
      align-items: center;
    }

    .about-text h2 {
      font-family: 'Playfair Display', serif;
      font-size: 2.5rem;
      margin-bottom: 1.5rem;
      color: var(--primary);
    }

    .about-text p {
      margin-bottom: 1.5rem;
      color: var(--text-light);
      font-size: 1.05rem;
    }

    .about-image {
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 20px 60px rgba(212, 175, 55, 0.2);
      aspect-ratio: 4/5;
      object-fit: cover;
    }

    /* Services/Menu */
    .menu-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
      margin-top: 3rem;
    }

    .menu-card {
      background: var(--card-bg);
      border-radius: 10px;
      overflow: hidden;
      transition: all 0.3s;
      border: 1px solid rgba(212, 175, 55, 0.1);
      cursor: pointer;
      display: flex;
      flex-direction: column;
    }

    .menu-card:hover {
      transform: translateY(-10px);
      border-color: var(--primary);
      box-shadow: 0 20px 40px rgba(212, 175, 55, 0.15);
    }

    .menu-card-image {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .menu-card-content {
      padding: 1.5rem;
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }

    .menu-card-name {
      font-family: 'Playfair Display', serif;
      font-size: 1.3rem;
      color: var(--primary);
      margin-bottom: 0.5rem;
    }

    .menu-card-desc {
      color: var(--text-light);
      font-size: 0.9rem;
      margin-bottom: 1rem;
      flex-grow: 1;
    }

    .menu-card-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 1rem;
      border-top: 1px solid rgba(212, 175, 55, 0.1);
    }

    .menu-price {
      font-family: 'Playfair Display', serif;
      font-size: 1.2rem;
      color: var(--accent-orange);
      font-weight: 700;
    }

    .spice-badge {
      padding: 0.3rem 0.8rem;
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 600;
    }

    .spice-low {
      background: rgba(46, 204, 113, 0.2);
      color: #2ecc71;
    }

    .spice-medium {
      background: rgba(241, 196, 15, 0.2);
      color: #f1c40f;
    }

    .spice-high {
      background: rgba(231, 76, 60, 0.2);
      color: #e74c3c;
    }

    /* Stats */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 2rem;
      margin-top: 3rem;
    }

    .stat-card {
      text-align: center;
      padding: 2rem;
      background: var(--card-bg);
      border-radius: 10px;
      border: 1px solid rgba(212, 175, 55, 0.1);
    }

    .stat-number {
      font-family: 'Playfair Display', serif;
      font-size: 3rem;
      color: var(--primary);
      margin-bottom: 0.5rem;
    }

    .stat-label {
      color: var(--text-light);
      font-size: 1rem;
    }

    /* Gallery */
    .gallery-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 1.5rem;
      margin-top: 3rem;
    }

    .gallery-item {
      position: relative;
      overflow: hidden;
      border-radius: 10px;
      aspect-ratio: 1;
      cursor: pointer;
      group;
    }

    .gallery-item img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.3s;
    }

    .gallery-item:hover img {
      transform: scale(1.1);
    }

    .gallery-overlay {
      position: absolute;
      inset: 0;
      background: rgba(0, 0, 0, 0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      transition: opacity 0.3s;
      color: var(--primary);
      font-size: 2rem;
    }

    .gallery-item:hover .gallery-overlay {
      opacity: 1;
    }

    /* Testimonials */
    .testimonial-container {
      position: relative;
      margin-top: 3rem;
    }

    .testimonial-card {
      background: var(--card-bg);
      padding: 2.5rem;
      border-radius: 10px;
      border-left: 4px solid var(--primary);
      min-height: 250px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      animation: fadeIn 0.8s ease-out;
    }

    .testimonial-text {
      color: var(--text-light);
      font-style: italic;
      margin-bottom: 1.5rem;
      font-size: 1.05rem;
    }

    .testimonial-author {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .author-info h4 {
      color: var(--primary);
      margin-bottom: 0.3rem;
    }

    .author-info p {
      color: var(--text-light);
      font-size: 0.9rem;
    }

    .stars {
      color: var(--primary);
      margin-bottom: 0.5rem;
    }

    /* FAQ */
    .faq-container {
      max-width: 700px;
      margin: 3rem auto 0;
    }

    .faq-item {
      background: var(--card-bg);
      margin-bottom: 1rem;
      border-radius: 10px;
      border: 1px solid rgba(212, 175, 55, 0.1);
      overflow: hidden;
      transition: all 0.3s;
    }

    .faq-item.active {
      border-color: var(--primary);
    }

    .faq-question {
      padding: 1.5rem;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-weight: 600;
      color: var(--primary);
      user-select: none;
      transition: