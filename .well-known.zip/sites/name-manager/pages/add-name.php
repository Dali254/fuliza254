<section class="add-name-section">
    <div class="container">
        <div class="form-wrapper">
            <h1>Add a New Name</h1>
            <p>Share a name with its origin and meaning with our community</p>

            <form method="POST" class="add-name-form">
                <div class="form-group">
                    <label for="name">Name *</label>
                    <input type="text" id="name" name="name" required placeholder="Enter the name" class="form-input">
                </div>

                <div class="form-group">
                    <label for="origin">Origin/Culture *</label>
                    <input type="text" id="origin" name="origin" required placeholder="e.g., Arabic, Hebrew, Indian" class="form-input">
                </div>

                <div class="form-group">
                    <label for="meaning">Meaning *</label>
                    <textarea id="meaning" name="meaning" required placeholder="Describe the meaning and significance of the name" class="form-textarea" rows="5"></textarea>
                </div>

                <button type="submit" name="add_name" class="btn btn-primary btn-block">Add Name</button>
            </form>
        </div>
    </div>
</section>

<?php
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_name'])):
    $name = sanitize($_POST['name'] ?? '');
    $origin = sanitize($_POST['origin'] ?? '');
    $meaning = sanitize($_POST['meaning'] ?? '');

    if(empty($name) || empty($origin) || empty($meaning)):
        flash_message('All fields are required', 'error');
    else:
        if(add_name($name, $origin, $meaning)):
            flash_message('Name added successfully!', 'success');
            redirect('index.php?page=add-name');
        else:
            flash_message('Error adding name. Please try again.', 'error');
        endif;
    endif;
endif;
?>