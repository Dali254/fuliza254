<section class="names-list-section">
    <div class="container">
        <div class="list-header">
            <h1>All Names</h1>
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="Search names..." class="search-input">
                <i class="fas fa-search"></i>
            </div>
        </div>

        <?php
        $page = isset($_GET['page_num']) ? max(1, intval($_GET['page_num'])) : 1;
        $limit = ITEMS_PER_PAGE;
        $offset = ($page - 1) * $limit;
        $total_names = count_names();
        $total_pages = ceil($total_names / $limit);
        
        $all_names = get_all_names($limit, $offset);
        ?>

        <div class="names-list-table">
            <?php if(!empty($all_names)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Origin</th>
                        <th>Meaning</th>
                        <th>Added Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($all_names as $name): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($name['name'] ?? 'N/A'); ?></strong></td>
                        <td><?php echo htmlspecialchars($name['origin'] ?? 'Not specified'); ?></td>
                        <td><?php echo htmlspecialchars(substr($name['meaning'] ?? 'Not specified', 0, 50) . (strlen($name['meaning'] ?? '') > 50 ? '...' : '')); ?></td>
                        <td><?php echo htmlspecialchars(date('M d, Y', strtotime($name['date_added'] ?? 'now'))); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="no-data">No names found. <a href="index.php?page=add-name">Add one now!</a></p>
            <?php endif; ?>
        </div>

        <?php if($total_pages > 1): ?>
        <div class="pagination">
            <?php if($page > 1): ?>
                <a href="index.php?page=names-list&page_num=1" class="page-link">First</a>
                <a href="index.php?page=names-list&page_num=<?php echo $page - 1; ?>" class="page-link">Previous</a>
            <?php endif; ?>

            <?php for($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                <a href="index.php?page=names-list&page_num=<?php echo $i; ?>" class="page-link <?php echo $i == $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>

            <?php if($page < $total_pages): ?>
                <a href="index.php?page=names-list&page_num=<?php echo $page + 1; ?>" class="page-link">Next</a>
                <a href="index.php?page=names-list&page_num=<?php echo $total_pages; ?>" class="page-link">Last</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</section>