<?php
defined('SITE_NAME')    || define('SITE_NAME',    'Name Manager');
defined('SITE_PHONE')   || define('SITE_PHONE',   '+254 700 000 000');
defined('SITE_EMAIL')   || define('SITE_EMAIL',   'info@name-manager.co.ke');
defined('SITE_ADDRESS') || define('SITE_ADDRESS', 'Nairobi, Kenya');
defined('WHATSAPP_NUM') || define('WHATSAPP_NUM', '254700000000');
defined('CURRENCY')     || define('CURRENCY',     'KES');
defined('SITE_URL')     || define('SITE_URL',     '');