<?php
require_admin();
?>

<section class="admin-names-section">
    <div class="container">
        <div class="section-header">
            <h1>Manage Names</h1>
            <a href="index.php?page=add-name" class="btn btn-primary">Add New Name</a>
        </div>

        <?php
        if(isset($_GET['delete']) && $_GET['delete']):
            $id = intval($_GET['delete']);
            if(delete_name($id)):
                flash_message('Name deleted successfully', 'success');
                redirect('index.php?page=admin-names');
            else:
                flash_message('Error deleting name', 'error');
            endif;
        endif;

        $all_names = get_all_names();
        ?>

        <div class="admin-table">
            <?php if(!empty($all_names)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Origin</th>
                        <th>Meaning</th>
                        <th>Date Added</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($all_names as $name): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($name['name'] ?? 'N/A'); ?></strong></td>
                        <td><?php echo htmlspecialchars($name['origin'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars(substr($name['meaning'] ?? 'N/A', 0, 40) . '...'); ?></td>
                        <td><?php echo htmlspecialchars(date('M d, Y', strtotime($name['date_added'] ?? 'now'))); ?></td>
                        <td>
                            <a href="index.php?page=admin-names&edit=<?php echo htmlspecialchars($name['id']); ?>" class="btn-action edit">Edit</a>
                            <a href="index.php?page=admin-names&delete=<?php echo htmlspecialchars($name['id']); ?>" onclick="return confirm('Are you sure?')" class="btn-action delete">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="no-data">No names found. <a href="index.php?page=add-name">Add one now!</a></p>
            <?php endif; ?>
        </div>
    </div>
</section>