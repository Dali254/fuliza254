<?php
session_start();

// Database setup
$dbPath = __DIR__ . '/site_data.db';
$db = new PDO('sqlite:' . $dbPath);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec('PRAGMA journal_mode=WAL');

// Create tables
$db->exec("CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    price TEXT NOT NULL,
    icon TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS gallery (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    image_url TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    message TEXT NOT NULL,
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS testimonials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    position TEXT NOT NULL,
    message TEXT NOT NULL,
    rating INTEGER DEFAULT 5,
    image_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS admin_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)");

// Seed sample data
$serviceCount = $db->query("SELECT COUNT(*) FROM services")->fetchColumn();
if ($serviceCount == 0) {
    $services = [
        ['Home Cleaning', 'Professional deep cleaning for your residential space. We use eco-friendly products and modern equipment to ensure your home is spotless and sanitized.', '5,000 - 15,000 KES', '🏠'],
        ['Office Cleaning', 'Commercial cleaning services for offices, corporate spaces, and business establishments. Daily, weekly, or monthly maintenance plans available.', '8,000 - 25,000 KES', '🏢'],
        ['Carpet Cleaning', 'Professional carpet and upholstery cleaning using advanced steam cleaning technology. Removes stains and allergens effectively.', '3,000 - 10,000 KES', '🧹'],
        ['Window Cleaning', 'Interior and exterior window cleaning for residential and commercial buildings. High-rise access available with safety certification.', '2,000 - 8,000 KES', '🪟'],
        ['Pest Control', 'Comprehensive pest control and fumigation services. Safe for families and pets. Monthly maintenance contracts available.', '4,000 - 12,000 KES', '🦟'],
        ['Garden Maintenance', 'Professional gardening, landscaping, and lawn care services. Regular maintenance or one-time projects.', '3,000 - 15,000 KES', '🌿'],
        ['Waste Management', 'Reliable waste collection and disposal services for homes and businesses. Eco-friendly recycling options available.', '1,500 - 6,000 KES', '♻️'],
        ['Disinfection Service', 'Advanced disinfection and sanitization using FDA-approved solutions. Perfect for offices, schools, and residential areas.', '6,000 - 18,000 KES', '🧼']
    ];
    
    foreach ($services as $service) {
        $db->prepare("INSERT INTO services (title, description, price, icon) VALUES (?, ?, ?, ?)")
            ->execute($service);
    }
}

$galleryCount = $db->query("SELECT COUNT(*) FROM gallery")->fetchColumn();
if ($galleryCount == 0) {
    $gallery = [
        ['Professional Office Space', 'https://images.unsplash.com/photo-1584622281867-8a748c99d3ea?w=500&h=500&fit=crop'],
        ['Modern Kitchen Cleaning', 'https://images.unsplash.com/photo-1600585152915-d92dbb6b0db0?w=500&h=500&fit=crop'],
        ['Bright Living Room', 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=500&h=500&fit=crop'],
        ['Luxury Bathroom', 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=500&h=500&fit=crop'],
        ['Garden Landscape', 'https://images.unsplash.com/photo-1585864299869-592a4a26d4d7?w=500&h=500&fit=crop'],
        ['Clean Workspace', 'https://images.unsplash.com/photo-1557804506-669714126472?w=500&h=500&fit=crop'],
        ['Sparkling Floors', 'https://images.unsplash.com/photo-1552883062-d811642cdeaa?w=500&h=500&fit=crop'],
        ['Window Perfection', 'https://images.unsplash.com/photo-1631679706909-1844bbd93628?w=500&h=500&fit=crop'],
        ['Green Maintenance', 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500&h=500&fit=crop']
    ];
    
    foreach ($gallery as $item) {
        $db->prepare("INSERT INTO gallery (title, image_url) VALUES (?, ?)")
            ->execute($item);
    }
}

$testimonialCount = $db->query("SELECT COUNT(*) FROM testimonials")->fetchColumn();
if ($testimonialCount == 0) {
    $testimonials = [
        ['James Mwangi', 'Business Owner, Nairobi', 'Pristine Care transformed our office! The team is professional, punctual, and thorough. Our employees love the clean workspace.', 5, 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'],
        ['Grace Kariuki', 'Homeowner, Westlands', 'I have been using their service for 6 months now. Consistent quality, fair pricing, and they are very friendly. Highly recommended!', 5, 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop'],
        ['David Kipchoge', 'Hotel Manager, Lavington', 'Professional service, reliable team, and excellent attention to detail. They handle our daily cleaning needs perfectly. Great partnership!', 5, 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop'],
        ['Sarah Okonkwo', 'School Principal, Karen', 'The disinfection service they provided during the pandemic was exceptional. Safe, efficient, and very professional team.', 5, 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop'],
        ['Peter Njoroge', 'Restaurant Owner, Upper Hill', 'Excellent pest control service! We have been pest-free for over a year now. Trustworthy and affordable.', 5, 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop']
    ];
    
    foreach ($testimonials as $testimonial) {
        $db->prepare("INSERT INTO testimonials (name, position, message, rating, image_url) VALUES (?, ?, ?, ?, ?)")
            ->execute($testimonial);
    }
}

$adminCount = $db->query("SELECT COUNT(*) FROM admin_users")->fetchColumn();
if ($adminCount == 0) {
    $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $db->prepare("INSERT INTO admin_users (username, password) VALUES (?, ?)")
        ->execute(['admin', $hashedPassword]);
}

// Handle POST requests
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'contact') {
        $name = htmlspecialchars($_POST['name'] ?? '');
        $email = htmlspecialchars($_POST['email'] ?? '');
        $phone = htmlspecialchars($_POST['phone'] ?? '');
        $msg = htmlspecialchars($_POST['message'] ?? '');
        
        if ($name && $email && $phone && $msg) {
            $db->prepare("INSERT INTO messages (name, email, phone, message) VALUES (?, ?, ?, ?)")
                ->execute([$name, $email, $phone, $msg]);
            $message = 'Thank you! Your message has been sent. We will contact you soon.';
            $messageType = 'success';
        } else {
            $message = 'Please fill all fields.';
            $messageType = 'error';
        }
    }
    
    if ($action === 'login') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        $admin = $db->prepare("SELECT * FROM admin_users WHERE username = ?")
            ->execute([$username])->fetch(PDO::FETCH_ASSOC);
        
        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            header('Location: ?page=admin');
            exit;
        } else {
            $message = 'Invalid username or password.';
            $messageType = 'error';
        }
    }
    
    if ($action === 'logout') {
        session_destroy();
        header('Location: ?page=admin');
        exit;
    }
    
    if ($action === 'add_service' && isset($_SESSION['admin_id'])) {
        $title = htmlspecialchars($_POST['title'] ?? '');
        $description = htmlspecialchars($_POST['description'] ?? '');
        $price = htmlspecialchars($_POST['price'] ?? '');
        $icon = htmlspecialchars($_POST['icon'] ?? '');
        
        if ($title && $description && $price && $icon) {
            $db->prepare("INSERT INTO services (title, description, price, icon) VALUES (?, ?, ?, ?)")
                ->execute([$title, $description, $price, $icon]);
            $message = 'Service added successfully!';
            $messageType = 'success';
        }
    }
    
    if ($action === 'delete_service' && isset($_SESSION['admin_id'])) {
        $id = intval($_POST['id'] ?? 0);
        $db->prepare("DELETE FROM services WHERE id = ?")->execute([$id]);
        $message = 'Service deleted.';
        $messageType = 'success';
    }
    
    if ($action === 'add_gallery' && isset($_SESSION['admin_id'])) {
        $title = htmlspecialchars($_POST['title'] ?? '');
        $image_url = htmlspecialchars($_POST['image_url'] ?? '');
        
        if ($title && $image_url) {
            $db->prepare("INSERT INTO gallery (title, image_url) VALUES (?, ?)")
                ->execute([$title, $image_url]);
            $message = 'Gallery item added!';
            $messageType = 'success';
        }
    }
    
    if ($action === 'delete_gallery' && isset($_SESSION['admin_id'])) {
        $id = intval($_POST['id'] ?? 0);
        $db->prepare("DELETE FROM gallery WHERE id = ?")->execute([$id]);
        $message = 'Gallery item deleted.';
        $messageType = 'success';
    }
    
    if ($action === 'mark_read' && isset($_SESSION['admin_id'])) {
        $id = intval($_POST['id'] ?? 0);
        $db->prepare("UPDATE messages SET is_read = 1 WHERE id = ?")->execute([$id]);
    }
    
    if ($action === 'delete_message' && isset($_SESSION['admin_id'])) {
        $id = intval($_POST['id'] ?? 0);
        $db->prepare("DELETE FROM messages WHERE id = ?")->execute([$id]);
    }
}

$page = $_GET['page'] ?? 'home';

// Fetch data
$services = $db->query("SELECT * FROM services ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
$gallery = $db->query("SELECT * FROM gallery ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
$testimonials = $db->query("SELECT * FROM testimonials ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
$messages = $db->query("SELECT * FROM messages ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
$unreadCount = $db->query("SELECT COUNT(*) FROM messages WHERE is_read = 0")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pristine Care - Professional Cleaning Services in Nairobi</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2ecc71;
            --primary-dark: #27ae60;
            --secondary: #3498db;
            --text-dark: #2c3e50;
            --text-light: #7f8c8d;
            --bg-light: #f8f9fa;
            --border: #ecf0f1;
            --success: #2ecc71;
            --error: #e74c3c;
            --white: #ffffff;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html {
            scroll-behavior: smooth;
        }
        
        body {
            font-family: 'Lato', sans-serif;
            color: var(--text-dark);
            line-height: 1.6;
            background-color: var(--white);
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            line-height: 1.3;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Header & Navigation */
        header {
            background: var(--white);
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
            transition: all 0.3s ease;
        }
        
        header.scrolled {
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }
        
        .logo {
            font-family: 'Poppins', sans-serif;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
        }
        
        .nav-menu {
            display: flex;
            gap: 2rem;
            list-style: none;
        }
        
        .nav-menu a {
            color: var(--text-dark);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
            position: relative;
        }
        
        .nav-menu a:hover {
            color: var(--primary);
        }
        
        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary);
            transition: width 0.3s ease;
        }
        
        .nav-menu a:hover::after {
            width: 100%;
        }
        
        .nav-menu a.active {
            color: var(--primary);
        }
        
        .hamburger {
            display: none;
            flex-direction: column;
            cursor: pointer;
        }
        
        .hamburger span {
            width: 25px;
            height: 3px;
            background: var(--text-dark);
            margin: 5px 0;
            transition: all 0.3s ease;
        }
        
        .hamburger.active span:nth-child(1) {
            transform: rotate(45deg) translate(8px, 8px);
        }
        
        .hamburger.active span:nth-child(2) {
            opacity: 0;
        }
        
        .hamburger.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }
        
        /* Hero Section */
        .hero {
            height: 100vh;
            background: linear-gradient(135deg, rgba(46, 204, 113, 0.8) 0%, rgba(52, 152, 219, 0.8) 100%), 
                        url('https://images.unsplash.com/photo-1584622261867-8a748c99d3ea?w=1200&h=1200&fit=crop');
            background-size: cover;
            background-position: center;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: var(--white);
            position: relative;
            overflow: hidden;
        }
        
        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(46, 204, 113, 0.4);
            animation: slideIn 1s ease-out;
        }
        
        .hero-content {
            position: relative;
            z-index: 10;
            max-width: 700px;
            animation: fadeIn 1s ease-out;
        }
        
        .hero h1 {
            font-size: 4rem;
            margin-bottom: 1rem;
            font-weight: 700;
        }
        
        .hero p {
            font-size: 1.3rem;
            margin-bottom: 2rem;
            opacity: 0.95;
        }
        
        .cta-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn {
            display: inline-block;
            padding: 0.8rem 2rem;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }
        
        .btn-primary {
            background: var(--primary);
            color: var(--white);
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(46, 204, 113, 0.3);
        }
        
        .btn-secondary {
            background: var(--white);
            color: var(--primary);
            border: 2px solid var(--white);
        }
        
        .btn-secondary:hover {
            background: transparent;
            transform: translateY(-2px);
        }
        
        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }
        
        .btn-danger {
            background: var(--error);
            color: var(--white);
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        /* Sections */
        section {
            padding: 5rem 0;
        }
        
        section.dark {
            background: var(--bg-light);
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 3rem;
        }
        
        .section-title h2 {
            font-size: 2.5rem;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }
        
        .section-title p {
            font-size: 1.1rem;
            color: var(--text-light);
        }
        
        /* About Section */
        .about-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            align-items: center;
        }
        
        .about-content h3 {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--text-dark);
        }
        
        .about-content p {
            margin-bottom: 1rem;
            color: var(--text-light);
            line-height: 1.8;
        }
        
        .about-img {
            width: 100%;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .about-img img {
            width: 100%;
            height: auto;
            display: block;
        }
        
        /* Services Grid */
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }
        
        .service-card {
            background: var(--white);
            border-radius: 10px;
            padding: 2rem;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid var(--border);
            cursor: pointer;
            animation: fadeIn 0.6s ease-out backwards;
        }
        
        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
            border-color: var(--primary);
        }
        
        .service-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        
        .service-card h3 {
            font-size: 1.3rem;
            margin-bottom: 0.5rem;
            color: var(--text-dark);
        }
        
        .service-card p {
            color: var(--text-light);
            margin-bottom: 1.5rem;
            min-height: 60px;
        }
        
        .service-price {
            font-size: 1.3rem;
            color: var(--primary);
            font-weight: 700;
        }
        
        /* Stats Section */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            text-align: center;
        }
        
        .stat-box {
            padding: 2rem;
        }
        
        .stat-number {
            font-size: 3rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: var(--text-light);
            font-size: 1.1rem;
        }
        
        /* Gallery */
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }
        
        .gallery-item {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
            aspect-ratio: 1;
            cursor: pointer;
            animation: fadeIn 0.6s ease-out backwards;
        }
        
        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        
        .gallery-item:hover img {
            transform: scale(1.1);
        }
        
        .gallery-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(46, 204, 113, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .gallery-item:hover .gallery-overlay {
            opacity: 1;
        }
        
        .gallery-overlay-icon {
            color: var(--white);
            font-size: 3rem;
        }
        
        /* Lightbox */
        .lightbox {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.9);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        
        .lightbox.active {
            display: flex;
        }
        
        .lightbox-content {
            max-width: 90vw;
            max-height: 90vh;
            position: relative;
        }
        
        .lightbox-img {
            max-width: 100%;
            max-height: 100%;
            border-radius: 10px;
        }
        
        .lightbox-close {
            position: absolute;
            top: -40px;
            right: 0;
            color: var(--white);
            font-size: 2rem;
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        
        .lightbox-close:hover {
            transform: rotate(90deg);
        }
        
        /* Testimonials */
        .testimonials-slider {
            position: relative;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .testimonial-card {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 2rem;
            text-align: center;
            display: none;
            animation: fadeIn 0.6s ease-out;
        }
        
        .testimonial-card.active {
            display: block;
        }
        
        .testimonial-img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin: 0 auto 1rem;
            overflow: hidden;
        }
        
        .testimonial-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .testimonial-text {
            font-style: italic;
            color: var(--text-light);
            margin-bottom: 1rem;
        }
        
        .testimonial-author {
            font-weight: 700;
            color: var(--text-dark);
        }
        
        .testimonial-position {
            color: var(--text-light);
            font-size: 0.9rem;
        }
        
        .stars {
            color: #f39c12;
            margin-bottom: 1rem;
        }
        
        .slider-nav {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .slider-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--border);
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .slider-dot.active {
            background: var(--primary);
            width: 30px;
            border-radius: 6px;
        }
        
        /* FAQ */
        .faq-list {
            max-width: 700px;
            margin: 0 auto;
        }
        
        .faq-item {
            border-bottom: 1px solid var(--border);
            padding: 1.5rem 0;
            animation: slideUp 0.6s ease-out backwards;
        }
        
        .faq-question {
            font-weight: 700;
            color: var(--text-dark);
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: color 0.3s ease;
        }
        
        .faq-question:hover {
            color: var(--primary);
        }
        
        .faq-toggle {
            font-size: 1.5rem;
            transition: transform 0.3s ease;
        }
        
        .faq-item.active .faq-toggle {
            transform: rotate(180deg);
        }
        
        .faq-answer {
            display: none;
            color: var(--text-light);
            margin-top: 1rem;
            line-height: 1.8;
        }
        
        .faq-item.active .faq-answer {
            display: block;
        }
        
        /* Contact Form */
        .contact-form {
            max-width: 600px;
            margin: 0 auto;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid var(--border);
            border-radius: 5px;
            font-family: inherit;
            font-size: 1rem;
            transition: border-color