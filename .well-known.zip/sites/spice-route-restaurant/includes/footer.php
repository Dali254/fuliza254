</main>

<footer style="background: var(--dark); color: #fff; padding: 4rem 0 2rem; margin-top: 5rem;">
    <div class="container">
        <div class="row mb-4">
            <div class="col-md-4 mb-4">
                <h5 style="font-family: var(--playfair); margin-bottom: 1rem; color: var(--secondary);">Spice Route</h5>
                <p style="color: #aaa; margin-bottom: 1rem;">Discover the finest spices and authentic flavors from across the globe. Experience luxury dining with our dark, elegant ambiance.</p>
                <div>
                    <a href="#" style="color: var(--secondary); margin-right: 1rem;"><i class="fab fa-facebook"></i></a>
                    <a href="#" style="color: var(--secondary); margin-right: 1rem;"><i class="fab fa-instagram"></i></a>
                    <a href="#" style="color: var(--secondary); margin-right: 1rem;"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <h5 style="font-family: var(--playfair); margin-bottom: 1rem; color: var(--secondary);">Quick Links</h5>
                <ul style="list-style: none; padding: 0;">
                    <li><a href="index.php?page=home" style="color: #aaa; text-decoration: none;">Home</a></li>
                    <li><a href="index.php?page=about" style="color: #aaa; text-decoration: none;">About</a></li>
                    <li><a href="index.php?page=services" style="color: #aaa; text-decoration: none;">Services</a></li>
                    <li><a href="index.php?page=gallery" style="color: #aaa; text-decoration: none;">Gallery</a></li>
                    <li><a href="index.php?page=contact" style="color: #aaa; text-decoration: none;">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4 mb-4">
                <h5 style="font-family: var(--playfair); margin-bottom: 1rem; color: var(--secondary);">Contact Info</h5>
                <p style="color: #aaa;"><i class="fas fa-phone" style="color: var(--secondary); margin-right: 0.5rem;"></i><?php echo sanitize(SITE_PHONE); ?></p>
                <p style="color: #aaa;"><i class="fas fa-envelope" style="color: var(--secondary); margin-right: 0.5rem;"></i><?php echo sanitize(SITE_EMAIL); ?></p>
                <p style="color: #aaa;"><i class="fas fa-map-marker-alt" style="color: var(--secondary); margin-right: 0.5rem;"></i><?php echo sanitize(SITE_ADDRESS); ?></p>
            </div>
        </div>
        <hr style="border-color: rgba(255,255,255,0.1); margin: 2rem 0;">
        <div class="row">
            <div class="col-md-6">
                <p style="color: #aaa; margin: 0;">&copy; <?php echo date('Y'); ?> <?php echo sanitize(SITE_NAME); ?>. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="#" style="color: #aaa; text-decoration: none; margin-left: 1rem;">Privacy Policy</a>
                <a href="#" style="color: #aaa; text-decoration: none; margin-left: 1rem;">Terms of Service</a>
            </div>
        </div>
    </div>
</footer>

<div style="position: fixed; bottom: 2rem; right: 2rem; z-index: 100;">
    <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>" target="_blank" style="display: inline-flex; align-items: center; justify-content: center; width: 60px; height: 60px; background: #25d366; color: white; border-radius: 50%; text-decoration: none; box-shadow: 0 4px 12px rgba(0,0,0,0.15); transition: transform 0.3s ease;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
        <i class="fab fa-whatsapp" style="font-size: 1.5rem;"></i>
    </a>
</div>

<button id="back-top" style="position: fixed; bottom: 100px; right: 2rem; display: none; width: 50px; height: 50px; background: var(--primary); color: white; border: none; border-radius: 50%; cursor: pointer; font-size: 1.2rem; transition: all 0.3s ease; z-index: 99;" onmouseover="this.style.backgroundColor='var(--secondary)'" onmouseout="this.style.backgroundColor='var(--primary)'">
    <i class="fas fa-chevron-up"></i>
</button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>