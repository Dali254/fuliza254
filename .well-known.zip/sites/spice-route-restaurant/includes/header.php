<?php
$csrf = generate_csrf();
$currentPage = $_GET['page'] ?? 'home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo sanitize(SITE_NAME); ?> - Spice Route Restaurant</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        :root {
            --primary: #1e3a5f;
            --secondary: #c9a84c;
            --accent: #e85d04;
            --dark: #0a0e27;
            --light: #f8f9fa;
            --text-primary: #1a1a1a;
            --text-light: #666;
            --border: #e0e0e0;
            --playfair: 'Playfair Display', serif;
            --lato: 'Lato', sans-serif;
        }
        
        body {
            font-family: var(--lato);
            color: var(--text-primary);
            background-color: #fff;
            line-height: 1.6;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: var(--playfair);
            font-weight: 700;
            color: var(--primary);
        }
        
        header {
            position: sticky;
            top: 0;
            z-index: 1000;
            background: rgba(255, 255, 255, 0.98);
            border-bottom: 1px solid var(--border);
            padding: 1rem 0;
        }
        
        .navbar-brand {
            font-family: var(--playfair);
            font-size: 1.8rem;
            font-weight: 900;
            color: var(--primary) !important;
        }
        
        .navbar-brand span {
            color: var(--secondary);
        }
        
        .nav-link {
            margin: 0 0.5rem;
            color: var(--text-primary) !important;
            font-weight: 500;
            position: relative;
            transition: color 0.3s ease;
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 50%;
            width: 0;
            height: 2px;
            background: var(--secondary);
            transform: translateX(-50%);
            transition: width 0.3s ease;
        }
        
        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }
        
        .hamburger {
            display: none;
            flex-direction: column;
            background: none;
            border: none;
            cursor: pointer;
        }
        
        .hamburger span {
            width: 25px;
            height: 3px;
            background: var(--primary);
            margin: 5px 0;
            transition: 0.3s;
        }
        
        .mobile-menu {
            display: none;
            position: fixed;
            top: 70px;
            left: 0;
            width: 100%;
            background: white;
            flex-direction: column;
            padding: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            z-index: 999;
        }
        
        .mobile-menu.active {
            display: flex;
        }
        
        .mobile-menu a {
            padding: 1rem;
            color: var(--text-primary);
            text-decoration: none;
            border-bottom: 1px solid var(--border);
            font-weight: 500;
        }
        
        .loading-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--primary);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease;
        }
        
        .loading-screen.active {
            opacity: 1;
            visibility: visible;
        }
        
        .spinner {
            border: 4px solid rgba(255,255,255,0.3);
            border-top: 4px solid var(--secondary);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        @media (max-width: 768px) {
            .hamburger {
                display: flex;
            }
            
            .navbar-collapse {
                display: none !important;
            }
        }
    </style>
</head>
<body>
<div class="loading-screen" id="loadingScreen">
    <div class="spinner"></div>
</div>

<header>
    <nav class="navbar navbar-expand-lg navbar-light container">
        <a class="navbar-brand" href="index.php">Spice <span>Route</span></a>
        <button class="hamburger" id="hamburger" type="button">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <div class="navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link <?php echo $currentPage === 'home' ? 'active' : ''; ?>" href="index.php?page=home">Home</a></li>
                <li class="nav-item"><a class="nav-link <?php echo $currentPage === 'about' ? 'active' : ''; ?>" href="index.php?page=about">About</a></li>
                <li class="nav-item"><a class="nav-link <?php echo $currentPage === 'services' ? 'active' : ''; ?>" href="index.php?page=services">Services</a></li>
                <li class="nav-item"><a class="nav-link <?php echo $currentPage === 'gallery' ? 'active' : ''; ?>" href="index.php?page=gallery">Gallery</a></li>
                <li class="nav-item"><a class="nav-link <?php echo $currentPage === 'contact' ? 'active' : ''; ?>" href="index.php?page=contact">Contact</a></li>
            </ul>
        </div>
    </nav>
</header>

<div class="mobile-menu" id="mobileMenu">
    <a href="index.php?page=home">Home</a>
    <a href="index.php?page=about">About</a>
    <a href="index.php?page=services">Services</a>
    <a href="index.php?page=gallery">Gallery</a>
    <a href="index.php?page=contact">Contact</a>
</div>

<main>