<?php
defined('SITE_DB_HOST') || define('SITE_DB_HOST', 'localhost');
defined('SITE_DB_NAME') || define('SITE_DB_NAME', 'lipawinc_beb');
defined('SITE_DB_USER') || define('SITE_DB_USER', 'lipawinc_beb');
defined('SITE_DB_PASS') || define('SITE_DB_PASS', 'lipawinc_beb');
try {
    $pdo = new PDO(
        'mysql:host='.SITE_DB_HOST.';dbname='.SITE_DB_NAME.';charset=utf8mb4',
        SITE_DB_USER, SITE_DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    error_log('DB Error: '.$e->getMessage());
    die('<p style="font-family:sans-serif;padding:20px;color:#c00;font-size:16px">Database connection failed.</p>');
}