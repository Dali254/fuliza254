<?php
function sanitize($s) { return htmlspecialchars(strip_tags(trim((string)$s)), ENT_QUOTES, 'UTF-8'); }
function redirect($url) { header('Location: '.$url); exit; }
function flash($msg, $type='success') { $_SESSION['flash'] = ['msg'=>$msg,'type'=>$type]; }
function get_flash() { $f=$_SESSION['flash']??null; unset($_SESSION['flash']); return $f; }
function is_admin() { return !empty($_SESSION['admin_logged_in']); }
function require_admin() { if(!is_admin()){header('Location:../admin/login.php');exit;} }
function format_price($n) { return 'KES '.number_format((float)$n,2); }
function time_ago($dt) {
    $d=time()-strtotime($dt);
    if($d<60) return $d.'s ago';
    if($d<3600) return round($d/60).'m ago';
    if($d<86400) return round($d/3600).'h ago';
    return round($d/86400).'d ago';
}
function generate_csrf() {
    if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function verify_csrf($t) { return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'],$t); }
function show_flash() {
    $f=get_flash(); if(!$f) return;
    $bg=$f['type']=='success'?'#d1fae5':'#fee2e2';
    $col=$f['type']=='success'?'#065f46':'#991b1b';
    echo '<div style="padding:12px 16px;background:'.$bg.';color:'.$col.';border-radius:8px;margin:12px 0;font-weight:600;">'.sanitize($f['msg']).'</div>';
}