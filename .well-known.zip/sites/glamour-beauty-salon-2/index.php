<?php
session_start();
require_once __DIR__ . "/config/db.php";
require_once __DIR__ . "/config/config.php";
require_once __DIR__ . "/includes/functions.php";
$page = $_GET["page"] ?? "home";
$allowed_pages = ["home","about","services","gallery","contact"];
if (!in_array($page, $allowed_pages)) $page = "home";
require_once __DIR__ . "/includes/header.php";
require_once __DIR__ . "/pages/{$page}.php";
require_once __DIR__ . "/includes/footer.php";