<?php
require_once __DIR__ . '/config/db.php';
$user = requireAuth();
$siteId = intval($_GET['site'] ?? 0);
$site   = null;
if ($siteId) {
    $s = getDB()->prepare("SELECT id, name, status, slug, project_type FROM sites WHERE id=? AND user_id=? LIMIT 1");
    $s->execute([$siteId, $user['id']]);
    $site = $s->fetch();
}
$siteName = getSetting('site_name', 'BuildKE');
$baseUrl  = rtrim(SITE_URL, '/');
$downloadPrice = intval(getSetting('download_price', '499'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>Project Builder — <?= htmlspecialchars($siteName) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#07070e;--bg2:#0f0f1a;--bg3:#161622;--bg4:#1c1c2c;--bg5:#222234;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.12);
  --text:#eeeef8;--text2:rgba(238,238,248,.55);--text3:rgba(238,238,248,.3);--text4:rgba(238,238,248,.14);
  --p:#7c3aed;--b:#3b82f6;--g:#10b981;--r:#ef4444;--o:#f59e0b;
  --grad:linear-gradient(135deg,#7c3aed,#3b82f6);
  --hh:52px;--sw:300px;--fw:260px;
}
html,body{height:100%;overflow:hidden;font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--text);-webkit-font-smoothing:antialiased}

/* HEADER */
.hdr{height:var(--hh);display:flex;align-items:center;padding:0 14px;gap:8px;background:rgba(7,7,14,.92);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);z-index:300;flex-shrink:0;position:relative}
.hdr::after{content:'';position:absolute;bottom:0;left:0;right:0;height:1px;background:var(--grad);opacity:.25}
.logo{font-size:14px;font-weight:900;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;white-space:nowrap;flex-shrink:0}
.hdr-gap{flex:1}
.hdr-name{font-size:12px;color:var(--text3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px}
.hbtn{height:30px;padding:0 11px;border-radius:7px;border:none;cursor:pointer;font-size:11.5px;font-weight:700;display:inline-flex;align-items:center;gap:4px;transition:.18s;text-decoration:none;white-space:nowrap;flex-shrink:0;-webkit-tap-highlight-color:transparent}
.hbtn.ghost{background:rgba(255,255,255,.06);color:var(--text2);border:1px solid var(--border2)}
.hbtn.ghost:hover{background:rgba(255,255,255,.1);color:var(--text)}
.hbtn.grn{background:linear-gradient(135deg,#059669,var(--g));color:#fff;box-shadow:0 2px 8px rgba(16,185,129,.3)}
.hbtn.grn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.sep{width:1px;height:18px;background:var(--border);flex-shrink:0}
@media(max-width:480px){.hbl{display:none}.hdr-name{display:none}}

/* STATUS BAR */
.sbar{height:28px;display:flex;align-items:center;padding:0 14px;gap:8px;background:var(--bg2);border-bottom:1px solid var(--border);flex-shrink:0;font-size:11px;color:var(--text3);overflow:hidden;transition:background .3s}
.sbar.gen{background:rgba(124,58,237,.07);border-color:rgba(124,58,237,.2)}
.sbar.db{background:rgba(16,185,129,.07);border-color:rgba(16,185,129,.2)}
.sdot{width:6px;height:6px;border-radius:50%;background:var(--text4);flex-shrink:0;transition:background .3s}
.sdot.gen{background:var(--o);animation:pulse 1s infinite}
.sdot.db{background:var(--b);animation:pulse 1s infinite}
.sdot.ok{background:var(--g)}
.sdot.err{background:var(--r)}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
#loadbar{position:fixed;top:0;left:0;right:0;height:2px;background:var(--grad);transform:scaleX(0);transform-origin:left;z-index:9999;display:none;transition:transform .2s}

/* LAYOUT */
.layout{display:flex;height:calc(100vh - var(--hh) - 28px);overflow:hidden}

/* CHAT PANEL */
.chat-panel{width:var(--sw);flex-shrink:0;background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;overflow:hidden}

/* Type selector */
.type-sel{padding:10px 12px;border-bottom:1px solid var(--border);flex-shrink:0}
.type-lbl{font-size:9.5px;font-weight:800;color:var(--text3);text-transform:uppercase;letter-spacing:.7px;margin-bottom:7px}
.type-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:4px}
.tbtn{padding:7px 4px;border-radius:8px;border:1.5px solid var(--border);background:var(--bg3);color:var(--text3);font-size:9.5px;font-weight:700;cursor:pointer;transition:.18s;text-align:center;-webkit-tap-highlight-color:transparent;display:flex;flex-direction:column;align-items:center;gap:3px}
.tbtn i{font-size:14px;transition:.18s}
.tbtn:hover,.tbtn.sel{border-color:rgba(124,58,237,.45);background:rgba(124,58,237,.1);color:#c4b5fd}
.tbtn.sel{box-shadow:0 0 0 2px rgba(124,58,237,.2)}
.db-support{font-size:9px;color:rgba(16,185,129,.7);font-weight:700}

/* Messages */
.msgs{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px;-webkit-overflow-scrolling:touch}
.msgs::-webkit-scrollbar{width:3px}
.msgs::-webkit-scrollbar-thumb{background:rgba(255,255,255,.07)}
.msg{display:flex;flex-direction:column;animation:msgIn .2s ease}
@keyframes msgIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
.msg.u{align-items:flex-end}.msg.a{align-items:flex-start}
.bubble{padding:9px 13px;border-radius:14px;font-size:12.5px;line-height:1.6;max-width:92%}
.msg.u .bubble{background:var(--grad);color:#fff;border-radius:14px 3px 14px 14px}
.msg.a .bubble{background:var(--bg4);color:var(--text);border:1px solid var(--border);border-radius:3px 14px 14px 14px}
.msg.a .bubble a{color:#a78bfa;font-weight:700;text-decoration:none}
.typing{display:flex;gap:4px;padding:10px 12px;background:var(--bg4);border:1px solid var(--border);border-radius:3px 14px 14px 14px;width:fit-content}
.typing span{width:5px;height:5px;border-radius:50%;background:var(--p);animation:td 1.2s ease-in-out infinite}
.typing span:nth-child(2){animation-delay:.2s}.typing span:nth-child(3){animation-delay:.4s}
@keyframes td{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-5px)}}
.sugs{display:flex;flex-wrap:wrap;gap:4px;margin-top:3px}
.sug{padding:4px 9px;background:rgba(124,58,237,.07);border:1px solid rgba(124,58,237,.2);border-radius:20px;font-size:10.5px;color:#c4b5fd;cursor:pointer;transition:.15s;-webkit-tap-highlight-color:transparent}
.sug:hover,.sug:active{background:rgba(124,58,237,.16)}

/* DB notice */
.db-notice{margin:8px 12px;padding:8px 10px;background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.2);border-radius:9px;font-size:10.5px;color:rgba(134,239,172,.8);display:flex;align-items:flex-start;gap:6px;line-height:1.5}
.db-notice i{flex-shrink:0;margin-top:1px;color:var(--g)}

/* Input */
.input-area{padding:9px 10px 12px;border-top:1px solid var(--border);background:var(--bg2);flex-shrink:0}
.input-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:5px}
.input-hint{font-size:9.5px;color:var(--text3);display:flex;align-items:center;gap:3px}
.type-badge{font-size:9px;padding:2px 7px;border-radius:20px;font-weight:700}
.type-badge.html{background:rgba(228,77,38,.1);color:#fb923c;border:1px solid rgba(228,77,38,.2)}
.type-badge.php{background:rgba(136,146,190,.1);color:#a5b4fc;border:1px solid rgba(136,146,190,.2)}
.type-badge.react{background:rgba(97,218,251,.1);color:#67e8f9;border:1px solid rgba(97,218,251,.2)}
.type-badge.node{background:rgba(140,200,75,.1);color:#86efac;border:1px solid rgba(140,200,75,.2)}
.type-badge.vue{background:rgba(66,184,131,.1);color:#6ee7b7;border:1px solid rgba(66,184,131,.2)}
.img-strip{display:none;flex-wrap:wrap;gap:5px;margin-bottom:6px}
.img-wrap{position:relative;width:40px;height:40px}
.img-th{width:40px;height:40px;border-radius:7px;object-fit:cover;border:1.5px solid rgba(124,58,237,.35)}
.img-x{position:absolute;top:-4px;right:-4px;width:14px;height:14px;border-radius:50%;background:var(--r);color:#fff;font-size:8px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:none}
.input-row{display:flex;gap:5px;align-items:flex-end}
#chatInput{flex:1;resize:none;height:40px;max-height:100px;background:var(--bg3);border:1.5px solid var(--border2);border-radius:10px;padding:9px 11px;color:var(--text);font-size:13px;font-family:inherit;outline:none;transition:.2s;line-height:1.4;-webkit-appearance:none}
#chatInput:focus{border-color:var(--p);box-shadow:0 0 0 3px rgba(124,58,237,.1)}
#chatInput::placeholder{color:var(--text4)}
.ibtns{display:flex;gap:4px;align-items:flex-end}
.ibtn{width:40px;height:40px;border-radius:10px;border:1.5px solid var(--border2);background:var(--bg3);color:var(--text3);font-size:13px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:.18s;-webkit-tap-highlight-color:transparent}
.ibtn:hover{background:rgba(124,58,237,.1);border-color:rgba(124,58,237,.3);color:#c4b5fd}
#sendBtn{width:40px;height:40px;border-radius:10px;border:none;cursor:pointer;background:var(--grad);color:#fff;font-size:13px;display:flex;align-items:center;justify-content:center;transition:.18s;box-shadow:0 2px 8px rgba(124,58,237,.35);-webkit-tap-highlight-color:transparent}
#sendBtn:active{transform:scale(.93)}
#sendBtn:disabled{opacity:.4;cursor:not-allowed;transform:none;box-shadow:none}
#imgInput{display:none}

/* FILE TREE */
.filetree-panel{width:var(--fw);flex-shrink:0;background:var(--bg3);border-right:1px solid var(--border);display:flex;flex-direction:column;overflow:hidden}
.ph{height:38px;display:flex;align-items:center;padding:0 12px;gap:7px;border-bottom:1px solid var(--border);flex-shrink:0;font-size:11px;font-weight:700;color:var(--text2);background:var(--bg4)}
.ph i{font-size:12px;color:var(--text3)}
.ph-acts{margin-left:auto;display:flex;gap:5px}
.ph-btn{height:22px;padding:0 8px;border-radius:6px;border:1px solid var(--border2);background:transparent;color:var(--text3);font-size:10px;font-weight:700;cursor:pointer;transition:.15s;display:flex;align-items:center;gap:3px}
.ph-btn:hover{background:rgba(255,255,255,.07);color:var(--text2)}
.ph-btn.grn{border-color:rgba(16,185,129,.3);color:var(--g)}
.ph-btn.grn:hover{background:rgba(16,185,129,.1)}
.tree{flex:1;overflow-y:auto;padding:6px 0;-webkit-overflow-scrolling:touch}
.tree::-webkit-scrollbar{width:3px}
.tree::-webkit-scrollbar-thumb{background:rgba(255,255,255,.06)}
.tree-empty{padding:28px 14px;text-align:center;color:var(--text3);font-size:11.5px;line-height:1.6}
.tree-empty i{font-size:28px;opacity:.12;margin-bottom:8px;display:block}
.tree-folder,.tree-file{display:flex;align-items:center;gap:6px;padding:5px 12px;font-size:11.5px;cursor:pointer;transition:.15s;white-space:nowrap;overflow:hidden}
.tree-folder{font-weight:700;color:var(--text2)}
.tree-folder:hover{background:rgba(255,255,255,.04);color:var(--text)}
.tree-file{color:var(--text3);padding-left:26px}
.tree-file:hover{background:rgba(255,255,255,.03);color:var(--text2)}
.tree-file.act{background:rgba(124,58,237,.1);color:#c4b5fd}
.tree-file i{font-size:10px;flex-shrink:0}
.tree-folder i{font-size:11px;color:var(--o);opacity:.65}
.tree-name{flex:1;overflow:hidden;text-overflow:ellipsis}
.tree-lines{font-size:9.5px;color:var(--text4);flex-shrink:0}
.dl-panel{flex-shrink:0;border-top:1px solid var(--border);padding:10px 12px;background:var(--bg4)}
.dl-info{font-size:10.5px;color:var(--text3);margin-bottom:7px;line-height:1.5}
.dl-btn{width:100%;height:36px;border-radius:9px;border:none;cursor:pointer;background:var(--grad);color:#fff;font-size:12.5px;font-weight:800;display:flex;align-items:center;justify-content:center;gap:6px;transition:.18s;-webkit-tap-highlight-color:transparent}
.dl-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}

/* EDITOR */
.editor-panel{flex:1;display:flex;flex-direction:column;overflow:hidden;min-width:0}
.etabs{height:38px;display:flex;align-items:stretch;background:var(--bg3);border-bottom:1px solid var(--border);overflow-x:auto;flex-shrink:0}
.etabs::-webkit-scrollbar{height:2px}
.etabs::-webkit-scrollbar-thumb{background:rgba(255,255,255,.06)}
.etab{display:flex;align-items:center;gap:6px;padding:0 13px;font-size:11.5px;font-weight:600;color:var(--text3);cursor:pointer;white-space:nowrap;transition:.15s;border-right:1px solid var(--border);flex-shrink:0;position:relative}
.etab:hover{color:var(--text2);background:rgba(255,255,255,.03)}
.etab.act{color:var(--text);background:var(--bg2)}
.etab.act::after{content:'';position:absolute;bottom:0;left:0;right:0;height:2px;background:var(--grad)}
.etab i{font-size:10px;color:var(--text4)}
.etab.act i{color:var(--text3)}
.etab-x{width:14px;height:14px;border-radius:3px;background:transparent;border:none;color:var(--text4);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:9px;transition:.15s}
.etab-x:hover{background:rgba(239,68,68,.18);color:var(--r)}
.code-area{flex:1;overflow:hidden;position:relative;background:var(--bg)}
#codeEditor{width:100%;height:100%;border:none;outline:none;background:var(--bg);color:#cdd6f4;font-family:'Fira Code','Cascadia Code','Courier New',monospace;font-size:12.5px;line-height:1.75;padding:14px 16px;resize:none;tab-size:2;-webkit-appearance:none;overflow-y:auto}
#codeEditor::-webkit-scrollbar{width:5px;height:5px}
#codeEditor::-webkit-scrollbar-thumb{background:rgba(255,255,255,.07);border-radius:3px}
.code-ph{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:36px;pointer-events:none}
.code-ph-ico{font-size:46px;opacity:.08;margin-bottom:4px}
.code-ph-t{font-size:14px;font-weight:800;color:var(--text2)}
.code-ph-s{font-size:11.5px;color:var(--text3);max-width:280px;line-height:1.65}

/* Setup overlay */
.ov{display:none;position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.82);backdrop-filter:blur(14px);align-items:center;justify-content:center;padding:20px}
.ov.on{display:flex}
.setup-box{background:var(--bg2);border:1px solid var(--border2);border-radius:20px;width:100%;max-width:640px;max-height:86vh;overflow:hidden;display:flex;flex-direction:column}
.setup-hd{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;flex-shrink:0}
.setup-ttl{font-size:15px;font-weight:800;flex:1}
.setup-cls{width:30px;height:30px;border-radius:8px;background:rgba(255,255,255,.06);border:1px solid var(--border2);color:var(--text2);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px}
.setup-body{flex:1;overflow-y:auto;padding:20px;-webkit-overflow-scrolling:touch;font-size:13px;line-height:1.75;color:var(--text2)}
.setup-body::-webkit-scrollbar{width:4px}
.setup-body::-webkit-scrollbar-thumb{background:rgba(255,255,255,.07);border-radius:2px}
.setup-body pre{background:var(--bg3);border:1px solid var(--border);border-radius:9px;padding:12px 14px;font-size:11.5px;line-height:1.7;color:#86efac;overflow-x:auto;margin:10px 0;font-family:monospace;white-space:pre-wrap}
.setup-body p{margin-bottom:10px}
.setup-body h3{font-size:12.5px;font-weight:800;color:var(--text);margin:16px 0 6px;text-transform:uppercase;letter-spacing:.5px}
.setup-body strong{color:var(--text)}

/* DB created badge */
.db-badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;background:rgba(16,185,129,.12);border:1px solid rgba(16,185,129,.28);border-radius:20px;font-size:10px;font-weight:700;color:#4ade80;vertical-align:middle}

/* MOBILE */
@media(max-width:900px){
  .filetree-panel{display:none}
  :root{--sw:100vw}
  .chat-panel{position:absolute;top:0;bottom:56px;left:0;right:0;width:100%!important;z-index:10;transition:transform .25s}
  .chat-panel.hide{transform:translateX(-100%)}
  .editor-panel{position:absolute;top:0;bottom:56px;left:0;right:0;z-index:9;transition:transform .25s}
  .editor-panel.hide{transform:translateX(100%)}
  #chatInput{font-size:16px}
  .input-area{padding-bottom:calc(56px + env(safe-area-inset-bottom) + 8px)!important}
}
.mob-tabs{display:none;position:fixed;bottom:0;left:0;right:0;height:56px;background:rgba(15,15,26,.95);backdrop-filter:blur(20px);border-top:1px solid var(--border);z-index:200;padding:5px 8px env(safe-area-inset-bottom);align-items:flex-start;justify-content:space-around;gap:4px}
@media(max-width:900px){.mob-tabs{display:flex}}
.mt-btn{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;cursor:pointer;padding:4px;border:none;background:transparent;color:var(--text3);transition:.15s;border-radius:8px;-webkit-tap-highlight-color:transparent}
.mt-btn.act{color:#c4b5fd;background:rgba(124,58,237,.1)}
.mt-btn i{font-size:17px}
.mt-btn span{font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.3px}
</style>
</head>
<body>
<div id="loadbar"></div>

<div class="hdr">
  <div class="logo">⚡ <?= htmlspecialchars($siteName) ?></div>
  <div class="sep"></div>
  <div class="hdr-name" id="hdrName"><?= $site ? htmlspecialchars($site['name']) : 'New Project' ?></div>
  <div class="hdr-gap"></div>
  <button class="hbtn ghost" id="hdrSetupBtn" onclick="showSetup()" style="display:none"><i class="fa-solid fa-circle-question"></i><span class="hbl"> Guide</span></button>
  <button class="hbtn grn" id="hdrDlBtn" onclick="downloadProject()" style="display:none">
    <i class="fa-solid fa-file-zipper"></i><span class="hbl"> Download ZIP</span>
  </button>
  <div class="sep"></div>
  <a href="<?= $baseUrl ?>/dashboard.php" class="hbtn ghost" style="padding:0 9px"><i class="fa-solid fa-grid-2"></i></a>
</div>

<div class="sbar" id="sbar">
  <div class="sdot" id="sdot"></div>
  <span id="stxt">Choose a project type and describe what to build</span>
  <span id="sextra" style="margin-left:auto;font-size:10px;color:var(--text4)"></span>
</div>

<div class="layout">

  <!-- CHAT -->
  <div class="chat-panel" id="chatPanel">
    <div class="type-sel">
      <div class="type-lbl">Project Type</div>
      <div class="type-grid">
        <button class="tbtn sel" data-type="html" onclick="setType('html',this)">
          <i class="fa-brands fa-html5" style="color:#e44d26"></i>HTML
        </button>
        <button class="tbtn" data-type="php" onclick="setType('php',this)">
          <i class="fa-brands fa-php" style="color:#8892be"></i>PHP
          <span class="db-support">+MySQL</span>
        </button>
        <button class="tbtn" data-type="react" onclick="setType('react',this)">
          <i class="fa-brands fa-react" style="color:#61dafb"></i>React
        </button>
        <button class="tbtn" data-type="node" onclick="setType('node',this)">
          <i class="fa-brands fa-node-js" style="color:#8cc84b"></i>Node
          <span class="db-support">+MySQL</span>
        </button>
        <button class="tbtn" data-type="vue" onclick="setType('vue',this)">
          <i class="fa-solid fa-v" style="color:#42b883"></i>Vue
        </button>
      </div>
    </div>

    <!-- DB notice shown for PHP/Node -->
    <div class="db-notice" id="dbNotice" style="display:none">
      <i class="fa-solid fa-database"></i>
      <span><strong>Auto MySQL Setup:</strong> For PHP/Node projects, we automatically create a MySQL database, run your SQL schema, and inject the credentials into your config files. Your project works immediately after download!</span>
    </div>

    <div class="msgs" id="msgs">
      <div class="msg a">
        <div class="bubble">
          🚀 <strong>Project Builder</strong><br><br>
          I generate <strong>complete multi-file projects</strong> with all files, working code, and — for PHP/Node — a <strong>real MySQL database</strong> created automatically on our server.<br><br>
          Choose your stack, describe your project, get a working ZIP.
        </div>
      </div>
      <div class="sugs" id="sugBox">
        <div class="sug" data-t="html">Multi-page salon website with booking</div>
        <div class="sug" data-t="php">PHP e-commerce shop with cart & M-Pesa</div>
        <div class="sug" data-t="php">PHP blog with admin panel and MySQL</div>
        <div class="sug" data-t="react">React todo app with local storage</div>
        <div class="sug" data-t="node">Node.js REST API for a restaurant</div>
        <div class="sug" data-t="php">PHP school management system</div>
        <div class="sug" data-t="php">PHP hotel booking system with rooms DB</div>
        <div class="sug" data-t="node">Node.js job board with applications</div>
      </div>
    </div>

    <div class="input-area">
      <div class="input-top">
        <div class="input-hint"><i class="fa-solid fa-terminal" style="color:#c4b5fd;font-size:11px"></i> Describe your project</div>
        <span class="type-badge html" id="typeBadge">HTML</span>
      </div>
      <div class="img-strip" id="imgStrip"></div>
      <div class="input-row">
        <textarea id="chatInput" placeholder="e.g. A salon website with home, services, gallery, booking and contact pages..." rows="1" autocomplete="off" autocorrect="off"></textarea>
        <div class="ibtns">
          <button class="ibtn" title="Upload reference" onclick="document.getElementById('imgInput').click()"><i class="fa-solid fa-image"></i></button>
          <button id="sendBtn" type="button"><i class="fa-solid fa-paper-plane"></i></button>
        </div>
      </div>
      <input type="file" id="imgInput" accept="image/*" multiple>
    </div>
  </div>

  <!-- FILE TREE -->
  <div class="filetree-panel">
    <div class="ph">
      <i class="fa-solid fa-folder-tree"></i>
      <span>Project Files</span>
      <div class="ph-acts">
        <button class="ph-btn" onclick="expandAll()"><i class="fa-solid fa-expand"></i></button>
        <button class="ph-btn grn" id="dlBtnTree" onclick="downloadProject()" style="display:none">
          <i class="fa-solid fa-download"></i> ZIP
        </button>
      </div>
    </div>
    <div class="tree" id="fileTree">
      <div class="tree-empty"><i class="fa-solid fa-folder-open"></i>Files appear here<br>after generation</div>
    </div>
    <div class="dl-panel" id="dlPanel" style="display:none">
      <div class="dl-info" id="dlInfo"></div>
      <button class="dl-btn" onclick="downloadProject()">
        <i class="fa-solid fa-file-zipper"></i> Download ZIP
      </button>
    </div>
  </div>

  <!-- EDITOR -->
  <div class="editor-panel" id="editorPanel">
    <div class="etabs" id="etabs"></div>
    <div class="code-area">
      <div class="code-ph" id="codePh">
        <div class="code-ph-ico">💻</div>
        <div class="code-ph-t">Code Editor</div>
        <div class="code-ph-s">Click any file in the tree to view and edit. Changes are saved automatically to the project.</div>
      </div>
      <textarea id="codeEditor" spellcheck="false" style="display:none" onkeydown="handleTab(event)" oninput="onEdit()"></textarea>
    </div>
  </div>
</div>

<!-- MOBILE TABS -->
<div class="mob-tabs">
  <button class="mt-btn act" id="mChat" onclick="mob('chat')"><i class="fa-solid fa-comments"></i><span>Chat</span></button>
  <button class="mt-btn" id="mCode" onclick="mob('code')"><i class="fa-solid fa-code"></i><span>Code</span></button>
  <button class="mt-btn" id="mDl" onclick="downloadProject()"><i class="fa-solid fa-file-zipper"></i><span>ZIP</span></button>
</div>

<!-- SETUP OVERLAY -->
<div class="ov" id="setupOv">
  <div class="setup-box">
    <div class="setup-hd">
      <i class="fa-solid fa-terminal" style="color:#a78bfa"></i>
      <span class="setup-ttl">Setup & Deployment Guide</span>
      <button class="setup-cls" onclick="document.getElementById('setupOv').classList.remove('on')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="setup-body" id="setupBody"></div>
  </div>
</div>

<script>
var BASE='<?= $baseUrl ?>',SID=<?= $site?intval($site['id']):'null' ?>;
var PTYPE='<?= $site?($site['project_type']??'html'):'html' ?>';
var FILES={},FILE_META=[],OPEN_TABS=[],ACTIVE=null;
var HIST=[],IMGS=[],SETUP='',PNAME='project',GENERATING=false;

// ── INIT ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded',function(){
    var ta=document.getElementById('chatInput');
    ta.addEventListener('input',function(){this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px';});
    ta.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey&&window.innerWidth>900){e.preventDefault();send();}});
    document.getElementById('sendBtn').addEventListener('click',send);
    document.getElementById('imgInput').addEventListener('change',handleImgs);
    document.querySelectorAll('.sug').forEach(function(el){
        el.addEventListener('click',function(){
            var t=this.dataset.t;if(t)setType(t,document.querySelector('.tbtn[data-type="'+t+'"]'));
            document.getElementById('chatInput').value=this.textContent.trim();
            document.getElementById('chatInput').focus();
        });
    });
    if(SID){
        fetch(BASE+'/site_html.php?site_id='+SID,{credentials:'include'})
        .then(r=>r.json()).then(function(d){
            if(d.project_files){
                FILES={};FILE_META=[];
                d.project_files.forEach(function(f){FILES[f.path]=f.content;FILE_META.push({path:f.path,size:f.size||0,lines:f.lines||0});});
                renderTree();
                if(FILE_META.length)openFile(FILE_META[0].path);
                showDlButtons();
            }
        }).catch(()=>{});
    }
});

// ── TYPE SELECTOR ─────────────────────────────────────────────────────────────
function setType(t,btn){
    PTYPE=t;
    document.querySelectorAll('.tbtn').forEach(b=>b.classList.remove('sel'));
    if(btn)btn.classList.add('sel');
    var badge=document.getElementById('typeBadge');
    badge.className='type-badge '+t;badge.textContent=t.toUpperCase();
    // Show DB notice for PHP/Node
    document.getElementById('dbNotice').style.display=(t==='php'||t==='node')?'flex':'none';
    var ph={html:'e.g. Multi-page beauty salon website with gallery and booking...',php:'e.g. PHP e-commerce shop with cart, products, orders and M-Pesa checkout...',react:'e.g. React task manager with drag-and-drop and local storage...',node:'e.g. Node.js job board API with JWT auth and applications...',vue:'e.g. Vue 3 inventory management dashboard with charts...'};
    document.getElementById('chatInput').placeholder=ph[t]||'Describe your project...';
}

// ── IMAGES ────────────────────────────────────────────────────────────────────
function handleImgs(e){
    Array.from(e.target.files).slice(0,2-IMGS.length).forEach(function(f){
        if(!f.type.startsWith('image/')||f.size>4*1024*1024)return;
        var r=new FileReader();r.onload=function(ev){IMGS.push({b64:ev.target.result.split(',')[1],type:f.type});renderStrip();};r.readAsDataURL(f);
    });e.target.value='';
}
function renderStrip(){
    var s=document.getElementById('imgStrip');s.innerHTML='';if(!IMGS.length){s.style.display='none';return;}s.style.display='flex';
    IMGS.forEach(function(img,i){var w=document.createElement('div');w.className='img-wrap';w.innerHTML='<img class="img-th" src="data:'+img.type+';base64,'+img.b64+'"><button class="img-x" onclick="IMGS.splice('+i+',1);renderStrip()">✕</button>';s.appendChild(w);});
}

// ── SEND ──────────────────────────────────────────────────────────────────────
function send(){
    if(GENERATING)return;
    var ta=document.getElementById('chatInput'),msg=ta.value.trim();
    if(!msg&&!IMGS.length)return;
    if(!msg)msg='Use the uploaded image as design reference.';

    GENERATING=true;
    var btn=document.getElementById('sendBtn');
    btn.disabled=true;ta.value='';ta.style.height='40px';
    var sb=document.getElementById('sugBox');if(sb)sb.remove();

    addMsg('u',esc(msg));
    HIST.push({role:'user',content:msg});
    setStatus('gen','Generating project...');
    barStart();showTyping();
    if(window.innerWidth<=900)mob('code');

    var payload={prompt:msg,type:PTYPE,site_id:SID,history:HIST.slice(-6),mode:SID?'edit':'create'};
    if(IMGS.length)payload.images=IMGS.map(function(i){return{base64:i.b64,type:i.type};});
    IMGS=[];renderStrip();

    fetch(BASE+'/project_generate.php',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
    .then(function(res){
        if(!res.ok){return res.text().then(function(t){throw new Error('HTTP '+res.status+': '+t.substring(0,200));});}
        var reader=res.body.getReader(),dec=new TextDecoder(),buf='',evt='';
        function pump(){
            return reader.read().then(function(r){
                if(r.done){if(GENERATING){GENERATING=false;btn.disabled=false;barStop();hideTyping();setStatus('err','Stream ended unexpectedly');}return;}
                buf+=dec.decode(r.value,{stream:true});
                var lines=buf.split('\n');buf=lines.pop();
                for(var i=0;i<lines.length;i++){
                    var line=lines[i].trim();
                    if(line.startsWith('event:')){evt=line.slice(6).trim();}
                    else if(line.startsWith('data:')){
                        try{
                            var d=JSON.parse(line.slice(5).trim());
                            if(evt==='status'){handleStatus(d);}
                            else if(evt==='progress'){setStatus('gen','Writing... '+Math.round((d.chars||0)/1000)+'K chars');}
                            else if(evt==='done'){handleDone(d,btn);}
                            else if(evt==='error'){handleErr(d.message||'Error',btn);}
                        }catch(e){}
                        evt='';
                    }
                }
                return pump();
            });
        }
        return pump();
    })
    .catch(function(err){handleErr(err.message||'Connection failed',btn);});
}

function handleStatus(d){
    var stage=d.stage||'';
    // Special styling for DB stages
    if(stage==='database'){
        setStatus('db','Creating MySQL database...');
        document.getElementById('sbar').className='sbar db';
    } else if(stage==='db_done'){
        setStatus('db','Database created & tables loaded!');
        document.getElementById('sbar').className='sbar db';
    } else if(stage==='zip'){
        setStatus('gen',d.message||'Packaging ZIP...');
        document.getElementById('sbar').className='sbar gen';
    } else {
        setStatus('gen',d.message||'Working...');
    }
}

function handleDone(d,btn){
    GENERATING=false;btn.disabled=false;barStop();hideTyping();
    SID=d.site_id||SID;PNAME=d.project_name||'project';SETUP=d.setup||'';
    history.replaceState(null,'','?site='+SID);
    document.getElementById('hdrName').textContent=PNAME;

    var dbBadge = d.db_created
        ? ' <span class="db-badge"><i class="fa-solid fa-database"></i> MySQL Ready</span>'
        : '';

    // Fetch full files
    fetch(BASE+'/site_html.php?site_id='+SID,{credentials:'include'})
    .then(r=>r.json()).then(function(data){
        FILES={};FILE_META=[];
        if(data.project_files){
            data.project_files.forEach(function(f){FILES[f.path]=f.content;FILE_META.push({path:f.path,size:f.size||0,lines:f.lines||0});});
        }
        renderTree();
        if(FILE_META.length)openFile(FILE_META[0].path);
        showDlButtons();
        document.getElementById('dlInfo').textContent=FILE_META.length+' files · '+(d.type||PTYPE).toUpperCase()+(d.db_created?' · MySQL DB ready':'');

        var st=FILE_META.length+' files generated';
        if(d.db_created)st+=' · MySQL DB created';
        setStatus('ok',st);

        HIST.push({role:'assistant',content:'[project generated]'});
        addMsg('a',
            '✅ <strong>'+FILE_META.length+' files generated!</strong>'+dbBadge
            +(d.db_created?'<br>🗄️ <strong>MySQL database created</strong> — credentials injected into config files':'')
            +'<br>Click any file in the tree to view & edit.'
            +' <a href="#" onclick="downloadProject();return false">⬇ Download ZIP</a>'
            +' · <a href="#" onclick="showSetup();return false">📖 Guide</a>'
        );
        document.getElementById('sbar').className='sbar';
        if(window.innerWidth<=900)mob('code');
    });
}

function handleErr(msg,btn){
    GENERATING=false;btn.disabled=false;barStop();hideTyping();
    setStatus('err',msg.substring(0,80));
    document.getElementById('sbar').className='sbar';
    addMsg('a','❌ '+esc(msg));
}

function showDlButtons(){
    document.getElementById('hdrDlBtn').style.display='inline-flex';
    document.getElementById('hdrSetupBtn').style.display='inline-flex';
    document.getElementById('dlBtnTree').style.display='inline-flex';
    document.getElementById('dlPanel').style.display='block';
}

// ── FILE TREE ─────────────────────────────────────────────────────────────────
function renderTree(){
    var tree=document.getElementById('fileTree');tree.innerHTML='';
    if(!FILE_META.length){tree.innerHTML='<div class="tree-empty"><i class="fa-solid fa-folder-open"></i>No files</div>';return;}
    var folders={};
    FILE_META.forEach(function(f){
        var parts=f.path.split('/');
        if(parts.length===1){if(!folders[''])folders['']=[]; folders[''].push(f);}
        else{var fd=parts.slice(0,-1).join('/');if(!folders[fd])folders[fd]=[];folders[fd].push(f);}
    });
    if(folders[''])folders[''].forEach(function(f){tree.appendChild(mkFile(f));});
    Object.keys(folders).filter(k=>k).sort().forEach(function(folder){
        var d=document.createElement('div');d.className='tree-folder';
        d.innerHTML='<i class="fa-solid fa-folder"></i><span class="tree-name">'+esc(folder)+'</span>';
        tree.appendChild(d);
        folders[folder].forEach(function(f){tree.appendChild(mkFile(f));});
    });
}
function mkFile(f){
    var d=document.createElement('div');d.className='tree-file'+(ACTIVE===f.path?' act':'');d.dataset.path=f.path;
    var ico=fIcon(f.path);
    d.innerHTML='<i class="'+ico+'"></i><span class="tree-name">'+esc(f.path.split('/').pop())+'</span><span class="tree-lines">'+(f.lines||0)+'L</span>';
    d.addEventListener('click',function(){openFile(f.path);});
    return d;
}
function fIcon(p){
    var ext=(p.split('.').pop()||'').toLowerCase();
    var m={html:'fa-brands fa-html5',css:'fa-brands fa-css3-alt',js:'fa-brands fa-js',jsx:'fa-brands fa-react',vue:'fa-solid fa-file-code',php:'fa-brands fa-php',json:'fa-solid fa-brackets-curly',md:'fa-solid fa-file-lines',sql:'fa-solid fa-database',env:'fa-solid fa-lock',htaccess:'fa-solid fa-shield'};
    return 'fa-solid fa-file-code '+(m[ext]||'');
}

// ── EDITOR ────────────────────────────────────────────────────────────────────
function openFile(path){
    if(FILES[path]!==undefined){_open(path);return;}
    fetch(BASE+'/get_file.php?site_id='+SID+'&path='+encodeURIComponent(path),{credentials:'include'})
    .then(r=>r.json()).then(d=>{FILES[path]=d.content||'';_open(path);})
    .catch(()=>{FILES[path]='// Could not load file';_open(path);});
}
function _open(path){
    ACTIVE=path;
    if(!OPEN_TABS.find(t=>t.path===path))OPEN_TABS.push({path:path,dirty:false});
    renderTabs();
    var ed=document.getElementById('codeEditor'),ph=document.getElementById('codePh');
    ph.style.display='none';ed.style.display='block';
    ed.value=FILES[path]||'';ed.dataset.path=path;
    document.querySelectorAll('.tree-file').forEach(function(el){el.classList.toggle('act',el.dataset.path===path);});
}
function renderTabs(){
    var tabs=document.getElementById('etabs');tabs.innerHTML='';
    OPEN_TABS.forEach(function(tab){
        var d=document.createElement('div');d.className='etab'+(tab.path===ACTIVE?' act':'');
        d.innerHTML='<i class="'+fIcon(tab.path)+'"></i><span>'+esc(tab.path.split('/').pop())+'</span>'+(tab.dirty?'<span style="color:var(--o);margin-left:2px">●</span>':'')+'<button class="etab-x" onclick="closeTab(\''+tab.path+'\',event)"><i class="fa-solid fa-xmark"></i></button>';
        d.addEventListener('click',function(e){if(!e.target.closest('.etab-x'))openFile(tab.path);});
        tabs.appendChild(d);
    });
}
function closeTab(path,e){
    if(e)e.stopPropagation();
    OPEN_TABS=OPEN_TABS.filter(t=>t.path!==path);
    if(ACTIVE===path){
        ACTIVE=OPEN_TABS.length?OPEN_TABS[OPEN_TABS.length-1].path:null;
        if(ACTIVE)_open(ACTIVE);
        else{document.getElementById('codeEditor').style.display='none';document.getElementById('codePh').style.display='flex';}
    }
    renderTabs();
}
function expandAll(){FILE_META.forEach(function(f){if(!OPEN_TABS.find(t=>t.path===f.path))OPEN_TABS.push({path:f.path,dirty:false});});if(FILE_META.length&&!ACTIVE)_open(FILE_META[0].path);renderTabs();}
function onEdit(){var ed=document.getElementById('codeEditor'),p=ed.dataset.path;if(!p)return;FILES[p]=ed.value;var t=OPEN_TABS.find(t=>t.path===p);if(t&&!t.dirty){t.dirty=true;renderTabs();}}
function handleTab(e){if(e.key!=='Tab')return;e.preventDefault();var ta=e.target,s=ta.selectionStart,en=ta.selectionEnd;ta.value=ta.value.substring(0,s)+'  '+ta.value.substring(en);ta.selectionStart=ta.selectionEnd=s+2;onEdit();}

// ── DOWNLOAD ──────────────────────────────────────────────────────────────────
function downloadProject(){
    if(!SID){alert('Generate a project first!');return;}
    var a=document.createElement('a');a.href=BASE+'/project_download.php?site_id='+SID;
    a.download=PNAME+'.zip';document.body.appendChild(a);a.click();a.remove();
}

// ── SETUP GUIDE ───────────────────────────────────────────────────────────────
function showSetup(){
    if(!SETUP){alert('Generate a project first to see setup instructions.');return;}
    var body=document.getElementById('setupBody');
    var html=SETUP
        .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
        .replace(/```([^`]+)```/gs,'<pre>$1</pre>')
        .replace(/`([^`]+)`/g,'<code style="background:var(--bg3);padding:1px 5px;border-radius:4px;font-size:11px;font-family:monospace">$1</code>')
        .replace(/^###\s+(.+)$/gm,'<h3>$1</h3>')
        .replace(/^##\s+(.+)$/gm,'<h3>$1</h3>')
        .replace(/^#\s+(.+)$/gm,'<h3>$1</h3>')
        .replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>')
        .replace(/\n\n/g,'</p><p>')
        .replace(/\n/g,'<br>');
    body.innerHTML='<p>'+html+'</p>';
    document.getElementById('setupOv').classList.add('on');
}

// ── HELPERS ───────────────────────────────────────────────────────────────────
function setStatus(type,msg){
    var dot=document.getElementById('sdot'),t=document.getElementById('stxt');
    dot.className='sdot'+(type?' '+type:'');t.textContent=msg;
    if(type!=='db')document.getElementById('sbar').className='sbar'+(type==='gen'?' gen':'');
}
function addMsg(r,h){var box=document.getElementById('msgs'),d=document.createElement('div');d.className='msg '+r;var b=document.createElement('div');b.className='bubble';b.innerHTML=h;d.appendChild(b);box.appendChild(d);box.scrollTop=box.scrollHeight;}
function showTyping(){var box=document.getElementById('msgs'),el=document.createElement('div');el.className='typing';el.id='typing';el.innerHTML='<span></span><span></span><span></span>';box.appendChild(el);box.scrollTop=box.scrollHeight;}
function hideTyping(){var el=document.getElementById('typing');if(el)el.remove();}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
var bTmr,bPct=0;
function barStart(){var b=document.getElementById('loadbar');b.style.display='block';bPct=0;b.style.transform='scaleX(0)';bTmr=setInterval(()=>{bPct=Math.min(bPct+Math.random()*1.2,88);b.style.transform='scaleX('+bPct/100+')';},300);}
function barStop(){clearInterval(bTmr);var b=document.getElementById('loadbar');b.style.transform='scaleX(1)';setTimeout(()=>{b.style.display='none';b.style.transform='scaleX(0)';},500);}
function mob(tab){var c=document.getElementById('chatPanel'),e=document.getElementById('editorPanel'),mc=document.getElementById('mChat'),me=document.getElementById('mCode');if(tab==='chat'){c.classList.remove('hide');e.classList.add('hide');mc.classList.add('act');me.classList.remove('act');}else{e.classList.remove('hide');c.classList.add('hide');me.classList.add('act');mc.classList.remove('act');}}
document.getElementById('setupOv').addEventListener('click',function(e){if(e.target===this)this.classList.remove('on');});
document.addEventListener('keydown',function(e){if(e.key==='Escape')document.getElementById('setupOv').classList.remove('on');});
</script>
</body>
</html>