<?php
// site_html.php — returns site HTML or project files for preview/editor
require_once __DIR__ . '/config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json');

$user = authUser();
if (!$user) { echo json_encode(['error'=>'Not logged in']); exit; }

$siteId = intval($_GET['site_id'] ?? 0);
if (!$siteId) { echo json_encode(['error'=>'No site ID']); exit; }

$s = getDB()->prepare("SELECT html_content, project_files, project_type, status, slug, name FROM sites WHERE id=? AND user_id=? LIMIT 1");
$s->execute([$siteId, $user['id']]);
$site = $s->fetch();

if (!$site) { echo json_encode(['error'=>'Site not found']); exit; }

$response = [
    'status' => $site['status'],
    'slug'   => $site['slug'],
    'name'   => $site['name'],
    'type'   => $site['project_type'] ?? 'html',
];

// Return project files if this is a multi-file project
if (!empty($site['project_files'])) {
    $files = json_decode($site['project_files'], true) ?: [];
    // Return file metadata + content
    $fileMeta = array_map(function($f) {
        return [
            'path'    => $f['path'],
            'content' => $f['content'],
            'size'    => strlen($f['content'] ?? ''),
            'lines'   => substr_count($f['content'] ?? '', "\n") + 1,
        ];
    }, $files);
    $response['project_files'] = $fileMeta;
    $response['file_count'] = count($files);
}

// Also return html_content for single-file sites
if (!empty($site['html_content'])) {
    $response['html'] = $site['html_content'];
}

echo json_encode($response);