<?php
require_once __DIR__ . '/config/db.php';
$user = requireAuth();
$siteId = intval($_GET['site'] ?? 0);
$site   = null;
if ($siteId) {
    $s = getDB()->prepare("SELECT * FROM sites WHERE id=? AND user_id=? LIMIT 1");
    $s->execute([$siteId, $user['id']]);
    $site = $s->fetch();
}
$siteName      = getSetting('site_name', 'BuildKE');
$downloadPrice = intval(getSetting('download_price', '499'));
$baseUrl       = rtrim(SITE_URL, '/');
$liveUrl       = $site && $site['status'] === 'published' ? $baseUrl . '/sites/' . $site['slug'] . '/' : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title><?= $site ? htmlspecialchars($site['name']) : 'New Site' ?> — <?= htmlspecialchars($siteName) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#07070e;--bg2:#0f0f1a;--bg3:#161622;--bg4:#1c1c2c;
  --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.12);
  --text:#eeeef8;--text2:rgba(238,238,248,.55);--text3:rgba(238,238,248,.3);--text4:rgba(238,238,248,.13);
  --p:#7c3aed;--g:#10b981;--o:#f59e0b;--r:#ef4444;
  --grad:linear-gradient(135deg,#7c3aed,#3b82f6);
  --hh:52px;--cw:360px;--tab-h:58px;
}
html,body{height:100%;overflow:hidden;font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--text);-webkit-font-smoothing:antialiased}

/* HEADER */
.hdr{height:var(--hh);display:flex;align-items:center;padding:0 12px;gap:7px;background:rgba(7,7,14,.95);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);position:relative;z-index:300;flex-shrink:0}
.hdr::after{content:'';position:absolute;bottom:0;left:0;right:0;height:1px;background:var(--grad);opacity:.3}
.logo{font-size:14px;font-weight:900;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;white-space:nowrap;flex-shrink:0}
.hdr-name{flex:1;font-size:11.5px;color:var(--text3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 6px}
.sep{width:1px;height:18px;background:var(--border2);flex-shrink:0}
.hbtn{height:30px;padding:0 10px;border-radius:7px;border:none;cursor:pointer;font-size:11.5px;font-weight:700;display:inline-flex;align-items:center;gap:4px;transition:.15s;text-decoration:none;white-space:nowrap;flex-shrink:0}
.hbtn.ghost{background:rgba(255,255,255,.06);color:var(--text2);border:1px solid var(--border2)}
.hbtn.ghost:hover{background:rgba(255,255,255,.1)}
.hbtn.grn{background:linear-gradient(135deg,#059669,var(--g));color:#fff}
.hbtn.grn:hover{filter:brightness(1.1)}
@media(max-width:420px){.hbl{display:none}}

/* STATUS */
.sbar{height:26px;display:flex;align-items:center;padding:0 12px;gap:7px;background:var(--bg2);border-bottom:1px solid var(--border);font-size:10.5px;color:var(--text3);flex-shrink:0;overflow:hidden;transition:.3s}
.sbar.gen{background:rgba(124,58,237,.06)}
.sbar.db{background:rgba(16,185,129,.06)}
.sdot{width:6px;height:6px;border-radius:50%;background:var(--text4);flex-shrink:0;transition:.3s}
.sdot.gen{background:var(--o);animation:pulse 1s infinite}
.sdot.db{background:var(--g);animation:pulse 1s infinite}
.sdot.ok{background:var(--g)}
.sdot.err{background:var(--r)}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
#loadbar{position:fixed;top:0;left:0;right:0;height:2px;background:var(--grad);transform:scaleX(0);transform-origin:left;z-index:9999;display:none}

/* LAYOUT */
.wrap{display:flex;height:calc(100vh - var(--hh) - 26px);overflow:hidden;position:relative}

/* CHAT */
.chat{width:var(--cw);flex-shrink:0;background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;overflow:hidden}
.msgs{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:9px;-webkit-overflow-scrolling:touch}
.msgs::-webkit-scrollbar{width:3px}
.msgs::-webkit-scrollbar-thumb{background:rgba(255,255,255,.07)}
.msg{display:flex;flex-direction:column;animation:mi .2s ease}
@keyframes mi{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
.msg.u{align-items:flex-end}.msg.a{align-items:flex-start}
.bubble{padding:10px 13px;border-radius:16px;font-size:13px;line-height:1.6;max-width:92%}
.msg.u .bubble{background:var(--grad);color:#fff;border-radius:16px 3px 16px 16px}
.msg.a .bubble{background:var(--bg4);border:1px solid var(--border);border-radius:3px 16px 16px 16px}
.msg.a .bubble a{color:#a78bfa;font-weight:700;text-decoration:none}
.typing{display:flex;gap:4px;padding:10px 12px;background:var(--bg4);border:1px solid var(--border);border-radius:3px 16px 16px 16px;width:fit-content}
.typing span{width:5px;height:5px;border-radius:50%;background:var(--p);animation:td 1.2s ease-in-out infinite}
.typing span:nth-child(2){animation-delay:.2s}.typing span:nth-child(3){animation-delay:.4s}
@keyframes td{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-5px)}}
.sugs{display:flex;flex-wrap:wrap;gap:4px;margin-top:3px}
.sug{padding:4px 9px;background:rgba(124,58,237,.07);border:1px solid rgba(124,58,237,.2);border-radius:20px;font-size:10.5px;color:#c4b5fd;cursor:pointer;transition:.15s;-webkit-tap-highlight-color:transparent}
.sug:active,.sug:hover{background:rgba(124,58,237,.16)}

/* QUICK EDITS */
.qpanel{flex-shrink:0;border-top:1px solid var(--border);padding:9px 10px;background:var(--bg3)}
.q-title{font-size:9.5px;font-weight:800;color:var(--text3);text-transform:uppercase;letter-spacing:.7px;margin-bottom:7px}
.qbtns{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}
.qbtn{height:32px;border-radius:8px;border:1px solid var(--border2);background:var(--bg4);color:var(--text3);font-size:10px;font-weight:700;cursor:pointer;transition:.15s;display:flex;align-items:center;justify-content:center;gap:3px;-webkit-tap-highlight-color:transparent}
.qbtn:active,.qbtn:hover{background:rgba(124,58,237,.1);border-color:rgba(124,58,237,.3);color:#c4b5fd}
.qbtn i{font-size:10px}

/* INPUT */
.input-area{padding:9px 10px 10px;border-top:1px solid var(--border);background:var(--bg2);flex-shrink:0}
.input-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:5px;font-size:9.5px;color:var(--text3)}
.model-tag{font-size:9px;padding:2px 7px;background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.2);border-radius:20px;color:#93c5fd;font-weight:700}
.img-strip{display:none;flex-wrap:wrap;gap:4px;margin-bottom:6px}
.img-wrap{position:relative;width:38px;height:38px}
.img-th{width:38px;height:38px;border-radius:7px;object-fit:cover;border:1.5px solid rgba(124,58,237,.3)}
.img-x{position:absolute;top:-4px;right:-4px;width:14px;height:14px;border-radius:50%;background:var(--r);color:#fff;font-size:8px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:none}
.irow{display:flex;gap:5px;align-items:flex-end}
#chatInput{flex:1;resize:none;height:42px;max-height:100px;background:var(--bg3);border:1.5px solid var(--border2);border-radius:10px;padding:10px 12px;color:var(--text);font-size:13px;font-family:inherit;outline:none;transition:.2s;line-height:1.4;-webkit-appearance:none}
#chatInput:focus{border-color:var(--p);box-shadow:0 0 0 3px rgba(124,58,237,.1)}
#chatInput::placeholder{color:var(--text4)}
.ibtns{display:flex;gap:4px;align-items:flex-end}
.ibtn{width:42px;height:42px;border-radius:10px;border:1.5px solid var(--border2);background:var(--bg3);color:var(--text3);font-size:13px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:.15s}
.ibtn:hover{background:rgba(124,58,237,.1);border-color:rgba(124,58,237,.3);color:#c4b5fd}
#sendBtn{width:42px;height:42px;border-radius:10px;border:none;background:var(--grad);color:#fff;font-size:13px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:.15s;box-shadow:0 2px 8px rgba(124,58,237,.3);-webkit-tap-highlight-color:transparent}
#sendBtn:active{transform:scale(.92)}
#sendBtn:disabled{opacity:.4;cursor:not-allowed;transform:none;box-shadow:none}
#imgInput{display:none}

/* PREVIEW */
.preview{flex:1;display:flex;flex-direction:column;min-width:0}
.ptbar{height:38px;display:flex;align-items:center;gap:6px;padding:0 10px;background:var(--bg3);border-bottom:1px solid var(--border);flex-shrink:0}
.dbtn{width:27px;height:27px;border-radius:6px;border:1px solid var(--border2);background:transparent;color:var(--text3);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:10px;transition:.15s}
.dbtn:hover,.dbtn.on{background:rgba(124,58,237,.12);color:#c4b5fd;border-color:rgba(124,58,237,.3)}
.purl{flex:1;height:25px;background:var(--bg2);border:1px solid var(--border);border-radius:6px;padding:0 9px;font-size:10.5px;color:var(--text3);display:flex;align-items:center;gap:5px;overflow:hidden;cursor:pointer;transition:.15s;text-decoration:none}
.purl:hover{border-color:var(--border2);color:var(--text2)}
.purl span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ptbtn{width:27px;height:27px;border-radius:6px;border:1px solid var(--border2);background:transparent;color:var(--text3);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:10px;transition:.15s}
.ptbtn:hover{background:rgba(255,255,255,.06);color:var(--text2)}
.pwrap{flex:1;overflow:hidden;background:#111;display:flex;justify-content:center;align-items:flex-start;position:relative}
.pwrap.desktop #pframe{width:100%}
.pwrap.tablet  #pframe{width:768px;box-shadow:0 0 0 1px rgba(255,255,255,.05)}
.pwrap.mobile  #pframe{width:390px;box-shadow:0 0 0 1px rgba(255,255,255,.05)}
@media(max-width:768px){.pwrap.tablet #pframe,.pwrap.mobile #pframe{width:100%}}
#pframe{height:100%;border:none;background:#fff;display:none;transition:width .3s}

/* EMPTY */
.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:28px;pointer-events:none}
.empty-ico{width:68px;height:68px;border-radius:18px;background:rgba(124,58,237,.08);border:1px solid rgba(124,58,237,.18);display:flex;align-items:center;justify-content:center;font-size:26px;margin-bottom:4px}
.empty-t{font-size:16px;font-weight:800;color:var(--text2)}
.empty-s{font-size:12px;color:var(--text3);max-width:220px;line-height:1.65}
.chips{display:flex;flex-wrap:wrap;gap:5px;justify-content:center;margin-top:6px}
.chip{padding:3px 9px;background:rgba(124,58,237,.07);border:1px solid rgba(124,58,237,.16);border-radius:20px;font-size:10px;color:var(--text3)}

/* CODE STREAM */
#codeStream{position:absolute;inset:0;background:#05050d;display:none;flex-direction:column}
.cs-bar{height:36px;background:#0a0a14;border-bottom:1px solid rgba(255,255,255,.05);display:flex;align-items:center;padding:0 14px;gap:10px;flex-shrink:0}
.cs-dots{display:flex;gap:4px}
.cs-dot{width:10px;height:10px;border-radius:50%}
.cs-dot.r{background:#ff5f57}.cs-dot.y{background:#febc2e}.cs-dot.g{background:#28c840}
.cs-lbl{font-size:10.5px;color:rgba(167,139,250,.7);font-weight:700;font-family:system-ui}
.cs-chars{margin-left:auto;font-size:10px;color:rgba(255,255,255,.18);font-family:system-ui}
#csPre{flex:1;overflow-y:auto;padding:14px;font-size:11px;line-height:1.8;color:#7dd3fc;white-space:pre-wrap;word-break:break-all;font-family:monospace;margin:0}
#csPre::-webkit-scrollbar{width:3px}
#csPre::-webkit-scrollbar-thumb{background:rgba(255,255,255,.07)}

/* MOBILE */
@media(max-width:768px){
  .chat{position:absolute;top:0;left:0;right:0;height:calc(100% - var(--tab-h));width:100%!important;z-index:10;transition:opacity .2s,transform .18s}
  .preview{position:absolute;top:0;left:0;right:0;height:calc(100% - var(--tab-h));z-index:9;transition:opacity .2s,transform .18s}
  .wrap{height:calc(100vh - var(--hh) - 26px - var(--tab-h))}
  .chat.mob{opacity:1;pointer-events:all;z-index:10;transform:none}
  .preview.mob{opacity:1;pointer-events:all;z-index:10;transform:none}
  .chat:not(.mob){opacity:0;pointer-events:none;transform:translateX(-14px)}
  .preview:not(.mob){opacity:0;pointer-events:none;transform:translateX(14px)}
  .dbtn{display:none}
  #chatInput{font-size:16px}
  .input-area{padding-bottom:calc(var(--tab-h) + env(safe-area-inset-bottom) + 6px)!important}
}
.tabbar{display:none;position:fixed;bottom:0;left:0;right:0;height:calc(var(--tab-h) + env(safe-area-inset-bottom));background:rgba(15,15,26,.96);backdrop-filter:blur(20px);border-top:1px solid var(--border);z-index:400;padding:5px 8px env(safe-area-inset-bottom);align-items:flex-start;justify-content:space-around;gap:4px}
@media(max-width:768px){.tabbar{display:flex}}
.tab{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;cursor:pointer;padding:4px;border:none;background:transparent;color:var(--text3);border-radius:9px;transition:.15s;-webkit-tap-highlight-color:transparent}
.tab.on{color:#c4b5fd;background:rgba(124,58,237,.1)}
.tab i{font-size:18px}.tab span{font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.3px}
.tab-dot{width:5px;height:5px;border-radius:50%;background:var(--g);position:absolute;top:5px;right:calc(50% - 14px);display:none}
.tab-dot.on{display:block}

/* PAY MODAL */
.ov{display:none;position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.8);backdrop-filter:blur(14px);align-items:flex-end;justify-content:center}
.ov.on{display:flex}
@media(min-width:580px){.ov{align-items:center;padding:20px}}
.modal{background:var(--bg2);border:1px solid var(--border2);border-radius:22px 22px 0 0;width:100%;max-width:420px;padding:16px 16px 32px;position:relative;max-height:90vh;overflow-y:auto;animation:su .25s cubic-bezier(.22,1,.36,1)}
@media(min-width:580px){.modal{border-radius:22px;animation:pi .25s cubic-bezier(.22,1,.36,1)}}
@keyframes su{from{transform:translateY(100%)}to{transform:none}}
@keyframes pi{from{opacity:0;transform:scale(.92)}to{opacity:1;transform:none}}
.mhandle{width:34px;height:4px;background:rgba(255,255,255,.1);border-radius:2px;margin:0 auto 16px}
@media(min-width:580px){.mhandle{display:none}}
.mline{position:absolute;top:0;left:0;right:0;height:2px;border-radius:22px 22px 0 0;background:var(--grad)}
.mclose{position:absolute;top:13px;right:13px;width:28px;height:28px;border-radius:7px;background:rgba(255,255,255,.06);border:1px solid var(--border2);color:var(--text2);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:12px}
.mclose:hover{background:rgba(239,68,68,.1);color:var(--r)}
.minput{width:100%;height:50px;background:var(--bg3);border:1.5px solid var(--border2);border-radius:11px;padding:0 13px;color:var(--text);font-size:16px;outline:none;transition:.2s;font-family:inherit;-webkit-appearance:none}
.minput:focus{border-color:var(--p)}
.mbtn{width:100%;height:50px;border-radius:12px;border:none;cursor:pointer;font-size:14px;font-weight:800;color:#fff;display:flex;align-items:center;justify-content:center;gap:7px;transition:.15s;-webkit-tap-highlight-color:transparent}
.mbtn.purple{background:var(--grad);box-shadow:0 4px 16px rgba(124,58,237,.35)}
.mbtn.green{background:linear-gradient(135deg,#059669,var(--g))}
.mbtn:active{transform:scale(.97)}
.mbtn:disabled{opacity:.4;cursor:not-allowed}
.pring{width:48px;height:48px;border-radius:50%;border:3px solid rgba(124,58,237,.2);border-top-color:var(--p);animation:spin .8s linear infinite;margin:0 auto 14px}
@keyframes spin{to{transform:rotate(360deg)}}
</style>
</head>
<body>
<div id="loadbar"></div>

<div class="hdr">
  <div class="logo">⚡ <?= htmlspecialchars($siteName) ?></div>
  <div class="sep"></div>
  <div class="hdr-name" id="hdrName"><?= $site ? htmlspecialchars($site['name']) : 'New Site' ?></div>
  <?php if ($liveUrl): ?>
  <a href="<?= htmlspecialchars($liveUrl) ?>" target="_blank" class="hbtn ghost" title="View live site">
    <i class="fa-solid fa-arrow-up-right-from-square"></i><span class="hbl"> Visit</span>
  </a>
  <?php endif; ?>
  <button class="hbtn ghost" id="hdrDlBtn" onclick="openPay()" style="display:<?= $site?'inline-flex':'none' ?>">
    <i class="fa-solid fa-download"></i><span class="hbl"> Download</span>
  </button>
  <div class="sep"></div>
  <a href="<?= $baseUrl ?>/dashboard.php" class="hbtn ghost" style="padding:0 9px"><i class="fa-solid fa-grid-2"></i></a>
</div>

<div class="sbar" id="sbar">
  <div class="sdot" id="sdot"></div>
  <span id="stxt"><?= $site && $liveUrl ? 'Site is live — describe changes to edit it' : 'Describe your business to build a website' ?></span>
</div>

<div class="wrap">

  <!-- CHAT PANEL -->
  <div class="chat mob" id="chatPanel">
    <div class="msgs" id="msgs">
      <div class="msg a">
        <div class="bubble">
          👋 <strong>Welcome to <?= htmlspecialchars($siteName) ?>!</strong><br><br>
          Describe your business and I'll generate a <strong>complete multi-file PHP website</strong> with pages, admin panel, MySQL database — and deploy it live instantly on our server.<br><br>
          Upload a photo 📸 for design inspiration!
        </div>
      </div>
      <?php if (!$site): ?>
      <div class="sugs" id="sugBox">
        <div class="sug">Glamour Beauty Salon, Nairobi, pink & gold</div>
        <div class="sug">Spice Route Restaurant, dark luxury theme</div>
        <div class="sug">MediCare Clinic, blue & white, appointments</div>
        <div class="sug">Prime Properties real estate, dark & gold</div>
        <div class="sug">E-commerce shop with cart & M-Pesa</div>
        <div class="sug">Sunset Hotel, luxury tropical feel</div>
        <div class="sug">St. Mary's School, admissions & fees</div>
        <div class="sug">Church website with events & giving</div>
      </div>
      <?php endif; ?>
    </div>

    <?php if ($site): ?>
    <div class="qpanel">
      <div class="q-title">⚡ Quick Edits</div>
      <div class="qbtns">
        <button class="qbtn" onclick="qe('Change to a bold dark theme with gold accents')"><i class="fa-solid fa-palette"></i> Dark Theme</button>
        <button class="qbtn" onclick="qe('Add WhatsApp floating button and improve contact form')"><i class="fa-brands fa-whatsapp"></i> WhatsApp</button>
        <button class="qbtn" onclick="qe('Add scroll animations to all sections')"><i class="fa-solid fa-wand-magic-sparkles"></i> Animations</button>
        <button class="qbtn" onclick="qe('Add a pricing section with 3 tiers and M-Pesa payment info')"><i class="fa-solid fa-tag"></i> Pricing</button>
        <button class="qbtn" onclick="qe('Add a testimonials carousel with star ratings')"><i class="fa-solid fa-star"></i> Reviews</button>
        <button class="qbtn" onclick="qe('Fix mobile responsiveness — hamburger menu, responsive grid')"><i class="fa-solid fa-mobile-screen"></i> Mobile</button>
        <button class="qbtn" onclick="qe('Add FAQ accordion section with 6 questions')"><i class="fa-solid fa-circle-question"></i> FAQ</button>
        <button class="qbtn" onclick="qe('Add image gallery with lightbox managed from admin panel')"><i class="fa-solid fa-images"></i> Gallery</button>
        <button class="qbtn" onclick="qe('Improve the admin panel — add dashboard stats, better UI')"><i class="fa-solid fa-shield-halved"></i> Admin</button>
      </div>
    </div>
    <?php endif; ?>

    <div class="input-area">
      <div class="input-top">
        <span><i class="fa-solid fa-wand-magic-sparkles" style="color:#c4b5fd;margin-right:3px"></i><?= $site ? 'Describe your changes' : 'Describe your website' ?></span>
        <span class="model-tag">PHP · MySQL · Live Deploy</span>
      </div>
      <div class="img-strip" id="imgStrip"></div>
      <div class="irow">
        <textarea id="chatInput" placeholder="<?= $site ? 'e.g. Change colors to navy blue and add a gallery section...' : 'e.g. A luxury hotel called Sunset Resort in Mombasa...' ?>" rows="1" autocomplete="off" autocorrect="off"></textarea>
        <div class="ibtns">
          <button class="ibtn" onclick="document.getElementById('imgInput').click()" title="Upload image"><i class="fa-solid fa-image"></i></button>
          <button id="sendBtn"><i class="fa-solid fa-paper-plane"></i></button>
        </div>
      </div>
      <input type="file" id="imgInput" accept="image/*" multiple>
    </div>
  </div>

  <!-- PREVIEW PANEL -->
  <div class="preview" id="previewPanel">
    <div class="ptbar">
      <button class="dbtn on" id="bd" onclick="setDev('desktop')"><i class="fa-solid fa-desktop"></i></button>
      <button class="dbtn" id="bt" onclick="setDev('tablet')"><i class="fa-solid fa-tablet-screen-button"></i></button>
      <button class="dbtn" id="bm" onclick="setDev('mobile')"><i class="fa-solid fa-mobile-screen"></i></button>
      <a class="purl" id="purlBtn" href="#" target="_blank">
        <i class="fa-solid fa-circle" style="color:var(--g);font-size:5px;flex-shrink:0"></i>
        <span id="purlTxt"><?= $liveUrl ?: 'Your site URL appears here' ?></span>
      </a>
      <button class="ptbtn" onclick="toggleCode()" title="View Code" id="codeBtn"><i class="fa-solid fa-code"></i></button>
      <button class="ptbtn" onclick="reload()" title="Refresh"><i class="fa-solid fa-rotate-right"></i></button>
    </div>
    <div class="pwrap desktop" id="pwrap">
      <div class="empty" id="emptyState">
        <div class="empty-ico">🌐</div>
        <div class="empty-t">Your website previews here</div>
        <div class="empty-s">Every generated site has multiple pages, admin panel, and MySQL database</div>
        <div class="chips">
          <span class="chip">📁 Multi-file PHP</span>
          <span class="chip">🗄️ MySQL DB</span>
          <span class="chip">🔐 Admin Panel</span>
          <span class="chip">📱 Mobile Ready</span>
          <span class="chip">⚡ Live Instantly</span>
        </div>
      </div>
      <div id="codeStream">
        <div class="cs-bar">
          <div class="cs-dots"><div class="cs-dot r"></div><div class="cs-dot y"></div><div class="cs-dot g"></div></div>
          <span class="cs-lbl" id="csLbl">⚡ Generating...</span>
          <span class="cs-chars" id="csChars">0 chars</span>
        </div>
        <pre id="csPre"></pre>
      </div>
      <iframe id="pframe" sandbox="allow-scripts allow-forms allow-same-origin allow-popups"></iframe>
    </div>
  </div>
</div>

<!-- MOBILE TABS -->
<div class="tabbar">
  <button class="tab on" id="tabChat" onclick="mob('chat')"><i class="fa-solid fa-comments"></i><span>Chat</span></button>
  <button class="tab" id="tabPreview" onclick="mob('preview')" style="position:relative">
    <div class="tab-dot" id="tabDot"></div>
    <i class="fa-solid fa-globe"></i><span>Preview</span>
  </button>
  <button class="tab" onclick="openPay()"><i class="fa-solid fa-download"></i><span>Download</span></button>
</div>

<!-- PAY MODAL -->
<div class="ov" id="payOv">
  <div class="modal">
    <div class="mhandle"></div>
    <div class="mline"></div>
    <button class="mclose" onclick="closePay()"><i class="fa-solid fa-xmark"></i></button>
    <div id="payS1">
      <div style="font-size:17px;font-weight:900;margin-bottom:3px">Download Your Website</div>
      <div style="font-size:12px;color:var(--text2);margin-bottom:16px">Get all files as a ZIP to host anywhere</div>
      <div style="font-size:28px;font-weight:900;letter-spacing:-1px;margin-bottom:2px">KES <span><?= $downloadPrice ?></span></div>
      <div style="font-size:12px;color:var(--text2);margin-bottom:14px">One-time · includes all PHP files + SQL</div>
      <div style="height:1px;background:var(--border);margin:12px 0"></div>
      <label style="font-size:11px;font-weight:800;color:var(--text3);display:block;margin-bottom:6px;text-transform:uppercase;letter-spacing:.5px">M-Pesa Number</label>
      <input type="tel" class="minput" id="payPhone" placeholder="07XX XXX XXX" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" style="margin-bottom:12px">
      <button class="mbtn purple" id="payBtn" onclick="startPay()"><i class="fa-solid fa-mobile-screen"></i> Pay with M-Pesa</button>
    </div>
    <div id="payS2" style="display:none;text-align:center;padding-top:20px">
      <div class="pring"></div>
      <div style="font-size:15px;font-weight:900;margin-bottom:5px">Check Your Phone</div>
      <div style="font-size:12px;color:var(--text2);margin-bottom:12px">Enter M-Pesa PIN to complete</div>
      <div style="font-size:24px;font-weight:900;color:var(--g);margin-bottom:4px">KES <?= $downloadPrice ?></div>
      <div id="payResult" style="margin-top:12px"></div>
      <button class="mbtn" style="height:44px;background:rgba(255,255,255,.06);border:1px solid var(--border2);color:var(--text2);margin-top:10px" onclick="closePay()">Cancel</button>
    </div>
  </div>
</div>

<script>
var SID=<?= $site?intval($site['id']):'null' ?>,BASE='<?= $baseUrl ?>',DP=<?= $downloadPrice ?>;
var SURL='<?= $liveUrl ?>',SLUG='<?= $site?addslashes($site['slug']??''):'' ?>';
var HIST=[],IMGS=[],PAYID=null,POLL=null,GEN=false,CODE=false;

// Init
document.addEventListener('DOMContentLoaded',function(){
    var ta=document.getElementById('chatInput');
    ta.addEventListener('input',function(){this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px';});
    ta.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey&&window.innerWidth>768){e.preventDefault();send();}});
    document.getElementById('sendBtn').addEventListener('click',send);
    document.getElementById('imgInput').addEventListener('change',handleImgs);
    document.querySelectorAll('.sug').forEach(function(el){
        el.addEventListener('click',function(){
            document.getElementById('chatInput').value=this.textContent.trim();
            document.getElementById('chatInput').focus();
        });
    });
    // If existing site is published, show iframe
    if(SURL){
        var fr=document.getElementById('pframe'),ep=document.getElementById('emptyState');
        fr.src=SURL;fr.style.display='block';ep.style.display='none';
        document.getElementById('purlBtn').href=SURL;
        document.getElementById('purlTxt').textContent=SURL;
    }
});

// Quick edit
function qe(t){document.getElementById('chatInput').value=t;send();}

// Images
function handleImgs(e){
    Array.from(e.target.files).slice(0,2-IMGS.length).forEach(function(f){
        if(!f.type.startsWith('image/')||f.size>4*1024*1024)return;
        var r=new FileReader();r.onload=function(ev){IMGS.push({b64:ev.target.result.split(',')[1],type:f.type});renderStrip();};r.readAsDataURL(f);
    });e.target.value='';
}
function renderStrip(){
    var s=document.getElementById('imgStrip');s.innerHTML='';
    if(!IMGS.length){s.style.display='none';return;}s.style.display='flex';
    IMGS.forEach(function(img,i){
        var w=document.createElement('div');w.className='img-wrap';
        w.innerHTML='<img class="img-th" src="data:'+img.type+';base64,'+img.b64+'"><button class="img-x" onclick="IMGS.splice('+i+',1);renderStrip()">✕</button>';
        s.appendChild(w);
    });
}

// SEND
function send(){
    if(GEN)return;
    var ta=document.getElementById('chatInput'),msg=ta.value.trim();
    if(!msg&&!IMGS.length)return;
    if(!msg)msg='Use the uploaded image as design reference.';

    GEN=true;
    var btn=document.getElementById('sendBtn');
    btn.disabled=true;ta.value='';ta.style.height='42px';
    var sb=document.getElementById('sugBox');if(sb)sb.remove();

    addMsg('u',esc(msg)+(IMGS.length?' <span style="opacity:.6;font-size:11px">📸 +'+IMGS.length+'</span>':''));
    HIST.push({role:'user',content:msg});
    setStatus('gen','Generating your website...');
    barStart();showCodeStream();
    if(window.innerWidth<=768)mob('preview');

    var payload={prompt:msg,site_id:SID,history:HIST.slice(-6),mode:SID?'edit':'create'};
    if(IMGS.length)payload.images=IMGS.map(function(i){return{base64:i.b64,type:i.type};});
    IMGS=[];renderStrip();

    fetch(BASE+'/generate.php',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
    .then(function(res){
        if(!res.ok)return res.text().then(function(t){throw new Error('HTTP '+res.status+': '+t.slice(0,150));});
        var reader=res.body.getReader(),dec=new TextDecoder(),buf='',evt='';
        function pump(){
            return reader.read().then(function(r){
                if(r.done){if(GEN)fail('Stream ended unexpectedly');return;}
                buf+=dec.decode(r.value,{stream:true});
                var lines=buf.split('\n');buf=lines.pop();
                for(var i=0;i<lines.length;i++){
                    var l=lines[i].trim();
                    if(l.startsWith('event:')){evt=l.slice(6).trim();}
                    else if(l.startsWith('data:')){
                        try{
                            var d=JSON.parse(l.slice(5).trim());
                            if(evt==='status') handleStatus(d);
                            else if(evt==='fileplan') handleFilePlan(d);
                            else if(evt==='filegen') handleFileGen(d);
                            else if(evt==='progress') updateProgress(d.chars);
                            else if(evt==='done') handleDone(d,msg,btn);
                            else if(evt==='error') fail(d.message||'Error',btn);
                        }catch(e){}
                        evt='';
                    }
                }
                return pump();
            });
        }
        return pump();
    })
    .catch(function(e){fail(e.message,btn);});
}

function handleStatus(d){
    var msg=d.msg||'Working...';
    setStatus(msg.includes('database')||msg.includes('Database')?'db':'gen', msg);
    document.getElementById('csLbl').textContent='⚡ '+msg;
}

function handleFilePlan(d){
    var pre=document.getElementById('csPre');
    pre.textContent='Generating '+d.total+' files:\n\n'+d.files.join('\n');
    document.getElementById('csChars').textContent='0/'+d.total+' files';
}

function handleFileGen(d){
    var pre=document.getElementById('csPre');
    var lines=pre.textContent.split('\n');
    var result=lines.map(function(line){
        var clean=line.replace(/^[✅⚡]\s*/,'');
        if(clean===d.file) return '⚡ '+d.file;
        if(lines.indexOf(line)>0 && lines.indexOf(line)<d.index) return '✅ '+clean;
        return clean;
    });
    pre.textContent=result.join('\n');
    pre.scrollTop=pre.scrollHeight;
    document.getElementById('csChars').textContent=d.index+'/'+d.total+' files';
    document.getElementById('csLbl').textContent='⚡ Writing '+d.file;
}

function updateProgress(chars){
    document.getElementById('csChars').textContent=(chars||0).toLocaleString()+' chars';
}

function handleDone(d,msg,btn){
    GEN=false;btn.disabled=false;barStop();
    hideCodeStream();
    SID=d.site_id||SID;SLUG=d.slug||SLUG;SURL=d.url||'';
    history.replaceState(null,'','?site='+SID);
    document.getElementById('hdrName').textContent=SLUG.replace(/-/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
    document.getElementById('hdrDlBtn').style.display='inline-flex';

    // Load live site in iframe
    if(d.url){
        var fr=document.getElementById('pframe'),ep=document.getElementById('emptyState');
        fr.src=d.url+'?t='+Date.now();fr.style.display='block';ep.style.display='none';
        document.getElementById('purlBtn').href=d.url;
        document.getElementById('purlTxt').textContent=d.url;
        document.getElementById('tabDot').classList.add('on');
    }

    var dbNote=d.db_created?'<br>🗄️ MySQL database created & populated':'';
    var errNote=d.errors&&d.errors.length?'<br>⚠️ '+d.errors.length+' write error(s)':'';
    setStatus('ok', d.file_count+' files deployed · Live at '+d.url);
    HIST.push({role:'assistant',content:'[generated]'});
    addMsg('a',
        '✅ <strong>'+d.file_count+' files generated & live!</strong>'+dbNote+errNote
        +'<br>🌐 <a href="'+d.url+'" target="_blank">'+d.url+'</a>'
        +'<br>🔐 Admin: <a href="'+d.admin_url+'" target="_blank">'+d.admin_url+'</a>'
        +'<br><small style="opacity:.55">Admin password: admin123 — change after login</small>'
    );
    if(window.innerWidth<=768)mob('preview');
}

function fail(msg,btn){
    GEN=false;if(btn)btn.disabled=false;barStop();hideCodeStream();
    setStatus('err',msg.substring(0,70));
    addMsg('a','❌ '+esc(msg));
    if(window.innerWidth<=768)mob('chat');
}

// Code stream display
function showCodeStream(){
    document.getElementById('pframe').style.display='none';
    document.getElementById('emptyState').style.display='none';
    document.getElementById('csPre').textContent='';
    document.getElementById('csChars').textContent='0 chars';
    document.getElementById('codeStream').style.display='flex';
}
function hideCodeStream(){
    document.getElementById('codeStream').style.display='none';
    if(SURL){document.getElementById('pframe').style.display='block';}
}
function toggleCode(){
    if(!SURL){alert('Generate a website first.');return;}
    CODE=!CODE;
    if(CODE){
        fetch(SURL,{mode:'no-cors'}).catch(()=>{});
        document.getElementById('pframe').style.display='none';
        document.getElementById('csLbl').textContent='📄 Live Site Code';
        document.getElementById('codeStream').style.display='flex';
        document.getElementById('codeBtn').innerHTML='<i class="fa-solid fa-eye"></i>';
        // Fetch the index.php source
        fetch(BASE+'/site_html.php?site_id='+SID,{credentials:'include'})
        .then(r=>r.json()).then(function(d){
            if(d.project_files&&d.project_files.length){
                var src=d.project_files[0].content||'';
                document.getElementById('csPre').textContent=src;
                document.getElementById('csChars').textContent=src.length.toLocaleString()+' chars';
            }
        });
    } else {
        document.getElementById('codeStream').style.display='none';
        document.getElementById('pframe').style.display='block';
        document.getElementById('codeBtn').innerHTML='<i class="fa-solid fa-code"></i>';
    }
}
function reload(){if(SURL)document.getElementById('pframe').src=SURL+'?t='+Date.now();}
function setDev(d){document.getElementById('pwrap').className='pwrap '+d;['desktop','tablet','mobile'].forEach(x=>document.getElementById('b'+x[0]).classList.toggle('on',x===d));}

// Messages
function addMsg(r,h){var b=document.getElementById('msgs'),d=document.createElement('div');d.className='msg '+r;var bbl=document.createElement('div');bbl.className='bubble';bbl.innerHTML=h;d.appendChild(bbl);b.appendChild(d);b.scrollTop=b.scrollHeight;}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

// Status
function setStatus(type,msg){
    var dot=document.getElementById('sdot'),t=document.getElementById('stxt'),bar=document.getElementById('sbar');
    dot.className='sdot'+(type?' '+type:'');t.textContent=msg;
    bar.className='sbar'+(type==='gen'?' gen':type==='db'?' db':'');
}

// Load bar
var bTmr,bPct=0;
function barStart(){var b=document.getElementById('loadbar');b.style.display='block';b.style.transition='none';b.style.transform='scaleX(0)';bPct=0;bTmr=setInterval(()=>{bPct=Math.min(bPct+Math.random()*1.5,88);b.style.transition='transform .3s';b.style.transform='scaleX('+bPct/100+')';},400);}
function barStop(){clearInterval(bTmr);var b=document.getElementById('loadbar');b.style.transform='scaleX(1)';setTimeout(()=>{b.style.display='none';b.style.transform='scaleX(0)';},500);}

// Mobile tabs
function mob(tab){
    var c=document.getElementById('chatPanel'),p=document.getElementById('previewPanel');
    var tc=document.getElementById('tabChat'),tp=document.getElementById('tabPreview');
    if(tab==='chat'){c.classList.add('mob');p.classList.remove('mob');tc.classList.add('on');tp.classList.remove('on');}
    else{p.classList.add('mob');c.classList.remove('mob');tp.classList.add('on');tc.classList.remove('on');}
}

// Pay modal
function openPay(){
    if(!SID){alert('Generate a website first!');return;}
    document.getElementById('payOv').classList.add('on');
    document.getElementById('payS1').style.display='block';
    document.getElementById('payS2').style.display='none';
    document.getElementById('payBtn').disabled=false;
    document.getElementById('payBtn').innerHTML='<i class="fa-solid fa-mobile-screen"></i> Pay with M-Pesa';
}
function closePay(){document.getElementById('payOv').classList.remove('on');if(POLL){clearInterval(POLL);POLL=null;}}
function startPay(){
    var ph=document.getElementById('payPhone').value.trim();
    if(!ph){alert('Enter M-Pesa number');return;}
    var btn=document.getElementById('payBtn');btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Sending...';
    fetch(BASE+'/pay.php',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({site_id:SID,type:'download',phone:ph})})
    .then(r=>r.json()).then(function(d){
        if(d.already_paid){window.location.href=BASE+'/download.php?site_id='+SID;closePay();return;}
        if(d.error){alert(d.error);btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-mobile-screen"></i> Pay with M-Pesa';return;}
        PAYID=d.pay_id;
        document.getElementById('payS1').style.display='none';
        document.getElementById('payS2').style.display='block';
        POLL=setInterval(function(){
            fetch(BASE+'/pay.php',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
                body:JSON.stringify({action:'poll',pay_id:PAYID})})
            .then(r=>r.json()).then(function(pd){
                if(pd.status==='completed'){
                    clearInterval(POLL);
                    document.getElementById('payResult').innerHTML='<button class="mbtn green" onclick="window.location.href=BASE+\'/download.php?site_id=\'+SID;closePay()"><i class="fa-solid fa-file-zipper"></i> Download ZIP Now</button>';
                } else if(pd.status==='failed'){
                    clearInterval(POLL);
                    document.getElementById('payResult').innerHTML='<div style="color:var(--r);font-weight:700;font-size:13px">Payment failed. Try again.</div>';
                }
            });
        },5000);
    }).catch(function(){alert('Connection failed.');btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-mobile-screen"></i> Pay with M-Pesa';});
}
document.getElementById('payOv').addEventListener('click',function(e){if(e.target===this)closePay();});
document.addEventListener('keydown',function(e){if(e.key==='Escape')closePay();});
</script>
</body>
</html>