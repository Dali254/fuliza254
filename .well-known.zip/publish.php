<?php
// publish.php — publish a site to our hosting (single file OR multi-file project)
require_once __DIR__ . '/config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json');

$user = authUser();
if (!$user) { echo json_encode(['error' => 'Not logged in']); exit; }

$siteId = intval($_POST['site_id'] ?? $_GET['site_id'] ?? 0);
if (!$siteId) { echo json_encode(['error' => 'No site specified']); exit; }

$db = getDB();

// Load site
$s = $db->prepare("SELECT * FROM sites WHERE id=? AND user_id=? LIMIT 1");
$s->execute([$siteId, $user['id']]);
$site = $s->fetch();
if (!$site) { echo json_encode(['error' => 'Site not found']); exit; }

// Check payment
if (!in_array($site['status'], ['paid', 'published', 'expired'])) {
    $p = $db->prepare("SELECT id FROM payments WHERE site_id=? AND user_id=? AND status='completed' AND type='hosting' LIMIT 1");
    $p->execute([$siteId, $user['id']]);
    if (!$p->fetch()) {
        echo json_encode(['error' => 'Please complete hosting payment first']);
        exit;
    }
}

$siteSlug = $site['slug'];
$siteDir  = __DIR__ . '/sites/' . $siteSlug . '/';
$siteUrl  = rtrim(getSetting('site_url', SITE_URL), '/') . '/sites/' . $siteSlug . '/';

// Create directory
if (!is_dir($siteDir)) {
    if (!mkdir($siteDir, 0755, true)) {
        echo json_encode(['error' => 'Could not create site directory. Check folder permissions.']);
        exit;
    }
}

// ── Detect project type ────────────────────────────────────────────────────────
$projectFiles = !empty($site['project_files']) ? json_decode($site['project_files'], true) : null;
$isMultiFile  = is_array($projectFiles) && count($projectFiles) > 0;
$htmlContent  = $site['html_content'] ?? '';
$isPhpSingle  = !$isMultiFile && strpos(ltrim($htmlContent), '<?php') === 0;

// ── Case 1: Multi-file project (from project_builder) ─────────────────────────
if ($isMultiFile) {

    $hasPhp = false;
    foreach ($projectFiles as $file) {
        $path    = ltrim($file['path'] ?? '', './\\');
        $content = $file['content'] ?? '';
        if (empty($path)) continue;

        // Create subdirectories
        $fullPath = $siteDir . $path;
        $dir      = dirname($fullPath);
        if (!is_dir($dir)) mkdir($dir, 0755, true);

        // Fix DB paths if SQLite — redirect database.db to a data/ folder
        if (preg_match('/\bnew PDO\s*\(\s*["\']sqlite:/i', $content)) {
            // Move SQLite DB outside web root to a data folder
            $content = preg_replace(
                '/new PDO\s*\(\s*["\']sqlite:([^"\']+)["\']/',
                "new PDO('sqlite:' . __DIR__ . '/../../data/" . $siteSlug . ".db'",
                $content
            );
            $hasPhp = true;

            // Create the data folder if needed
            $dataDir = __DIR__ . '/data/';
            if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);

            // Protect data folder
            if (!file_exists($dataDir . '.htaccess')) {
                file_put_contents($dataDir . '.htaccess', "Deny from all\n");
            }
        }

        if (pathinfo($path, PATHINFO_EXTENSION) === 'php') $hasPhp = true;

        file_put_contents($fullPath, $content);
    }

    // Write main .htaccess for the project
    $ht = "DirectoryIndex index.php index.html\n"
        . "Options -Indexes\n"
        . "<IfModule mod_rewrite.c>\n"
        . "    RewriteEngine On\n"
        . "    RewriteCond %{REQUEST_FILENAME} !-f\n"
        . "    RewriteCond %{REQUEST_FILENAME} !-d\n"
        . "    RewriteRule ^ index.php [QSA,L]\n"
        . "</IfModule>\n"
        . "# Protect sensitive files\n"
        . "<FilesMatch \"\\.env$|database\\.db$|config\\.php$\">\n"
        . "    Order allow,deny\n"
        . "    Deny from all\n"
        . "</FilesMatch>\n";

    // Only write if no .htaccess was in the project files
    $hasHtaccess = false;
    foreach ($projectFiles as $f) {
        if (basename($f['path'] ?? '') === '.htaccess') { $hasHtaccess = true; break; }
    }
    if (!$hasHtaccess) {
        file_put_contents($siteDir . '.htaccess', $ht);
    }

// ── Case 2: Single PHP file (from main builder) ────────────────────────────────
} elseif ($isPhpSingle) {

    // Fix SQLite path — move database outside web root
    $content = $htmlContent;
    if (preg_match('/new PDO\s*\(\s*["\']sqlite:/i', $content)) {
        $dataDir = __DIR__ . '/data/';
        if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
        if (!file_exists($dataDir . '.htaccess')) {
            file_put_contents($dataDir . '.htaccess', "Deny from all\n");
        }

        // Replace sqlite path with secure absolute path
        $dbFile  = $siteSlug . '.db';
        $content = preg_replace(
            '/new PDO\s*\(\s*["\']sqlite:[^"\']*["\']/',
            "new PDO('sqlite:' . dirname(__DIR__,2) . '/data/" . $dbFile . "'",
            $content
        );
    }

    // Write index.php
    if (file_put_contents($siteDir . 'index.php', $content) === false) {
        echo json_encode(['error' => 'Could not write index.php — check folder permissions']);
        exit;
    }

    // Write .htaccess — pass ALL query strings and paths to index.php
    $ht = "DirectoryIndex index.php\n"
        . "Options -Indexes\n"
        . "<IfModule mod_rewrite.c>\n"
        . "    RewriteEngine On\n"
        . "    RewriteCond %{REQUEST_FILENAME} !-f\n"
        . "    RewriteRule ^ index.php [QSA,L]\n"
        . "</IfModule>\n"
        . "<FilesMatch \"\\.db$\">\n"
        . "    Order allow,deny\n"
        . "    Deny from all\n"
        . "</FilesMatch>\n";
    file_put_contents($siteDir . '.htaccess', $ht);

// ── Case 3: Static HTML site ────────────────────────────────────────────────────
} else {

    if (empty($htmlContent)) {
        echo json_encode(['error' => 'No site content found. Please generate the site first.']);
        exit;
    }
    if (file_put_contents($siteDir . 'index.html', $htmlContent) === false) {
        echo json_encode(['error' => 'Could not write index.html — check folder permissions']);
        exit;
    }

    // Simple htaccess for static
    $ht = "DirectoryIndex index.html\nOptions -Indexes\n";
    file_put_contents($siteDir . '.htaccess', $ht);
}

// ── Update DB status ────────────────────────────────────────────────────────────
$db->prepare("UPDATE sites SET status='published' WHERE id=?")->execute([$siteId]);

// ── Test the site is actually reachable ────────────────────────────────────────
// Check what index file exists
$indexFile = file_exists($siteDir . 'index.php')  ? 'index.php'
           : (file_exists($siteDir . 'index.html') ? 'index.html' : null);

if (!$indexFile) {
    echo json_encode(['error' => 'Files were written but no index file found in ' . $siteDir]);
    exit;
}

echo json_encode([
    'success'     => true,
    'url'         => $siteUrl,
    'slug'        => $siteSlug,
    'type'        => $isMultiFile ? 'multi-file' : ($isPhpSingle ? 'php' : 'html'),
    'index_file'  => $indexFile,
    'file_count'  => $isMultiFile ? count($projectFiles) : 1,
    'message'     => 'Site is now live!',
]);