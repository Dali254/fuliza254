-- WebBuilder Kenya — Database Setup
-- Run this once in phpMyAdmin or MySQL CLI

CREATE DATABASE IF NOT EXISTS webbuilder CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE webbuilder;

CREATE TABLE IF NOT EXISTS users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    phone         VARCHAR(20)  NOT NULL,
    password      VARCHAR(255) NOT NULL,
    credits       INT DEFAULT 0,
    plan          ENUM('free','basic','pro') DEFAULT 'free',
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sites (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id       INT UNSIGNED NOT NULL,
    name          VARCHAR(150) NOT NULL,
    slug          VARCHAR(150) NOT NULL UNIQUE,
    description   TEXT,
    html_content  LONGTEXT,
    prompt        TEXT,
    status        ENUM('draft','paid','published') DEFAULT 'draft',
    downloads     INT DEFAULT 0,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_slug (slug)
);

CREATE TABLE IF NOT EXISTS payments (
    id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id              INT UNSIGNED NOT NULL,
    site_id              INT UNSIGNED,
    amount               DECIMAL(10,2) NOT NULL,
    phone                VARCHAR(20) NOT NULL,
    checkout_request_id  VARCHAR(100),
    mpesa_receipt        VARCHAR(50),
    type                 ENUM('download','hosting','credits') DEFAULT 'download',
    status               ENUM('pending','completed','failed') DEFAULT 'pending',
    created_at           DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_checkout   (checkout_request_id),
    INDEX idx_user       (user_id)
);

CREATE TABLE IF NOT EXISTS chat_history (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    site_id    INT UNSIGNED NOT NULL,
    role       ENUM('user','assistant') NOT NULL,
    content    LONGTEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_site (site_id)
);

-- Settings
CREATE TABLE IF NOT EXISTS settings (
    `key`   VARCHAR(100) PRIMARY KEY,
    `value` TEXT
);

INSERT IGNORE INTO settings VALUES
('site_name',        'BuildKE'),
('site_url',         'https://yourdomain.co.ke'),
('anthropic_api_key',''),
('mpesa_consumer_key',''),
('mpesa_consumer_secret',''),
('mpesa_shortcode',  ''),
('mpesa_passkey',    ''),
('mpesa_env',        'sandbox'),
('download_price',   '499'),
('hosting_price',    '299'),
('currency',         'KES');
