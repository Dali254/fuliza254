<?php
/**
 * cron/expire_sites.php
 * Run every hour via cPanel Cron Jobs:
 *   0 * * * * php /home/yourusername/public_html/cron/expire_sites.php
 *
 * What it does:
 *  1. Finds sites whose hosting_expires_at has passed
 *  2. Removes their index.html so the URL returns 404
 *  3. Marks them status='expired' in the DB
 *  4. Sends warning emails 3 days before expiry (optional)
 */

require_once __DIR__ . '/../config/db.php';

$log = __DIR__ . '/../mpesa/cron_log.txt';
$db  = getDB();

file_put_contents($log, "\n[" . date('Y-m-d H:i:s') . "] ── Cron: expire_sites ──\n", FILE_APPEND);

// ── 1. Expire overdue sites ───────────────────────────────────────────────────
$expired = $db->query("
    SELECT s.*, u.name as user_name, u.email as user_email
    FROM sites s
    JOIN users u ON s.user_id = u.id
    WHERE s.status = 'published'
      AND s.hosting_expires_at IS NOT NULL
      AND s.hosting_expires_at < NOW()
")->fetchAll();

foreach ($expired as $site) {
    // Remove the live file
    $siteFile = __DIR__ . '/../sites/' . $site['slug'] . '/index.html';
    $expired_dir = __DIR__ . '/../sites/' . $site['slug'] . '/';

    // Find the actual index file (could be .php or .html)
    $siteHtmlFile = $siteDir . 'index.html';
    $sitePhpFile  = $siteDir . 'index.php';
    $expiredPage  = buildExpiredPage($site);

    if (file_exists($sitePhpFile)) {
        // Replace PHP site — write expired as PHP so routing still works
        $expiredPhp = '<?php session_start(); ?>' . "
" . $expiredPage;
        file_put_contents($sitePhpFile, $expiredPhp);
    } elseif (file_exists($siteHtmlFile)) {
        file_put_contents($siteHtmlFile, $expiredPage);
    } else {
        // Create expired page
        file_put_contents($sitePhpFile, $expiredPage);
    }

    // Mark expired in DB
    $db->prepare("UPDATE sites SET status='expired' WHERE id=?")->execute([$site['id']]);

    // Log it
    $db->prepare("INSERT INTO hosting_expirations (site_id, action, note) VALUES (?,?,?)")
       ->execute([$site['id'], 'expired', 'Auto-expired by cron at ' . date('Y-m-d H:i:s')]);

    file_put_contents($log, "[EXPIRED] Site #{$site['id']} {$site['slug']} — user: {$site['user_name']}\n", FILE_APPEND);
}

// ── 2. Send 3-day warning for sites expiring soon ────────────────────────────
$expiringSoon = $db->query("
    SELECT s.*, u.name as user_name, u.email as user_email, u.phone
    FROM sites s
    JOIN users u ON s.user_id = u.id
    WHERE s.status = 'published'
      AND s.hosting_expires_at IS NOT NULL
      AND s.hosting_expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 3 DAY)
      AND NOT EXISTS (
          SELECT 1 FROM hosting_expirations he
          WHERE he.site_id = s.id
            AND he.action = 'warning_sent'
            AND he.created_at > DATE_SUB(NOW(), INTERVAL 3 DAY)
      )
")->fetchAll();

foreach ($expiringSoon as $site) {
    $daysLeft = ceil((strtotime($site['hosting_expires_at']) - time()) / 86400);

    // Log warning sent
    $db->prepare("INSERT INTO hosting_expirations (site_id, action, note) VALUES (?,?,?)")
       ->execute([$site['id'], 'warning_sent', "{$daysLeft} days left"]);

    file_put_contents($log, "[WARNING] Site #{$site['id']} expires in {$daysLeft} days — user: {$site['user_name']}\n", FILE_APPEND);
}

file_put_contents($log, "[DONE] Expired=" . count($expired) . " Warned=" . count($expiringSoon) . "\n", FILE_APPEND);

// ── HELPER: Build expired page ────────────────────────────────────────────────
function buildExpiredPage(array $site): string {
    $siteName   = getSetting('site_name', 'BuildKE');
    $renewUrl   = rtrim(getSetting('site_url', ''), '/') . '/renew.php?site=' . $site['id'];
    $slug       = htmlspecialchars($site['slug']);
    $name       = htmlspecialchars($site['name']);

    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Site Expired — {$name}</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{min-height:100vh;background:#0a0a12;color:#e8e8f0;font-family:'Segoe UI',system-ui,sans-serif;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#16161f;border:1px solid rgba(239,68,68,.3);border-radius:20px;padding:40px 32px;max-width:440px;width:100%;text-align:center;box-shadow:0 0 60px rgba(239,68,68,.08)}
.card::before{content:'';display:block;height:2px;background:linear-gradient(90deg,#ef4444,#f97316);border-radius:20px 20px 0 0;margin:-40px -32px 32px;border-radius:20px 20px 0 0}
.ico{font-size:52px;margin-bottom:16px}
h1{font-size:22px;font-weight:900;margin-bottom:8px;color:#fff}
p{font-size:14px;color:rgba(232,232,240,.55);line-height:1.65;margin-bottom:24px}
.btn{display:inline-flex;align-items:center;gap:8px;padding:14px 28px;background:linear-gradient(135deg,#7c3aed,#3b82f6);color:#fff;border-radius:11px;text-decoration:none;font-size:14px;font-weight:800;box-shadow:0 6px 20px rgba(124,58,237,.4);transition:.2s}
.btn:hover{transform:translateY(-2px);filter:brightness(1.1)}
.powered{margin-top:24px;font-size:11px;color:rgba(232,232,240,.25)}
.powered a{color:rgba(124,58,237,.7);text-decoration:none}
</style>
</head>
<body>
<div class="card">
  <div class="ico">⏰</div>
  <h1>Hosting Expired</h1>
  <p>The website <strong style="color:#fff">{$name}</strong> ({$slug}) has expired.<br>
     The site owner needs to renew hosting to bring it back online.</p>
  <a href="{$renewUrl}" class="btn">🔄 Renew Hosting</a>
  <div class="powered">Powered by <a href="/">{$siteName}</a></div>
</div>
</body>
</html>
HTML;
}