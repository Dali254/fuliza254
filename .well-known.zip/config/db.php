<?php
// config/db.php — edit these values for your hosting

define('DB_HOST', 'localhost');
define('DB_NAME', 'lipawinc_beb');
define('DB_USER', 'lipawinc_beb');         // your DB username
define('DB_PASS', 'lipawinc_beb');             // your DB password
define('SITE_URL', 'https://m.lipawin.com'); // no trailing slash
define('ANTHROPIC_KEY', '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');       // fallback — overridden by DB setting


// ── PDO Connection ────────────────────────────────────────────────────────────
function getDB(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $pdo = new PDO(
            'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
    } catch (PDOException $e) {
        die(json_encode(['error' => 'DB connection failed: ' . $e->getMessage()]));
    }
    return $pdo;
}

// ── Settings ──────────────────────────────────────────────────────────────────
function getSetting(string $key, string $default = ''): string {
    static $cache = [];
    if (isset($cache[$key])) return $cache[$key];
    $s = getDB()->prepare("SELECT `value` FROM settings WHERE `key`=? LIMIT 1");
    $s->execute([$key]);
    $r = $s->fetchColumn();
    return $cache[$key] = ($r !== false ? $r : $default);
}

// ── Auth helpers ──────────────────────────────────────────────────────────────
function authUser(): ?array {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['user_id'])) return null;
    $s = getDB()->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
    $s->execute([$_SESSION['user_id']]);
    return $s->fetch() ?: null;
}

function requireAuth(): array {
    $u = authUser();
    if (!$u) {
        // If AJAX request — return JSON, never redirect
        $isAjax = (
            isset($_SERVER['HTTP_X_REQUESTED_WITH']) ||
            str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') ||
            str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')
        );
        if ($isAjax) {
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Session expired. Please refresh the page and login again.']);
            exit;
        }
        header('Location: ' . SITE_URL . '/auth.php');
        exit;
    }
    return $u;
}

function loginUser(array $user): void {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
}

// ── Slug generator ────────────────────────────────────────────────────────────
function makeSlug(string $text): string {
    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $text));
    $slug = trim($slug, '-');
    // ensure unique
    $base = $slug; $i = 1;
    while (true) {
        $s = getDB()->prepare("SELECT id FROM sites WHERE slug=? LIMIT 1");
        $s->execute([$slug]);
        if (!$s->fetch()) break;
        $slug = $base . '-' . $i++;
    }
    return $slug;
}

// ── Sanitize ──────────────────────────────────────────────────────────────────
function clean(string $v): string {
    return htmlspecialchars(strip_tags(trim($v)), ENT_QUOTES, 'UTF-8');
}

// ── JSON response ─────────────────────────────────────────────────────────────
function jsonOut(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// ── Phone normalize ───────────────────────────────────────────────────────────
function normalizePhone(string $p): string {
    $p = preg_replace('/\D/', '', $p);
    if (strlen($p) === 9)  return '254' . $p;
    if (strlen($p) === 10) return '254' . substr($p, 1);
    return $p;
}