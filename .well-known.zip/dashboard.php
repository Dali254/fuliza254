<?php
require_once __DIR__ . '/config/db.php';
$user  = requireAuth();
$sites = getDB()->prepare("SELECT * FROM sites WHERE user_id=? ORDER BY updated_at DESC");
$sites->execute([$user['id']]);
$sites = $sites->fetchAll();
$siteName = getSetting('site_name', 'BuildKE');
$siteUrl  = rtrim(getSetting('site_url', SITE_URL), '/');
$totalSites   = count($sites);
$publishedCnt = count(array_filter($sites, fn($s) => $s['status']==='published'));
$paidCnt      = count(array_filter($sites, fn($s) => in_array($s['status'],['paid','published'])));
$totalDl      = array_sum(array_column($sites, 'downloads'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
<title>My Sites — <?= htmlspecialchars($siteName) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#07070e;--bg2:#0f0f18;--bg3:#161622;--bg4:#1c1c2a;
  --border:rgba(255,255,255,.06);--border2:rgba(255,255,255,.11);--border3:rgba(255,255,255,.17);
  --text:#eeeef6;--text2:rgba(238,238,246,.52);--text3:rgba(238,238,246,.28);
  --p:#7c3aed;--b:#3b82f6;--g:#10b981;--r:#ef4444;--o:#f59e0b;
  --grad:linear-gradient(135deg,#7c3aed,#3b82f6);
  --card-r:18px;
}
html{scroll-behavior:smooth}
body{min-height:100vh;background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;-webkit-font-smoothing:antialiased;overflow-x:hidden;
  background-image:radial-gradient(ellipse 120% 60% at 50% -5%,rgba(124,58,237,.14) 0%,transparent 60%)}

/* ── HEADER ── */
.hdr{
  position:sticky;top:0;z-index:200;height:58px;
  display:flex;align-items:center;padding:0 clamp(14px,4vw,28px);gap:10px;
  background:rgba(7,7,14,.82);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border-bottom:1px solid var(--border);
}
.logo{font-size:16px;font-weight:900;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;white-space:nowrap;flex-shrink:0;letter-spacing:-.2px}
.hdr-gap{flex:1}
.av{width:30px;height:30px;border-radius:9px;background:var(--grad);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;color:#fff;flex-shrink:0}
.hdr-name{font-size:13px;color:var(--text2);flex-shrink:0;white-space:nowrap}
.btn{height:34px;padding:0 14px;border-radius:9px;border:none;cursor:pointer;font-size:12.5px;font-weight:700;display:inline-flex;align-items:center;gap:5px;transition:all .18s;text-decoration:none;white-space:nowrap;flex-shrink:0;-webkit-tap-highlight-color:transparent}
.btn-grad{background:var(--grad);color:#fff;box-shadow:0 3px 14px rgba(124,58,237,.38)}
.btn-grad:hover{filter:brightness(1.1);transform:translateY(-1px)}
.btn-ghost{background:rgba(255,255,255,.06);color:var(--text2);border:1px solid var(--border2)}
.btn-ghost:hover{background:rgba(255,255,255,.1);color:var(--text)}
.icon-btn{width:34px;padding:0;border-radius:9px}
@media(max-width:480px){.hdr-name{display:none}.btn .bl{display:none}.btn-grad{padding:0 10px}}

/* ── BODY WRAP ── */
.wrap{max-width:1120px;margin:0 auto;padding:0 clamp(14px,4vw,28px) 60px}

/* ── HERO ── */
.hero{padding:32px 0 24px;display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap}
.hero-t{font-size:clamp(22px,5vw,30px);font-weight:900;letter-spacing:-.5px;line-height:1.2}
.hero-t em{font-style:normal;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.hero-s{font-size:13px;color:var(--text2);margin-top:5px}

/* ── STATS ── */
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:32px}
@media(max-width:560px){.stats{grid-template-columns:repeat(2,1fr)}}
.stat{
  background:var(--bg2);border:1px solid var(--border);border-radius:14px;
  padding:clamp(14px,3vw,20px);position:relative;overflow:hidden;
  transition:transform .2s,border-color .2s;
}
.stat::after{content:'';position:absolute;inset:0;background:var(--grad);opacity:0;transition:opacity .2s}
.stat:hover{transform:translateY(-2px);border-color:rgba(124,58,237,.28)}
.stat-v{font-size:clamp(24px,5vw,32px);font-weight:900;letter-spacing:-1.5px;line-height:1;position:relative;z-index:1}
.stat-l{font-size:10.5px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.7px;margin-top:5px;position:relative;z-index:1}
.stat-ico{position:absolute;right:14px;top:50%;transform:translateY(-50%);font-size:26px;opacity:.07}

/* ── SECTION ── */
.sec-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:10px}
.sec-title{font-size:13.5px;font-weight:800;display:flex;align-items:center;gap:7px;color:var(--text2);text-transform:uppercase;letter-spacing:.6px}
.sec-count{padding:2px 8px;background:rgba(124,58,237,.14);color:#b39dff;border-radius:20px;font-size:10.5px;font-weight:800}

/* ── GRID ── */
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,290px),1fr));gap:14px}

/* ── NEW CARD ── */
.new-card{
  background:rgba(124,58,237,.04);border:2px dashed rgba(124,58,237,.2);
  border-radius:var(--card-r);min-height:260px;display:flex;flex-direction:column;
  align-items:center;justify-content:center;gap:10px;text-decoration:none;
  transition:all .22s;-webkit-tap-highlight-color:transparent;cursor:pointer;
}
.new-card:hover{background:rgba(124,58,237,.1);border-color:rgba(124,58,237,.5);transform:translateY(-3px)}
.new-ring{width:54px;height:54px;border-radius:50%;background:rgba(124,58,237,.12);border:1.5px solid rgba(124,58,237,.3);display:flex;align-items:center;justify-content:center;font-size:22px;transition:.2s}
.new-card:hover .new-ring{transform:scale(1.1);background:rgba(124,58,237,.2)}
.new-t{font-size:14px;font-weight:800;color:var(--text2)}
.new-s{font-size:12px;color:var(--text3);text-align:center;max-width:170px;line-height:1.55}

/* ── SITE CARD ── */
.site-card{
  background:var(--bg2);border:1px solid var(--border);
  border-radius:var(--card-r);overflow:hidden;
  display:flex;flex-direction:column;transition:all .22s;
}
.site-card:hover{border-color:rgba(124,58,237,.32);transform:translateY(-3px);box-shadow:0 18px 52px rgba(0,0,0,.4)}

/* thumb */
.thumb{height:155px;background:var(--bg3);position:relative;overflow:hidden;flex-shrink:0}
.thumb-frame{width:200%;height:200%;transform:scale(.5);transform-origin:top left;pointer-events:none;border:none;background:#fff}
.thumb-ph{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:38px;opacity:.12}
.thumb-fade{position:absolute;inset:0;background:linear-gradient(to bottom,transparent 35%,rgba(15,15,24,.97) 100%)}

/* badges */
.status{position:absolute;top:10px;left:10px;padding:3px 9px;border-radius:20px;font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.4px;backdrop-filter:blur(8px)}
.status.draft{background:rgba(245,158,11,.18);color:var(--o);border:1px solid rgba(245,158,11,.3)}
.status.paid{background:rgba(16,185,129,.18);color:var(--g);border:1px solid rgba(16,185,129,.3)}
.status.published{background:rgba(59,130,246,.18);color:#60a5fa;border:1px solid rgba(59,130,246,.3)}
.status.expired{background:rgba(239,68,68,.18);color:var(--r);border:1px solid rgba(239,68,68,.3)}
.exp-pill{position:absolute;top:10px;right:10px;padding:3px 8px;border-radius:20px;font-size:9px;font-weight:700;backdrop-filter:blur(8px)}
.exp-pill.ok{background:rgba(16,185,129,.15);color:var(--g);border:1px solid rgba(16,185,129,.25)}
.exp-pill.warn{background:rgba(245,158,11,.15);color:var(--o);border:1px solid rgba(245,158,11,.25)}
.exp-pill.dead{background:rgba(239,68,68,.15);color:var(--r);border:1px solid rgba(239,68,68,.25)}

/* info */
.sinfo{padding:13px 15px 15px;flex:1;display:flex;flex-direction:column;gap:9px}
.sname{font-size:13.5px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.smeta{font-size:11px;color:var(--text3);display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.smeta-dot{width:3px;height:3px;border-radius:50%;background:var(--text3);flex-shrink:0}
.slink{font-size:10.5px;color:rgba(96,165,250,.7);font-family:monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer;transition:.15s}
.slink:hover{color:#93c5fd}

/* actions */
.sacts{display:flex;flex-direction:column;gap:6px;margin-top:auto}
.srow{display:flex;gap:6px}
.sact{
  flex:1;height:36px;border-radius:10px;border:1px solid var(--border2);
  background:transparent;color:var(--text2);font-size:11.5px;font-weight:700;
  cursor:pointer;transition:all .18s;display:flex;align-items:center;justify-content:center;
  gap:5px;text-decoration:none;-webkit-tap-highlight-color:transparent;
}
.sact:hover,.sact:active{background:rgba(124,58,237,.1);border-color:rgba(124,58,237,.32);color:#c4b5fd}
.sact.edit{background:var(--grad);color:#fff;border:none;box-shadow:0 3px 10px rgba(124,58,237,.3)}
.sact.edit:hover{filter:brightness(1.1)}
.sact.view{background:linear-gradient(135deg,#059669,var(--g));color:#fff;border:none}
.sact.dl{background:rgba(59,130,246,.12);color:#60a5fa;border:1px solid rgba(59,130,246,.25)}
.sact.renew{background:linear-gradient(135deg,#059669,var(--g));color:#fff;border:none}
.sact.buy{background:rgba(245,158,11,.12);color:var(--o);border:1px solid rgba(245,158,11,.25)}
.sact.del{background:rgba(239,68,68,.08);color:var(--r);border:1px solid rgba(239,68,68,.2)}
.sact.del:hover{background:var(--r);color:#fff;border-color:var(--r)}

/* ── MODAL ── */
.ov{display:none;position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);align-items:flex-end;justify-content:center}
.ov.on{display:flex}
@media(min-width:520px){.ov{align-items:center;padding:20px}}
.mbox{background:var(--bg2);border-radius:22px 22px 0 0;width:100%;max-width:380px;padding:22px 20px 36px;border:1px solid var(--border2);position:relative;animation:suUp .28s cubic-bezier(.22,1,.36,1)}
@media(min-width:520px){.mbox{border-radius:22px;padding:28px 24px;animation:popIn .28s cubic-bezier(.22,1,.36,1)}}
@keyframes suUp{from{transform:translateY(100%)}to{transform:none}}
@keyframes popIn{from{opacity:0;transform:scale(.9)}to{opacity:1;transform:none}}
.mbar{width:36px;height:4px;border-radius:2px;background:rgba(255,255,255,.14);margin:0 auto 20px}
@media(min-width:520px){.mbar{display:none}}
.m-ico{width:58px;height:58px;border-radius:50%;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);display:flex;align-items:center;justify-content:center;font-size:24px;color:var(--r);margin:0 auto 14px}
.m-title{font-size:18px;font-weight:900;text-align:center;margin-bottom:6px}
.m-sub{font-size:13px;color:var(--text2);text-align:center;margin-bottom:22px;line-height:1.6}
.m-btns{display:flex;gap:9px}
.m-btn{flex:1;height:48px;border-radius:12px;border:none;cursor:pointer;font-size:14px;font-weight:800;display:flex;align-items:center;justify-content:center;gap:7px;transition:.18s;-webkit-tap-highlight-color:transparent}
.m-cancel{background:rgba(255,255,255,.07);color:var(--text2);border:1px solid var(--border2)}
.m-cancel:hover{background:rgba(255,255,255,.12);color:var(--text)}
.m-delete{background:linear-gradient(135deg,#dc2626,var(--r));color:#fff;box-shadow:0 4px 16px rgba(239,68,68,.4)}
.m-delete:hover{filter:brightness(1.1)}

/* ── TOAST ── */
.toast{position:fixed;bottom:clamp(16px,4vw,28px);left:50%;transform:translateX(-50%) translateY(60px);background:var(--bg3);border:1px solid var(--border3);color:var(--text);border-radius:14px;padding:12px 20px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;box-shadow:0 8px 32px rgba(0,0,0,.45);z-index:9999;opacity:0;transition:all .3s cubic-bezier(.22,1,.36,1);white-space:nowrap;max-width:90vw;pointer-events:none}
.toast.show{transform:translateX(-50%) translateY(0);opacity:1}

/* ── EMPTY ── */
.empty{text-align:center;padding:80px 20px}
.empty-ico{font-size:58px;opacity:.12;margin-bottom:14px}
.empty-t{font-size:22px;font-weight:900;margin-bottom:8px}
.empty-s{font-size:14px;color:var(--text2);margin-bottom:26px;max-width:280px;margin-inline:auto;line-height:1.65}
</style>
</head>
<body>

<header class="hdr">
  <div class="logo">⚡ <?= htmlspecialchars($siteName) ?></div>
  <div class="hdr-gap"></div>
  <div class="av"><?= strtoupper(substr($user['name'],0,1)) ?></div>
  <span class="hdr-name"><?= htmlspecialchars(explode(' ',$user['name'])[0]) ?></span>
  <a href="<?= $siteUrl ?>/builder.php" class="btn btn-grad">
    <i class="fa-solid fa-plus"></i><span class="bl"> New Site</span>
  </a>
  <a href="<?= $siteUrl ?>/logout.php" class="btn btn-ghost icon-btn" title="Logout">
    <i class="fa-solid fa-right-from-bracket"></i>
  </a>
</header>

<div class="wrap">
  <!-- HERO -->
  <div class="hero">
    <div>
      <div class="hero-t">My <em>Websites</em> 🌐</div>
      <div class="hero-s">All your AI-built sites in one place</div>
    </div>
    <a href="<?= $siteUrl ?>/builder.php" class="btn btn-grad" style="height:40px;font-size:13px;padding:0 18px;align-self:center">
      <i class="fa-solid fa-wand-magic-sparkles"></i> Build New
    </a>
  </div>

  <!-- STATS -->
  <div class="stats">
    <div class="stat">
      <div class="stat-v"><?= $totalSites ?></div>
      <div class="stat-l">Total Sites</div>
      <i class="fa-solid fa-globe stat-ico"></i>
    </div>
    <div class="stat">
      <div class="stat-v" style="color:#60a5fa"><?= $publishedCnt ?></div>
      <div class="stat-l">Live Now</div>
      <i class="fa-solid fa-rocket stat-ico"></i>
    </div>
    <div class="stat">
      <div class="stat-v" style="color:#b39dff"><?= $paidCnt ?></div>
      <div class="stat-l">Purchased</div>
      <i class="fa-solid fa-receipt stat-ico"></i>
    </div>
    <div class="stat">
      <div class="stat-v" style="color:var(--o)"><?= $totalDl ?></div>
      <div class="stat-l">Downloads</div>
      <i class="fa-solid fa-download stat-ico"></i>
    </div>
  </div>

  <!-- SITES -->
  <?php if (empty($sites)): ?>
  <div class="empty">
    <div class="empty-ico">🌐</div>
    <div class="empty-t">No websites yet</div>
    <div class="empty-s">Create your first AI website in minutes — just describe what you need!</div>
    <a href="<?= $siteUrl ?>/builder.php" class="btn btn-grad" style="height:48px;padding:0 28px;font-size:14px;border-radius:13px;display:inline-flex">
      <i class="fa-solid fa-wand-magic-sparkles"></i> Build My First Site
    </a>
  </div>

  <?php else: ?>
  <div class="sec-head">
    <div class="sec-title">
      <i class="fa-solid fa-layer-group" style="font-size:11px"></i>
      All Sites
      <span class="sec-count"><?= $totalSites ?></span>
    </div>
  </div>

  <div class="grid">

    <a href="<?= $siteUrl ?>/builder.php" class="new-card">
      <div class="new-ring">✨</div>
      <div class="new-t">Create New Site</div>
      <div class="new-s">Describe your business and AI builds it in seconds</div>
    </a>

    <?php foreach ($sites as $s):
      $live    = $s['status'] === 'published';
      $isPaid  = in_array($s['status'], ['paid','published']);
      $expired = $s['status'] === 'expired';
      $expiry  = $s['hosting_expires_at'] ?? null;
      $dLeft   = $expiry ? ceil((strtotime($expiry)-time())/86400) : null;
      $liveUrl = $siteUrl.'/sites/'.$s['slug'].'/';
    ?>
    <div class="site-card" id="c<?= $s['id'] ?>">
      <div class="thumb">
        <?php if ($s['html_content']): ?>
        <iframe class="thumb-frame" srcdoc="<?= htmlspecialchars(substr($s['html_content'],0,5000)) ?>" sandbox loading="lazy"></iframe>
        <?php else: ?>
        <div class="thumb-ph">🌐</div>
        <?php endif; ?>
        <div class="thumb-fade"></div>
        <span class="status <?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span>
        <?php if ($expiry):
          $pc = $dLeft<=0?'dead':($dLeft<=7?'warn':'ok');
          $pt = $dLeft<=0?'Expired':($dLeft<=7?"⚠ {$dLeft}d left":date('M j',strtotime($expiry)));
        ?><span class="exp-pill <?= $pc ?>"><?= $pt ?></span><?php endif; ?>
      </div>

      <div class="sinfo">
        <div class="sname"><?= htmlspecialchars($s['name']) ?></div>
        <div class="smeta">
          <span><?= date('M j, Y', strtotime($s['updated_at'])) ?></span>
          <?php if ($s['downloads']): ?>
          <div class="smeta-dot"></div>
          <span><?= $s['downloads'] ?> dl</span>
          <?php endif; ?>
        </div>

        <?php if ($live): ?>
        <div class="slink" onclick="copyLink('<?= htmlspecialchars($liveUrl) ?>')" title="Click to copy link">
          <i class="fa-solid fa-link" style="margin-right:3px"></i><?= htmlspecialchars($liveUrl) ?>
        </div>
        <?php endif; ?>

        <div class="sacts">
          <div class="srow">
            <a href="<?= $siteUrl ?>/builder.php?site=<?= $s['id'] ?>" class="sact edit">
              <i class="fa-solid fa-pen-to-square"></i> Edit
            </a>
            <?php if ($live): ?>
            <a href="<?= htmlspecialchars($liveUrl) ?>" target="_blank" class="sact view">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> Visit
            </a>
            <?php elseif ($isPaid): ?>
            <a href="<?= $siteUrl ?>/download.php?site_id=<?= $s['id'] ?>" class="sact dl">
              <i class="fa-solid fa-download"></i> ZIP
            </a>
            <?php endif; ?>
          </div>
          <div class="srow">
            <?php if ($expired): ?>
            <a href="<?= $siteUrl ?>/renew.php?site=<?= $s['id'] ?>" class="sact renew">
              <i class="fa-solid fa-rotate-right"></i> Renew Hosting
            </a>
            <?php elseif (!$isPaid): ?>
            <a href="<?= $siteUrl ?>/builder.php?site=<?= $s['id'] ?>" class="sact buy">
              <i class="fa-solid fa-cart-shopping"></i> Purchase
            </a>
            <?php elseif ($live && $expiry): ?>
            <a href="<?= $siteUrl ?>/renew.php?site=<?= $s['id'] ?>" class="sact">
              <i class="fa-solid fa-calendar-plus"></i> Extend
            </a>
            <?php else: ?>
            <a href="<?= $siteUrl ?>/download.php?site_id=<?= $s['id'] ?>" class="sact dl">
              <i class="fa-solid fa-file-zipper"></i> Download ZIP
            </a>
            <?php endif; ?>
            <button class="sact del" onclick="confirmDel(<?= $s['id'] ?>,'<?= htmlspecialchars(addslashes($s['name'])) ?>')">
              <i class="fa-solid fa-trash"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- DELETE MODAL -->
<div class="ov" id="delOv">
  <div class="mbox">
    <div class="mbar"></div>
    <div class="m-ico"><i class="fa-solid fa-trash"></i></div>
    <div class="m-title">Delete Site?</div>
    <div class="m-sub">Permanently delete <strong id="delName"></strong>?<br>This cannot be undone.</div>
    <div class="m-btns">
      <button class="m-btn m-cancel" onclick="closeDel()">Cancel</button>
      <button class="m-btn m-delete" id="delBtn"><i class="fa-solid fa-trash"></i> Delete</button>
    </div>
  </div>
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<script>
var BASE='<?= $siteUrl ?>',DEL_ID=null,toTmr;

function confirmDel(id,name){
  DEL_ID=id;
  document.getElementById('delName').textContent=name;
  document.getElementById('delBtn').disabled=false;
  document.getElementById('delBtn').innerHTML='<i class="fa-solid fa-trash"></i> Delete';
  document.getElementById('delOv').classList.add('on');
}
function closeDel(){document.getElementById('delOv').classList.remove('on');DEL_ID=null;}

document.getElementById('delBtn').onclick=function(){
  if(!DEL_ID)return;
  this.disabled=true;this.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Deleting…';
  fetch(BASE+'/delete_site.php',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({site_id:DEL_ID})})
  .then(r=>r.json()).then(d=>{
    closeDel();
    if(d.success){
      var el=document.getElementById('c'+DEL_ID);
      if(el){el.style.transition='all .3s';el.style.opacity='0';el.style.transform='scale(.88)';setTimeout(()=>el.remove(),300);}
      toast('ok','✅ Site deleted');
    }else toast('err','❌ '+(d.error||'Delete failed'));
  }).catch(()=>{closeDel();toast('err','❌ Connection error');});
};

document.getElementById('delOv').addEventListener('click',e=>{if(e.target===e.currentTarget)closeDel();});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeDel();});

function copyLink(url){
  if(navigator.clipboard){navigator.clipboard.writeText(url).then(()=>toast('ok','🔗 Link copied!'));}
}

function toast(type,msg){
  var el=document.getElementById('toast');
  el.innerHTML=msg;el.className='toast '+type;
  clearTimeout(toTmr);void el.offsetWidth;
  el.classList.add('show');
  toTmr=setTimeout(()=>el.classList.remove('show'),3200);
}
</script>
</body>
</html>