<?php
// set_slug.php — let user change their site's slug/URL
require_once __DIR__ . '/config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json');

$user = authUser();
if (!$user) { echo json_encode(['error'=>'Not logged in']); exit; }

$body   = json_decode(file_get_contents('php://input'), true);
$siteId = intval($body['site_id'] ?? 0);
$newSlug = strtolower(trim($body['slug'] ?? ''));

if (!$siteId || !$newSlug) { echo json_encode(['error'=>'Missing fields']); exit; }

// Clean slug — only letters, numbers, hyphens, max 30 chars
$newSlug = preg_replace('/[^a-z0-9\-]/', '', $newSlug);
$newSlug = preg_replace('/-+/', '-', $newSlug);
$newSlug = trim($newSlug, '-');
$newSlug = substr($newSlug, 0, 30);

if (strlen($newSlug) < 3) { echo json_encode(['error'=>'Slug too short — min 3 characters']); exit; }

// Check site belongs to user
$s = getDB()->prepare("SELECT id, slug, status FROM sites WHERE id=? AND user_id=? LIMIT 1");
$s->execute([$siteId, $user['id']]);
$site = $s->fetch();
if (!$site) { echo json_encode(['error'=>'Site not found']); exit; }

// Check not taken by another site
$chk = getDB()->prepare("SELECT id FROM sites WHERE slug=? AND id!=? LIMIT 1");
$chk->execute([$newSlug, $siteId]);
if ($chk->fetch()) { echo json_encode(['error'=>'That URL is already taken. Try another.']); exit; }

// If site was published — rename the folder
if ($site['status'] === 'published') {
    $oldDir = __DIR__ . '/sites/' . $site['slug'] . '/';
    $newDir = __DIR__ . '/sites/' . $newSlug . '/';
    if (is_dir($oldDir)) {
        rename($oldDir, $newDir);
    }
}

// Update slug in DB
getDB()->prepare("UPDATE sites SET slug=? WHERE id=?")->execute([$newSlug, $siteId]);

$siteUrl = rtrim(SITE_URL, '/') . '/sites/' . $newSlug . '/';
echo json_encode(['success'=>true, 'slug'=>$newSlug, 'url'=>$siteUrl]);