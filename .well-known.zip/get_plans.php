<?php
// get_plans.php — returns active hosting plans as JSON
require_once __DIR__ . '/config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json');

$user = authUser();
if (!$user) { echo json_encode(['error'=>'Not logged in','plans'  =>[]]); exit; }

$plans = getDB()->query("
    SELECT id, name, duration_days, price, description
    FROM hosting_plans
    WHERE is_active=1
    ORDER BY sort_order ASC
")->fetchAll();

echo json_encode(['plans' => $plans]);