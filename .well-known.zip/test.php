<?php
// repair_site.php — fixes missing config/config.php and includes/functions.php
// on already-deployed sites. Run once then DELETE.
require_once __DIR__ . '/config/db.php';

$sitesDir = __DIR__ . '/sites/';
$fixed = [];

foreach (glob($sitesDir . '*/') as $siteDir) {
    $slug = basename($siteDir);

    // Get site info from our DB to get real values
    $s = getDB()->prepare("SELECT name, project_db_name FROM sites WHERE slug=? LIMIT 1");
    $s->execute([$slug]);
    $site = $s->fetch();
    if (!$site) continue;

    $siteName = $site['name'] ?: ucwords(str_replace('-', ' ', $slug));
    $dbName   = $site['project_db_name'] ?: DB_NAME;

    $repaired = [];

    // Fix config/config.php if missing or empty
    $configDir = $siteDir . 'config/';
    if (!is_dir($configDir)) mkdir($configDir, 0755, true);

    $configFile = $configDir . 'config.php';
    if (!file_exists($configFile) || filesize($configFile) < 20) {
        file_put_contents($configFile,
'<?php
defined(\'SITE_NAME\')    || define(\'SITE_NAME\',    \'' . addslashes($siteName) . '\');
defined(\'SITE_PHONE\')   || define(\'SITE_PHONE\',   \'+254 700 000 000\');
defined(\'SITE_EMAIL\')   || define(\'SITE_EMAIL\',   \'info@' . $slug . '.co.ke\');
defined(\'SITE_ADDRESS\') || define(\'SITE_ADDRESS\', \'Nairobi, Kenya\');
defined(\'WHATSAPP_NUM\') || define(\'WHATSAPP_NUM\', \'254700000000\');
defined(\'CURRENCY\')     || define(\'CURRENCY\',     \'KES\');
defined(\'SITE_URL\')     || define(\'SITE_URL\',     \'\');'
        );
        $repaired[] = 'config/config.php';
    }

    // Fix includes/functions.php if missing or empty
    $includesDir = $siteDir . 'includes/';
    if (!is_dir($includesDir)) mkdir($includesDir, 0755, true);

    $functionsFile = $includesDir . 'functions.php';
    if (!file_exists($functionsFile) || filesize($functionsFile) < 50) {
        file_put_contents($functionsFile,
'<?php
function sanitize($s) { return htmlspecialchars(strip_tags(trim((string)$s)), ENT_QUOTES, \'UTF-8\'); }
function redirect($url) { header(\'Location: \'.$url); exit; }
function flash($msg, $type=\'success\') { $_SESSION[\'flash\'] = [\'msg\'=>$msg,\'type\'=>$type]; }
function get_flash() { $f=$_SESSION[\'flash\']??null; unset($_SESSION[\'flash\']); return $f; }
function is_admin() { return !empty($_SESSION[\'admin_logged_in\']); }
function require_admin() { if(!is_admin()){header(\'Location:../admin/login.php\');exit;} }
function format_price($n) { return \'KES \'.number_format((float)$n,2); }
function time_ago($dt) {
    $d=time()-strtotime($dt);
    if($d<60) return $d.\'s ago\';
    if($d<3600) return round($d/60).\'m ago\';
    if($d<86400) return round($d/3600).\'h ago\';
    return round($d/86400).\'d ago\';
}
function generate_csrf() {
    if(empty($_SESSION[\'csrf\'])) $_SESSION[\'csrf\']=bin2hex(random_bytes(16));
    return $_SESSION[\'csrf\'];
}
function verify_csrf($t) { return isset($_SESSION[\'csrf\']) && hash_equals($_SESSION[\'csrf\'],$t); }
function show_flash() {
    $f=get_flash(); if(!$f) return;
    $bg=$f[\'type\']==\'success\'?\'#d1fae5\':\'#fee2e2\';
    $col=$f[\'type\']==\'success\'?\'#065f46\':\'#991b1b\';
    echo \'<div style="padding:12px 16px;background:\'.$bg.\';color:\'.$col.\';border-radius:8px;margin:12px 0;font-weight:600;">\'.sanitize($f[\'msg\']).\'</div>\';
}'
        );
        $repaired[] = 'includes/functions.php';
    }

    // Fix index.php if it has wrong require paths
    $indexFile = $siteDir . 'index.php';
    if (file_exists($indexFile)) {
        $idx = file_get_contents($indexFile);
        // Fix DB_HOST → SITE_DB_HOST
        $fixed_idx = preg_replace('/(?<!\w)DB_HOST(?!\w)/', 'SITE_DB_HOST', $idx);
        $fixed_idx = preg_replace('/(?<!\w)DB_NAME(?!\w)/', 'SITE_DB_NAME', $fixed_idx);
        $fixed_idx = preg_replace('/(?<!\w)DB_USER(?!\w)/', 'SITE_DB_USER', $fixed_idx);
        $fixed_idx = preg_replace('/(?<!\w)DB_PASS(?!\w)/', 'SITE_DB_PASS', $fixed_idx);
        if ($fixed_idx !== $idx) {
            file_put_contents($indexFile, $fixed_idx);
            $repaired[] = 'index.php (constants fixed)';
        }
    }

    // Fix all PHP files — rename DB_ constants
    $phpFiles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($siteDir));
    foreach ($phpFiles as $file) {
        if ($file->getExtension() !== 'php') continue;
        $c    = file_get_contents($file->getRealPath());
        $orig = $c;
        $c = preg_replace('/(?<!\w)DB_HOST(?!\w)/', 'SITE_DB_HOST', $c);
        $c = preg_replace('/(?<!\w)DB_NAME(?!\w)/', 'SITE_DB_NAME', $c);
        $c = preg_replace('/(?<!\w)DB_USER(?!\w)/', 'SITE_DB_USER', $c);
        $c = preg_replace('/(?<!\w)DB_PASS(?!\w)/', 'SITE_DB_PASS', $c);
        if ($c !== $orig) file_put_contents($file->getRealPath(), $c);
    }

    // Fix config/db.php — ensure using SITE_DB_ constants with defined() guards
    $dbFile = $configDir . 'db.php';
    if (file_exists($dbFile)) {
        $db = file_get_contents($dbFile);
        // If it still has raw defines without defined() guard, fix it
        if (strpos($db, 'defined(') === false && strpos($db, 'SITE_DB_HOST') !== false) {
            $db = preg_replace(
                '/define\(["\']SITE_DB_(HOST|NAME|USER|PASS)["\'],\s*([^)]+)\)/',
                'defined("SITE_DB_$1") || define("SITE_DB_$1", $2)',
                $db
            );
            file_put_contents($dbFile, $db);
            $repaired[] = 'config/db.php (defined guards added)';
        }
    }

    if ($repaired) {
        $fixed[$slug] = $repaired;
    }
}

echo '<pre style="font-family:monospace;padding:20px;background:#0f0f1a;color:#e8e8f0;border-radius:8px">';
echo "✅ Repair complete\n\n";
if ($fixed) {
    echo "Sites fixed:\n";
    foreach ($fixed as $slug => $files) {
        echo "\n  📁 $slug\n";
        foreach ($files as $f) echo "     ✓ $f\n";
    }
} else {
    echo "No broken files found — all sites look OK!\n";
}
echo "\n⚠️  DELETE this file now: repair_site.php\n";
echo '</pre>';