<?php
// get_file.php — returns a single project file's content
require_once __DIR__ . '/config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json');

$user = authUser();
if (!$user) { echo json_encode(['error'=>'Not logged in']); exit; }

$siteId = intval($_GET['site_id'] ?? 0);
$path   = trim($_GET['path'] ?? '');

if (!$siteId || !$path) { echo json_encode(['error'=>'Missing params']); exit; }

$s = getDB()->prepare("SELECT project_files FROM sites WHERE id=? AND user_id=? LIMIT 1");
$s->execute([$siteId, $user['id']]);
$row = $s->fetch();

if (!$row) { echo json_encode(['error'=>'Not found']); exit; }

$files = json_decode($row['project_files'] ?? '[]', true) ?: [];
foreach ($files as $f) {
    if ($f['path'] === $path) {
        echo json_encode(['content' => $f['content'], 'path' => $path]);
        exit;
    }
}
echo json_encode(['error'=>'File not found in project', 'content'=>'']);