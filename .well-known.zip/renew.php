<?php
// renew.php — User renewal page for expired/expiring sites
require_once __DIR__ . '/config/db.php';
$user = requireAuth();

$siteId = intval($_GET['site'] ?? 0);
if (!$siteId) { header('Location: ' . SITE_URL . '/dashboard.php'); exit; }

$db = getDB();
$s  = $db->prepare("SELECT * FROM sites WHERE id=? AND user_id=? LIMIT 1");
$s->execute([$siteId, $user['id']]);
$site = $s->fetch();
if (!$site) { header('Location: ' . SITE_URL . '/dashboard.php'); exit; }

// Load hosting plans
$plans = $db->query("SELECT * FROM hosting_plans WHERE is_active=1 ORDER BY sort_order ASC")->fetchAll();

// Expiry info
$isExpired   = $site['status'] === 'expired';
$expiresAt   = $site['hosting_expires_at'];
$daysLeft    = $expiresAt ? ceil((strtotime($expiresAt) - time()) / 86400) : null;
$baseUrl     = rtrim(SITE_URL, '/');
$siteName    = getSetting('site_name', 'BuildKE');
$siteUrl     = $baseUrl . '/sites/' . $site['slug'] . '/';

// Handle AJAX pay init
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) {
    header('Content-Type: application/json');
    require_once __DIR__ . '/mpesa/stk.php';

    $planId = intval($_POST['plan_id'] ?? 0);
    $phone  = normalizePhone($_POST['phone'] ?? $user['phone']);

    $plan = $db->prepare("SELECT * FROM hosting_plans WHERE id=? AND is_active=1 LIMIT 1");
    $plan->execute([$planId]);
    $plan = $plan->fetch();
    if (!$plan) { echo json_encode(['error'=>'Invalid plan']); exit; }

    $ref  = 'RNW-' . $siteId . '-' . time();
    $desc = 'Hosting renewal — ' . $plan['name'];

    $db->prepare("INSERT INTO payments (user_id, site_id, amount, phone, type, status) VALUES (?,?,?,?,'hosting','pending')")
       ->execute([$user['id'], $siteId, $plan['price'], $phone]);
    $payId = $db->lastInsertId();

    $result = mpesaStkPush($phone, intval($plan['price']), $ref, $desc);
    if ($result['success']) {
        $db->prepare("UPDATE payments SET checkout_request_id=? WHERE id=?")->execute([$result['CheckoutRequestID'], $payId]);
        // Store plan info for callback
        $db->prepare("UPDATE payments SET meta=? WHERE id=?")->execute([json_encode(['plan_id'=>$planId,'days'=>$plan['duration_days'],'renew'=>true]), $payId]);
        echo json_encode(['success'=>true, 'pay_id'=>$payId, 'message'=>$result['message']]);
    } else {
        $db->prepare("UPDATE payments SET status='failed' WHERE id=?")->execute([$payId]);
        echo json_encode(['error'=>$result['message'] ?? 'STK push failed']);
    }
    exit;
}

// Poll renewal payment
if (isset($_GET['poll'])) {
    header('Content-Type: application/json');
    $payId = intval($_GET['pay_id'] ?? 0);
    $p = $db->prepare("SELECT status, mpesa_receipt FROM payments WHERE id=? AND user_id=? LIMIT 1");
    $p->execute([$payId, $user['id']]);
    echo json_encode($p->fetch() ?: ['status'=>'not_found']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Renew Hosting — <?= htmlspecialchars($site['name']) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0a0a12;--bg2:#12121e;--bg3:#1a1a28;--border:rgba(255,255,255,.08);--border2:rgba(255,255,255,.14);--text:#e8e8f0;--text2:rgba(232,232,240,.55);--purple:#7c3aed;--blue:#3b82f6;--green:#10b981;--red:#ef4444;--gold:#f59e0b}
body{min-height:100vh;background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;display:flex;align-items:flex-start;justify-content:center;padding:24px 16px 60px;
  background-image:radial-gradient(ellipse 80% 50% at 50% 0%,rgba(124,58,237,.12) 0%,transparent 65%)}

.wrap{width:100%;max-width:500px}
.back{display:inline-flex;align-items:center;gap:6px;color:var(--text2);text-decoration:none;font-size:13px;font-weight:600;margin-bottom:20px;transition:.15s}
.back:hover{color:var(--text)}

/* Site card */
.site-card{background:var(--bg2);border:1px solid var(--border);border-radius:16px;padding:18px;margin-bottom:20px;display:flex;align-items:center;gap:14px}
.site-ico{width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,var(--purple),var(--blue));display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.site-name{font-size:15px;font-weight:800;color:var(--text)}
.site-url{font-size:11px;color:var(--text2);font-family:monospace;margin-top:3px;word-break:break-all}
.exp-badge{margin-top:5px;display:inline-flex;align-items:center;gap:5px;padding:3px 9px;border-radius:20px;font-size:10.5px;font-weight:700}
.exp-badge.expired{background:rgba(239,68,68,.12);color:var(--red);border:1px solid rgba(239,68,68,.25)}
.exp-badge.expiring{background:rgba(245,158,11,.12);color:var(--gold);border:1px solid rgba(245,158,11,.25)}
.exp-badge.active{background:rgba(16,185,129,.12);color:var(--green);border:1px solid rgba(16,185,129,.25)}

/* Plans grid */
.plans-title{font-size:14px;font-weight:800;margin-bottom:12px;display:flex;align-items:center;gap:7px}
.plans{display:flex;flex-direction:column;gap:10px;margin-bottom:20px}
.plan{background:var(--bg2);border:2px solid var(--border);border-radius:14px;padding:16px 18px;cursor:pointer;transition:all .2s;position:relative}
.plan:hover{border-color:rgba(124,58,237,.4);background:rgba(124,58,237,.05)}
.plan.selected{border-color:var(--purple);background:rgba(124,58,237,.1)}
.plan-badge{position:absolute;top:-10px;right:14px;background:linear-gradient(135deg,var(--purple),var(--blue));color:#fff;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:800}
.plan-top{display:flex;align-items:center;justify-content:space-between}
.plan-name{font-size:14px;font-weight:800;color:var(--text)}
.plan-price{font-size:20px;font-weight:900;color:var(--purple)}
.plan-price span{font-size:12px;font-weight:600;color:var(--text2)}
.plan-desc{font-size:12px;color:var(--text2);margin-top:4px}
.plan-check{width:20px;height:20px;border-radius:50%;border:2px solid var(--border2);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:.2s}
.plan.selected .plan-check{background:var(--purple);border-color:var(--purple);color:#fff}

/* Phone input */
.section-label{font-size:11.5px;font-weight:700;color:var(--text2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:7px}
.phone-input{width:100%;height:48px;background:var(--bg3);border:1.5px solid var(--border2);border-radius:11px;padding:0 14px;color:var(--text);font-size:15px;font-weight:700;outline:none;transition:.2s;margin-bottom:16px;font-family:inherit}
.phone-input:focus{border-color:var(--purple)}
.pay-btn{width:100%;height:52px;border-radius:13px;border:none;cursor:pointer;font-size:15px;font-weight:800;color:#fff;background:linear-gradient(135deg,var(--purple),var(--blue));box-shadow:0 6px 20px rgba(124,58,237,.45);transition:.2s;display:flex;align-items:center;justify-content:center;gap:9px}
.pay-btn:hover{transform:translateY(-2px);box-shadow:0 10px 28px rgba(124,58,237,.6)}
.pay-btn:disabled{opacity:.4;cursor:not-allowed;transform:none;box-shadow:none}

/* Pending state */
.pending{background:var(--bg2);border:1px solid rgba(124,58,237,.25);border-radius:16px;padding:28px 20px;text-align:center;display:none}
.pending-ring{width:56px;height:56px;border-radius:50%;border:3px solid rgba(124,58,237,.2);border-top-color:var(--purple);animation:spin .8s linear infinite;margin:0 auto 16px}
@keyframes spin{to{transform:rotate(360deg)}}

/* Success */
.success{background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.2);border-radius:16px;padding:28px 20px;text-align:center;display:none}
.success-ico{width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#059669,var(--green));display:flex;align-items:center;justify-content:center;font-size:26px;margin:0 auto 14px;box-shadow:0 0 30px rgba(16,185,129,.4);animation:pop .4s cubic-bezier(.34,1.56,.64,1)}
@keyframes pop{from{transform:scale(0)}to{transform:scale(1)}}
</style>
</head>
<body>
<div class="wrap">
    <a href="<?= $baseUrl ?>/dashboard.php" class="back"><i class="fa-solid fa-arrow-left"></i> My Sites</a>

    <!-- Site info -->
    <div class="site-card">
        <div class="site-ico">🌐</div>
        <div style="flex:1;min-width:0">
            <div class="site-name"><?= htmlspecialchars($site['name']) ?></div>
            <div class="site-url"><?= htmlspecialchars($siteUrl) ?></div>
            <?php if ($isExpired): ?>
            <div class="exp-badge expired"><i class="fa-solid fa-circle-xmark"></i> Hosting Expired</div>
            <?php elseif ($daysLeft !== null && $daysLeft <= 3): ?>
            <div class="exp-badge expiring"><i class="fa-solid fa-triangle-exclamation"></i> Expires in <?= $daysLeft ?> day<?= $daysLeft!=1?'s':'' ?></div>
            <?php elseif ($expiresAt): ?>
            <div class="exp-badge active"><i class="fa-solid fa-circle-check"></i> Active until <?= date('M j, Y', strtotime($expiresAt)) ?></div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Main form / pending / success -->
    <div id="formArea">
        <div class="plans-title"><i class="fa-solid fa-calendar-check" style="color:#a78bfa"></i> Choose Renewal Period</div>

        <div class="plans" id="plansContainer">
            <?php foreach ($plans as $i => $plan): ?>
            <div class="plan <?= $i===0?'selected':'' ?>" onclick="selectPlan(this, <?= $plan['id'] ?>)" data-id="<?= $plan['id'] ?>" data-price="<?= $plan['price'] ?>" data-days="<?= $plan['duration_days'] ?>">
                <?php if ($i===2): ?><div class="plan-badge">Popular</div><?php endif; ?>
                <div class="plan-top">
                    <div>
                        <div class="plan-name"><?= htmlspecialchars($plan['name']) ?></div>
                        <div class="plan-desc"><?= htmlspecialchars($plan['description'] ?? '') ?></div>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px">
                        <div class="plan-price">KES <?= number_format($plan['price']) ?><span>/<?= $plan['duration_days'] ?>d</span></div>
                        <div class="plan-check"><i class="fa-solid fa-check" style="font-size:10px"></i></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="section-label">M-Pesa Number</div>
        <input type="tel" class="phone-input" id="payPhone" placeholder="07XX XXX XXX" value="<?= htmlspecialchars($user['phone']) ?>">

        <button class="pay-btn" id="payBtn" onclick="startRenewal()">
            <i class="fa-solid fa-mobile-screen"></i>
            <span id="payBtnTxt">Pay KES <?= number_format($plans[0]['price'] ?? 299) ?> via M-Pesa</span>
        </button>
    </div>

    <!-- Pending -->
    <div class="pending" id="pendingArea">
        <div class="pending-ring"></div>
        <div style="font-size:16px;font-weight:800;margin-bottom:6px">Check Your Phone</div>
        <div style="font-size:13px;color:var(--text2);margin-bottom:14px">Enter your M-Pesa PIN to confirm</div>
        <div style="font-size:22px;font-weight:900;color:var(--purple)" id="pendAmt"></div>
        <div style="font-size:11px;color:var(--text2);margin-top:4px">Do not close this page</div>
        <button onclick="location.reload()" style="margin-top:16px;padding:8px 20px;background:rgba(255,255,255,.07);border:1px solid var(--border2);border-radius:8px;color:var(--text2);cursor:pointer;font-size:12px">Cancel</button>
    </div>

    <!-- Success -->
    <div class="success" id="successArea">
        <div class="success-ico">✅</div>
        <div style="font-size:18px;font-weight:900;margin-bottom:6px;color:#fff">Hosting Renewed!</div>
        <div style="font-size:13px;color:var(--text2);margin-bottom:6px">Your site is back online</div>
        <div style="font-size:11px;color:var(--green);font-weight:700;margin-bottom:20px" id="newExpiry"></div>
        <a id="visitBtn" href="<?= htmlspecialchars($siteUrl) ?>" target="_blank"
           style="display:inline-flex;align-items:center;gap:7px;padding:12px 24px;background:linear-gradient(135deg,#059669,var(--green));color:#fff;border-radius:11px;text-decoration:none;font-size:14px;font-weight:800;margin-bottom:10px">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> Visit Your Site
        </a><br>
        <a href="<?= $baseUrl ?>/dashboard.php" style="font-size:12px;color:var(--text2);text-decoration:none">← Back to Dashboard</a>
    </div>
</div>

<script>
var BASE     = '<?= $baseUrl ?>';
var SITE_ID  = <?= $siteId ?>;
var SEL_PLAN = <?= $plans[0]['id'] ?? 0 ?>;
var SEL_PRICE= <?= $plans[0]['price'] ?? 299 ?>;
var POLL_TMR = null;
var PAY_ID   = null;

function selectPlan(el, id) {
    document.querySelectorAll('.plan').forEach(function(p){ p.classList.remove('selected'); });
    el.classList.add('selected');
    SEL_PLAN  = id;
    SEL_PRICE = parseFloat(el.dataset.price);
    document.getElementById('payBtnTxt').textContent = 'Pay KES ' + SEL_PRICE.toLocaleString() + ' via M-Pesa';
}

function startRenewal() {
    var phone = document.getElementById('payPhone').value.trim();
    if (!phone) { alert('Enter your M-Pesa number'); return; }
    var btn = document.getElementById('payBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Sending STK Push…';

    fetch(location.href, {
        method: 'POST',
        credentials: 'include',
        headers: {'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'},
        body: 'plan_id=' + SEL_PLAN + '&phone=' + encodeURIComponent(phone)
    })
    .then(function(r){ return r.json(); })
    .then(function(d){
        if (d.error) { alert('Error: ' + d.error); btn.disabled=false; btn.innerHTML='<i class="fa-solid fa-mobile-screen"></i> <span id="payBtnTxt">Pay KES '+SEL_PRICE.toLocaleString()+' via M-Pesa</span>'; return; }
        PAY_ID = d.pay_id;
        document.getElementById('formArea').style.display   = 'none';
        document.getElementById('pendingArea').style.display = 'block';
        document.getElementById('pendAmt').textContent = 'KES ' + SEL_PRICE.toLocaleString();
        pollRenewal();
    })
    .catch(function(e){ alert('Connection error. Try again.'); btn.disabled=false; });
}

function pollRenewal() {
    var tries = 0;
    POLL_TMR = setInterval(function(){
        tries++;
        if (tries > 60) { clearInterval(POLL_TMR); return; }
        fetch(location.href + '?poll=1&pay_id=' + PAY_ID, {credentials:'include'})
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (d.status === 'completed') {
                clearInterval(POLL_TMR);
                document.getElementById('pendingArea').style.display = 'none';
                document.getElementById('successArea').style.display = 'block';
                // Refresh expiry display
                fetch(BASE + '/site_html.php?site_id=' + SITE_ID, {credentials:'include'})
                .then(function(r){ return r.json(); }).then(function(d){
                    if (d.expiry) document.getElementById('newExpiry').textContent = 'Active until ' + d.expiry;
                });
            } else if (d.status === 'failed') {
                clearInterval(POLL_TMR);
                document.getElementById('pendingArea').style.display = 'none';
                document.getElementById('formArea').style.display    = 'block';
                alert('Payment failed or cancelled. Please try again.');
                document.getElementById('payBtn').disabled = false;
            }
        }).catch(function(){});
    }, 5000);
}
</script>
</body>
</html>