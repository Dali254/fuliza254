<?php
// mpesa/stk.php — M-Pesa Daraja STK Push with full error logging

require_once __DIR__ . '/../config/db.php';

$STK_LOG = __DIR__ . '/stk_log.txt';

function mpesaToken(): string {
    global $STK_LOG;
    $key    = getSetting('mpesa_consumer_key');
    $secret = getSetting('mpesa_consumer_secret');
    $env    = getSetting('mpesa_env', 'sandbox');

    if (empty($key) || empty($secret)) {
        file_put_contents($STK_LOG, date('[Y-m-d H:i:s]') . " TOKEN ERROR: consumer_key or secret is empty\n", FILE_APPEND);
        return '';
    }

    $url = $env === 'live'
        ? 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
        : 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Basic ' . base64_encode("$key:$secret")],
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $raw     = curl_exec($ch);
    $curlErr = curl_error($ch);
    $httpCode= curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlErr) {
        file_put_contents($STK_LOG, date('[Y-m-d H:i:s]') . " TOKEN cURL ERROR: $curlErr\n", FILE_APPEND);
        return '';
    }

    $res = json_decode($raw, true);
    $token = $res['access_token'] ?? '';

    file_put_contents($STK_LOG,
        date('[Y-m-d H:i:s]') . " TOKEN: http=$httpCode env=$env token=" . ($token ? substr($token,0,10).'...' : 'EMPTY') . " raw=" . substr($raw,0,200) . "\n",
        FILE_APPEND
    );

    return $token;
}

function mpesaStkPush(string $phone, int $amount, string $ref, string $desc): array {
    global $STK_LOG;

    $env       = getSetting('mpesa_env', 'sandbox');
    $shortcode = getSetting('mpesa_shortcode');
    $passkey   = getSetting('mpesa_passkey');
    $siteUrl   = rtrim(getSetting('site_url', SITE_URL), '/');
    $timestamp = date('YmdHis');
    $password  = base64_encode($shortcode . $passkey . $timestamp);
    $token     = mpesaToken();

    if (empty($token)) {
        return ['success'=>false, 'CheckoutRequestID'=>null, 'message'=>'Could not get M-Pesa token. Check consumer key/secret in Admin Settings.'];
    }
    if (empty($shortcode)) {
        return ['success'=>false, 'CheckoutRequestID'=>null, 'message'=>'M-Pesa shortcode not configured. Go to Admin → Settings.'];
    }
    if (empty($passkey)) {
        return ['success'=>false, 'CheckoutRequestID'=>null, 'message'=>'M-Pesa passkey not configured. Go to Admin → Settings.'];
    }

    $url = $env === 'live'
        ? 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest'
        : 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

    $payload = [
        'BusinessShortCode' => $shortcode,
        'Password'          => $password,
        'Timestamp'         => $timestamp,
        'TransactionType'   => 'CustomerPayBillOnline',
        'Amount'            => $amount,
        'PartyA'            => $phone,
        'PartyB'            => $shortcode,
        'PhoneNumber'       => $phone,
        'CallBackURL'       => $siteUrl . '/mpesa/callback.php',
        'AccountReference'  => $ref,
        'TransactionDesc'   => $desc,
    ];

    file_put_contents($STK_LOG,
        date('[Y-m-d H:i:s]') . " STK PUSH: env=$env phone=$phone amount=$amount ref=$ref callback=" . $siteUrl . "/mpesa/callback.php\n",
        FILE_APPEND
    );

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token,
        ],
    ]);

    $raw     = curl_exec($ch);
    $curlErr = curl_error($ch);
    $httpCode= curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlErr) {
        file_put_contents($STK_LOG, date('[Y-m-d H:i:s]') . " STK cURL ERROR: $curlErr\n", FILE_APPEND);
        return ['success'=>false, 'CheckoutRequestID'=>null, 'message'=>'cURL error: ' . $curlErr];
    }

    $res = json_decode($raw, true);

    file_put_contents($STK_LOG,
        date('[Y-m-d H:i:s]') . " STK RESPONSE: http=$httpCode body=" . substr($raw,0,400) . "\n",
        FILE_APPEND
    );

    if (isset($res['CheckoutRequestID'])) {
        return [
            'success'           => true,
            'CheckoutRequestID' => $res['CheckoutRequestID'],
            'message'           => $res['CustomerMessage'] ?? 'STK Push sent',
        ];
    }

    // Extract useful error message from Safaricom response
    $errMsg = $res['errorMessage']
           ?? $res['ResultDesc']
           ?? $res['ResponseDescription']
           ?? ('Failed — HTTP ' . $httpCode);

    return ['success'=>false, 'CheckoutRequestID'=>null, 'message'=>$errMsg];
}