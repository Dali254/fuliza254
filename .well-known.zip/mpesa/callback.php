<?php
// mpesa/callback.php — Fixed: writes HTML file to disk on hosting payment

require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');
echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Accepted']);
if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

$log = __DIR__ . '/callback_log.txt';
file_put_contents($log, date('[Y-m-d H:i:s] ') . $raw . "\n\n", FILE_APPEND);

// Support both STK and flat format
$rc  = $data['Body']['stkCallback']['ResultCode']        ?? $data['ResultCode']        ?? null;
$ref = $data['Body']['stkCallback']['CheckoutRequestID'] ?? $data['CheckoutRequestID'] ?? null;

if (!$ref) { file_put_contents($log, "[SKIP] No ref\n", FILE_APPEND); exit; }

if ($rc != 0) {
    getDB()->prepare("UPDATE payments SET status='failed' WHERE checkout_request_id=? AND status='pending'")
           ->execute([$ref]);
    file_put_contents($log, "[FAILED] code=$rc\n", FILE_APPEND);
    exit;
}

// Extract receipt and amount
$receipt = null; $paid = 0;
foreach ($data['Body']['stkCallback']['CallbackMetadata']['Item'] ?? [] as $item) {
    if ($item['Name'] === 'MpesaReceiptNumber') $receipt = $item['Value'];
    if ($item['Name'] === 'Amount')             $paid    = floatval($item['Value']);
}
// Flat format fallback
if (!$receipt) $receipt = $data['TransactionReceipt'] ?? $data['MpesaReceiptNumber'] ?? null;
if (!$paid)    $paid    = floatval($data['TransactionAmount'] ?? $data['Amount'] ?? 0);

$db  = getDB();
$pay = $db->prepare("SELECT * FROM payments WHERE checkout_request_id=? AND status='pending' LIMIT 1");
$pay->execute([$ref]);
$payment = $pay->fetch();
if (!$payment) {
    file_put_contents($log, "[NOT FOUND] ref=$ref\n", FILE_APPEND);
    exit;
}

$db->beginTransaction();
try {
    // Mark payment complete
    $db->prepare("UPDATE payments SET status='completed', mpesa_receipt=?, amount=? WHERE id=?")
       ->execute([$receipt, $paid ?: $payment['amount'], $payment['id']]);

    if ($payment['site_id']) {
        // Load site
        $s = $db->prepare("SELECT * FROM sites WHERE id=? LIMIT 1");
        $s->execute([$payment['site_id']]);
        $site = $s->fetch();

        if ($site) {
            if ($payment['type'] === 'download') {
                // Just mark paid — user downloads ZIP manually
                $db->prepare("UPDATE sites SET status='paid' WHERE id=?")
                   ->execute([$site['id']]);
                file_put_contents($log, date('[Y-m-d H:i:s]') . " ✅ Download paid site#{$site['id']}\n", FILE_APPEND);
            }

            if ($payment['type'] === 'hosting') {
                // Determine hosting duration from plan (check meta JSON)
                $meta     = json_decode($payment['meta'] ?? '{}', true) ?: [];
                $days     = intval($meta['days'] ?? 30);
                $planId   = intval($meta['plan_id'] ?? 0);

                // If no meta, fall back to cheapest plan duration
                if ($days <= 0) $days = 30;

                // Calculate new expiry — if site already has future expiry, extend from there
                $currentExpiry = $site['hosting_expires_at'];
                if ($currentExpiry && strtotime($currentExpiry) > time()) {
                    // Extend from current expiry
                    $newExpiry = date('Y-m-d H:i:s', strtotime($currentExpiry . ' +' . $days . ' days'));
                } else {
                    // Start fresh from now
                    $newExpiry = date('Y-m-d H:i:s', strtotime('+' . $days . ' days'));
                }

                // Write HTML file to disk
                $siteDir = __DIR__ . '/../sites/' . $site['slug'] . '/';
                if (!is_dir($siteDir)) mkdir($siteDir, 0755, true);
                file_put_contents($siteDir . 'index.html', $site['html_content']);

                // Mark published + set expiry
                $db->prepare("UPDATE sites SET status='published', hosting_expires_at=?, hosting_plan=? WHERE id=?")
                   ->execute([$newExpiry, $planId ?: null, $site['id']]);

                // Log the renewal
                $db->prepare("INSERT INTO hosting_expirations (site_id, action, note) VALUES (?,?,?)")
                   ->execute([$site['id'], 'renewed', "Paid {$payment['amount']} — expires {$newExpiry}"]);

                file_put_contents($log,
                    date('[Y-m-d H:i:s]') . " ✅ Hosting site#{$site['id']} slug={$site['slug']} expires={$newExpiry}\n",
                    FILE_APPEND
                );
            }
        }
    }

    $db->commit();
    file_put_contents($log,
        date('[Y-m-d H:i:s]') . " ✅ Payment #{$payment['id']} complete receipt=$receipt\n",
        FILE_APPEND
    );
} catch (Exception $e) {
    $db->rollBack();
    file_put_contents($log,
        date('[Y-m-d H:i:s]') . " ❌ Error: " . $e->getMessage() . "\n",
        FILE_APPEND
    );
}