<?php
require_once __DIR__ . '/auth_check.php';
$admin     = requireAdmin();
$pageTitle = 'Users';
$db        = getDB();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $userId = intval($_POST['user_id'] ?? 0);

    if ($action === 'toggle_admin' && $userId && $userId !== $admin['id']) {
        $u = $db->prepare("SELECT is_admin FROM users WHERE id=?"); $u->execute([$userId]);
        $row = $u->fetch();
        $db->prepare("UPDATE users SET is_admin=? WHERE id=?")->execute([!$row['is_admin'], $userId]);
    }
    if ($action === 'delete' && $userId && $userId !== $admin['id']) {
        $db->prepare("DELETE FROM payments WHERE user_id=?")->execute([$userId]);
        $db->prepare("DELETE FROM sites WHERE user_id=?")->execute([$userId]);
        $db->prepare("DELETE FROM users WHERE id=?")->execute([$userId]);
    }
    if ($action === 'reset_password' && $userId) {
        $newPass = bin2hex(random_bytes(4)); // 8-char random
        $db->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($newPass, PASSWORD_DEFAULT), $userId]);
        $resetMsg = "Password reset to: <strong>{$newPass}</strong> — share with user";
    }
    if ($action !== 'reset_password') {
        header('Location: ' . SITE_URL . '/admin/users.php'); exit;
    }
}

// Search
$search = trim($_GET['q'] ?? '');
$where  = $search ? "WHERE (name LIKE ? OR email LIKE ? OR phone LIKE ?)" : "";
$params = $search ? ["%$search%", "%$search%", "%$search%"] : [];

$stmt = $db->prepare("SELECT u.*, (SELECT COUNT(*) FROM sites WHERE user_id=u.id) as site_count, (SELECT COALESCE(SUM(amount),0) FROM payments WHERE user_id=u.id AND status='completed') as total_paid FROM users u $where ORDER BY u.created_at DESC");
$stmt->execute($params);
$users = $stmt->fetchAll();

include __DIR__ . '/sidebar.php';
?>

<?php if (!empty($resetMsg)): ?>
<div style="margin-bottom:16px;padding:12px 16px;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.25);border-radius:10px;color:#4ade80;font-size:13px">
    <i class="fa-solid fa-key"></i> <?= $resetMsg ?>
</div>
<?php endif; ?>

<!-- Search + header -->
<div style="display:flex;align-items:center;gap:12px;margin-bottom:18px;flex-wrap:wrap">
    <form method="GET" style="display:flex;gap:8px;flex:1;min-width:200px">
        <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search name, email, phone…" class="form-control" style="flex:1">
        <button type="submit" class="btn primary"><i class="fa-solid fa-search"></i></button>
        <?php if ($search): ?><a href="<?= SITE_URL ?>/admin/users.php" class="btn ghost">Clear</a><?php endif; ?>
    </form>
    <div style="font-size:13px;color:var(--text2)"><?= count($users) ?> users</div>
</div>

<div class="panel">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-users" style="color:#a78bfa;margin-right:7px"></i>All Users</div>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Sites</th><th>Revenue</th><th>Role</th><th>Joined</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if (empty($users)): ?>
        <tr><td colspan="9"><div class="empty"><i class="fa-solid fa-users"></i>No users found</div></td></tr>
        <?php else: ?>
        <?php foreach ($users as $u): ?>
        <tr>
            <td><strong>#<?= $u['id'] ?></strong></td>
            <td><strong><?= htmlspecialchars($u['name']) ?></strong></td>
            <td style="font-size:12px;color:var(--text2)"><?= htmlspecialchars($u['email']) ?></td>
            <td style="font-size:12px"><?= htmlspecialchars($u['phone']) ?></td>
            <td><?= $u['site_count'] ?></td>
            <td style="color:var(--green);font-weight:700">KES <?= number_format($u['total_paid']) ?></td>
            <td>
                <?php if ($u['is_admin']): ?>
                <span class="badge admin"><i class="fa-solid fa-shield-halved"></i> Admin</span>
                <?php else: ?>
                <span style="font-size:12px;color:var(--text3)">User</span>
                <?php endif; ?>
            </td>
            <td style="font-size:12px;color:var(--text2)"><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
            <td>
                <div style="display:flex;gap:5px;flex-wrap:wrap">
                    <?php if ($u['id'] !== $admin['id']): ?>
                    <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="toggle_admin">
                        <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                        <button type="submit" class="btn sm ghost" title="<?= $u['is_admin']?'Remove Admin':'Make Admin' ?>">
                            <i class="fa-solid fa-<?= $u['is_admin']?'user-minus':'user-shield' ?>"></i>
                        </button>
                    </form>
                    <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="reset_password">
                        <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                        <button type="submit" class="btn sm ghost" title="Reset Password" onclick="return confirm('Reset password for <?= htmlspecialchars($u['name']) ?>?')">
                            <i class="fa-solid fa-key"></i>
                        </button>
                    </form>
                    <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                        <button type="submit" class="btn sm danger" title="Delete User" onclick="return confirm('Delete <?= htmlspecialchars($u['name']) ?> permanently? This deletes all their sites and payments too!')">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                    <?php else: ?>
                    <span style="font-size:11px;color:var(--text3);font-weight:700">(You)</span>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

</div></div>
</body></html>