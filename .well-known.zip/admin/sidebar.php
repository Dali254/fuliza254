<?php
// admin/sidebar.php — shared layout for all admin pages
$siteName   = getSetting('site_name', 'BuildKE');
$adminName  = $_SESSION['admin_name'] ?? 'Admin';
$currentPage= basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title><?= $pageTitle ?? 'Admin' ?> — <?= $siteName ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
    --bg:#0a0a12;--bg2:#12121e;--bg3:#1a1a28;--bg4:#20202e;
    --border:rgba(255,255,255,.07);--border2:rgba(255,255,255,.13);
    --text:#e8e8f0;--text2:rgba(232,232,240,.55);--text3:rgba(232,232,240,.32);
    --purple:#7c3aed;--blue:#3b82f6;--green:#10b981;--red:#ef4444;
    --gold:#f59e0b;--pink:#ec4899;
    --sidebar-w:230px;--header-h:56px;
}
html,body{height:100%;background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;overflow:hidden}

/* ── SIDEBAR ── */
.sidebar{
    position:fixed;top:0;left:0;bottom:0;width:var(--sidebar-w);
    background:var(--bg2);border-right:1px solid var(--border);
    display:flex;flex-direction:column;z-index:100;
    overflow-y:auto;
}
.sidebar::-webkit-scrollbar{width:3px}
.sidebar::-webkit-scrollbar-thumb{background:rgba(255,255,255,.08)}

.sb-logo{padding:20px 18px 16px;border-bottom:1px solid var(--border)}
.sb-logo-text{font-size:17px;font-weight:900;background:linear-gradient(135deg,#7c3aed,#3b82f6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.sb-logo-badge{font-size:10px;font-weight:700;color:rgba(167,139,250,.7);letter-spacing:.5px;text-transform:uppercase;margin-top:2px}

.sb-nav{padding:12px 10px;flex:1}
.sb-section{font-size:9.5px;font-weight:800;color:var(--text3);text-transform:uppercase;letter-spacing:1.2px;padding:14px 8px 6px;display:flex;align-items:center;gap:6px}
.sb-section::after{content:'';flex:1;height:1px;background:var(--border)}

.sb-link{
    display:flex;align-items:center;gap:10px;padding:9px 10px;
    border-radius:9px;font-size:13px;font-weight:600;color:var(--text2);
    text-decoration:none;transition:.15s;margin-bottom:2px;cursor:pointer;
    border:none;background:transparent;width:100%;text-align:left;
}
.sb-link:hover{background:rgba(255,255,255,.06);color:var(--text)}
.sb-link.on{background:rgba(124,58,237,.14);color:#a78bfa;font-weight:700}
.sb-link.on .sb-ico{color:#a78bfa}
.sb-ico{width:18px;text-align:center;font-size:13px;color:var(--text3);flex-shrink:0}
.sb-badge{margin-left:auto;padding:2px 7px;background:rgba(124,58,237,.2);color:#a78bfa;border-radius:20px;font-size:10px;font-weight:800}
.sb-badge.red{background:rgba(239,68,68,.2);color:#f87171}
.sb-badge.green{background:rgba(16,185,129,.2);color:#4ade80}

.sb-user{padding:14px 16px;border-top:1px solid var(--border);display:flex;align-items:center;gap:10px}
.sb-avatar{width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,var(--purple),var(--blue));display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;color:#fff;flex-shrink:0}
.sb-user-name{font-size:13px;font-weight:700;color:var(--text)}
.sb-user-role{font-size:10px;color:var(--text3)}
.sb-logout{margin-left:auto;width:28px;height:28px;border-radius:8px;background:rgba(239,68,68,.1);border:none;cursor:pointer;color:#f87171;font-size:13px;display:flex;align-items:center;justify-content:center;transition:.15s;flex-shrink:0;text-decoration:none}
.sb-logout:hover{background:rgba(239,68,68,.2)}

/* ── MAIN AREA ── */
.main{margin-left:var(--sidebar-w);height:100vh;display:flex;flex-direction:column;overflow:hidden}
.topbar{height:var(--header-h);display:flex;align-items:center;padding:0 24px;gap:14px;background:var(--bg2);border-bottom:1px solid var(--border);flex-shrink:0}
.topbar-title{font-size:18px;font-weight:800;color:var(--text)}
.topbar-right{margin-left:auto;display:flex;align-items:center;gap:10px}
.content{flex:1;overflow-y:auto;padding:24px;background:var(--bg)}
.content::-webkit-scrollbar{width:5px}
.content::-webkit-scrollbar-thumb{background:rgba(255,255,255,.08);border-radius:3px}

/* ── CARDS & TABLES ── */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:24px}
.stat-card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:20px;position:relative;overflow:hidden;transition:.2s}
.stat-card:hover{border-color:var(--border2);transform:translateY(-2px)}
.stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px}
.stat-card.purple::before{background:linear-gradient(90deg,var(--purple),var(--blue))}
.stat-card.green::before{background:linear-gradient(90deg,#059669,var(--green))}
.stat-card.gold::before{background:linear-gradient(90deg,#d97706,var(--gold))}
.stat-card.pink::before{background:linear-gradient(90deg,#db2777,var(--pink))}
.stat-card.red::before{background:linear-gradient(90deg,#dc2626,var(--red))}
.stat-ico{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;margin-bottom:12px}
.stat-card.purple .stat-ico{background:rgba(124,58,237,.15);color:#a78bfa}
.stat-card.green .stat-ico{background:rgba(16,185,129,.15);color:var(--green)}
.stat-card.gold .stat-ico{background:rgba(245,158,11,.15);color:var(--gold)}
.stat-card.pink .stat-ico{background:rgba(236,72,153,.15);color:var(--pink)}
.stat-card.red .stat-ico{background:rgba(239,68,68,.15);color:var(--red)}
.stat-label{font-size:11px;font-weight:700;color:var(--text2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px}
.stat-value{font-size:28px;font-weight:900;letter-spacing:-1px}
.stat-sub{font-size:11px;color:var(--text3);margin-top:3px}

.panel{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:20px}
.panel-header{padding:16px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px}
.panel-title{font-size:14px;font-weight:800;color:var(--text);flex:1}
.panel-action{height:32px;padding:0 14px;border-radius:8px;border:1px solid var(--border2);background:transparent;color:var(--text2);font-size:12px;font-weight:700;cursor:pointer;transition:.15s;text-decoration:none;display:flex;align-items:center;gap:5px}
.panel-action:hover{background:rgba(255,255,255,.07);color:var(--text)}
.panel-action.primary{background:linear-gradient(135deg,var(--purple),var(--blue));color:#fff;border:none;box-shadow:0 3px 10px rgba(124,58,237,.3)}

table{width:100%;border-collapse:collapse;min-width:600px}
.table-wrap{overflow-x:auto}
th{padding:12px 16px;font-size:10.5px;font-weight:800;color:var(--text3);text-transform:uppercase;letter-spacing:.6px;text-align:left;border-bottom:1px solid var(--border);background:var(--bg3);white-space:nowrap}
td{padding:13px 16px;font-size:13px;color:var(--text);border-bottom:1px solid var(--border);vertical-align:middle}
tr:last-child td{border-bottom:none}
tbody tr:hover td{background:rgba(255,255,255,.02)}

.badge{display:inline-flex;align-items:center;gap:4px;padding:4px 9px;border-radius:20px;font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.3px;white-space:nowrap}
.badge.completed,.badge.paid,.badge.published,.badge.active{background:rgba(16,185,129,.12);color:var(--green);border:1px solid rgba(16,185,129,.25)}
.badge.pending,.badge.draft{background:rgba(245,158,11,.12);color:var(--gold);border:1px solid rgba(245,158,11,.25)}
.badge.failed,.badge.inactive{background:rgba(239,68,68,.12);color:var(--red);border:1px solid rgba(239,68,68,.25)}
.badge.admin{background:rgba(124,58,237,.12);color:#a78bfa;border:1px solid rgba(124,58,237,.25)}

.btn{height:36px;padding:0 16px;border-radius:8px;border:none;cursor:pointer;font-size:12.5px;font-weight:700;display:inline-flex;align-items:center;gap:6px;transition:.2s;text-decoration:none;white-space:nowrap}
.btn.sm{height:30px;padding:0 12px;font-size:11.5px}
.btn.primary{background:linear-gradient(135deg,var(--purple),var(--blue));color:#fff;box-shadow:0 3px 10px rgba(124,58,237,.3)}
.btn.primary:hover{filter:brightness(1.1);transform:translateY(-1px)}
.btn.success{background:linear-gradient(135deg,#059669,var(--green));color:#fff}
.btn.danger{background:rgba(239,68,68,.12);color:var(--red);border:1px solid rgba(239,68,68,.25)}
.btn.danger:hover{background:var(--red);color:#fff}
.btn.ghost{background:rgba(255,255,255,.06);color:var(--text2);border:1px solid var(--border2)}
.btn.ghost:hover{background:rgba(255,255,255,.1);color:var(--text)}

.form-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-bottom:14px}
.form-group{display:flex;flex-direction:column;gap:5px}
.form-group label{font-size:11px;font-weight:700;color:var(--text2);text-transform:uppercase;letter-spacing:.5px}
.form-control{height:42px;background:var(--bg3);border:1.5px solid var(--border2);border-radius:9px;padding:0 12px;color:var(--text);font-size:13px;outline:none;transition:.2s;font-family:inherit}
.form-control:focus{border-color:var(--purple);background:rgba(124,58,237,.05)}
.form-control::placeholder{color:var(--text3)}
textarea.form-control{height:auto;padding:10px 12px;resize:vertical;min-height:80px}
select.form-control option{background:var(--bg2)}

.empty{text-align:center;padding:48px 20px;color:var(--text3)}
.empty i{font-size:40px;margin-bottom:12px;display:block;opacity:.3}

@media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:none}
    .main{margin-left:0}
}
</style>

<div class="sidebar">
    <div class="sb-logo">
        <div class="sb-logo-text">⚡ <?= $siteName ?></div>
        <div class="sb-logo-badge">Admin Panel</div>
    </div>

    <nav class="sb-nav">
        <div class="sb-section">Main</div>
        <a href="<?= SITE_URL ?>/admin/dashboard.php" class="sb-link <?= $currentPage==='dashboard.php'?'on':'' ?>">
            <i class="fa-solid fa-chart-line sb-ico"></i> Dashboard
        </a>
        <a href="<?= SITE_URL ?>/admin/users.php" class="sb-link <?= $currentPage==='users.php'?'on':'' ?>">
            <i class="fa-solid fa-users sb-ico"></i> Users
        </a>
        <a href="<?= SITE_URL ?>/admin/sites.php" class="sb-link <?= $currentPage==='sites.php'?'on':'' ?>">
            <i class="fa-solid fa-globe sb-ico"></i> Sites
        </a>
        <a href="<?= SITE_URL ?>/admin/payments.php" class="sb-link <?= $currentPage==='payments.php'?'on':'' ?>">
            <i class="fa-solid fa-money-bill-wave sb-ico"></i> Payments
        </a>

        <div class="sb-section">Config</div>
        <a href="<?= SITE_URL ?>/admin/hosting.php" class="sb-link <?= $currentPage==='hosting.php'?'on':'' ?>">
            <i class="fa-solid fa-calendar-check sb-ico"></i> Hosting Plans
        </a>
        <a href="<?= SITE_URL ?>/admin/settings.php" class="sb-link <?= $currentPage==='settings.php'?'on':'' ?>">
            <i class="fa-solid fa-gear sb-ico"></i> Settings
        </a>

        <div class="sb-section">Site</div>
        <a href="<?= SITE_URL ?>" target="_blank" class="sb-link">
            <i class="fa-solid fa-arrow-up-right-from-square sb-ico"></i> View Site
        </a>
        <a href="<?= SITE_URL ?>/admin/logout.php" class="sb-link" style="color:#f87171">
            <i class="fa-solid fa-right-from-bracket sb-ico" style="color:#f87171"></i> Logout
        </a>
    </nav>

    <div class="sb-user">
        <div class="sb-avatar"><?= strtoupper(substr($adminName, 0, 1)) ?></div>
        <div>
            <div class="sb-user-name"><?= htmlspecialchars($adminName) ?></div>
            <div class="sb-user-role">Super Admin</div>
        </div>
    </div>
</div>

<div class="main">
<div class="topbar">
    <div class="topbar-title"><?= $pageTitle ?? 'Dashboard' ?></div>
    <div class="topbar-right">
        <span style="font-size:12px;color:var(--text3)"><?= date('D, M j Y') ?></span>
    </div>
</div>
<div class="content">