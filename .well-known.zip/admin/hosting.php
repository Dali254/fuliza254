<?php
require_once __DIR__ . '/auth_check.php';
$admin     = requireAdmin();
$pageTitle = 'Hosting Plans';
$db        = getDB();
$msg       = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name  = trim($_POST['name'] ?? '');
        $days  = intval($_POST['duration_days'] ?? 30);
        $price = floatval($_POST['price'] ?? 0);
        $desc  = trim($_POST['description'] ?? '');
        $sort  = intval($_POST['sort_order'] ?? 0);
        if ($name && $days > 0 && $price > 0) {
            $db->prepare("INSERT INTO hosting_plans (name, duration_days, price, description, sort_order) VALUES (?,?,?,?,?)")
               ->execute([$name, $days, $price, $desc, $sort]);
            $msg = 'Plan added!';
        }
    }

    if ($action === 'edit') {
        $id    = intval($_POST['id'] ?? 0);
        $name  = trim($_POST['name'] ?? '');
        $days  = intval($_POST['duration_days'] ?? 30);
        $price = floatval($_POST['price'] ?? 0);
        $desc  = trim($_POST['description'] ?? '');
        $sort  = intval($_POST['sort_order'] ?? 0);
        $active= intval($_POST['is_active'] ?? 1);
        if ($id && $name && $days > 0 && $price > 0) {
            $db->prepare("UPDATE hosting_plans SET name=?, duration_days=?, price=?, description=?, sort_order=?, is_active=? WHERE id=?")
               ->execute([$name, $days, $price, $desc, $sort, $active, $id]);
            $msg = 'Plan updated!';
        }
    }

    if ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        if ($id) { $db->prepare("DELETE FROM hosting_plans WHERE id=?")->execute([$id]); $msg = 'Plan deleted.'; }
    }

    if ($action === 'expire_site') {
        $siteId = intval($_POST['site_id'] ?? 0);
        if ($siteId) {
            $s = $db->prepare("SELECT * FROM sites WHERE id=? LIMIT 1"); $s->execute([$siteId]); $site = $s->fetch();
            if ($site) {
                $siteFile = __DIR__ . '/../sites/' . $site['slug'] . '/index.html';
                if (file_exists($siteFile)) {
                    // Write expired page
                    $expiredHtml = '<html><body style="font-family:sans-serif;text-align:center;padding:60px;background:#0a0a12;color:#fff"><h1>⏰ Hosting Expired</h1><p>This site\'s hosting has expired. Please contact the site owner to renew.</p></body></html>';
                    file_put_contents($siteFile, $expiredHtml);
                }
                $db->prepare("UPDATE sites SET status='expired', hosting_expires_at=NOW() WHERE id=?")->execute([$siteId]);
                $db->prepare("INSERT INTO hosting_expirations (site_id, action, note) VALUES (?,?,?)")->execute([$siteId, 'expired', 'Manually expired by admin']);
                $msg = 'Site marked as expired.';
            }
        }
    }

    if ($action === 'extend') {
        $siteId = intval($_POST['site_id'] ?? 0);
        $days   = intval($_POST['days'] ?? 30);
        if ($siteId && $days > 0) {
            $s = $db->prepare("SELECT * FROM sites WHERE id=? LIMIT 1"); $s->execute([$siteId]); $site = $s->fetch();
            if ($site) {
                $base = ($site['hosting_expires_at'] && strtotime($site['hosting_expires_at']) > time()) ? $site['hosting_expires_at'] : date('Y-m-d H:i:s');
                $newExpiry = date('Y-m-d H:i:s', strtotime($base . ' +' . $days . ' days'));

                // Republish if expired
                if ($site['status'] === 'expired' && $site['html_content']) {
                    $dir = __DIR__ . '/../sites/' . $site['slug'] . '/';
                    if (!is_dir($dir)) mkdir($dir, 0755, true);
                    file_put_contents($dir . 'index.html', $site['html_content']);
                    $db->prepare("UPDATE sites SET status='published', hosting_expires_at=? WHERE id=?")->execute([$newExpiry, $siteId]);
                } else {
                    $db->prepare("UPDATE sites SET hosting_expires_at=? WHERE id=?")->execute([$newExpiry, $siteId]);
                }
                $db->prepare("INSERT INTO hosting_expirations (site_id, action, note) VALUES (?,?,?)")->execute([$siteId, 'renewed', "Admin extended +{$days} days → {$newExpiry}"]);
                $msg = "Site extended by {$days} days — expires {$newExpiry}";
            }
        }
    }
}

// Load data
$plans = $db->query("SELECT * FROM hosting_plans ORDER BY sort_order ASC")->fetchAll();
$hostedSites = $db->query("
    SELECT s.*, u.name as user_name, u.email as user_email,
        DATEDIFF(s.hosting_expires_at, NOW()) as days_left
    FROM sites s
    JOIN users u ON s.user_id=u.id
    WHERE s.status IN ('published','expired')
      AND s.hosting_expires_at IS NOT NULL
    ORDER BY s.hosting_expires_at ASC
")->fetchAll();

$stats = [
    'active'  => $db->query("SELECT COUNT(*) FROM sites WHERE status='published' AND hosting_expires_at > NOW()")->fetchColumn(),
    'expired' => $db->query("SELECT COUNT(*) FROM sites WHERE status='expired'")->fetchColumn(),
    'expiring'=> $db->query("SELECT COUNT(*) FROM sites WHERE status='published' AND hosting_expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)")->fetchColumn(),
    'revenue' => $db->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE type='hosting' AND status='completed'")->fetchColumn(),
];

include __DIR__ . '/sidebar.php';
?>

<?php if ($msg): ?>
<div style="margin-bottom:16px;padding:12px 16px;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.25);border-radius:10px;color:#4ade80;font-size:13px;display:flex;align-items:center;gap:8px">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg) ?>
</div>
<?php endif; ?>

<!-- Stats -->
<div class="stats-grid" style="margin-bottom:20px">
    <div class="stat-card green"><div class="stat-ico"><i class="fa-solid fa-circle-check"></i></div><div class="stat-label">Active Hosted</div><div class="stat-value"><?= $stats['active'] ?></div></div>
    <div class="stat-card gold"><div class="stat-ico"><i class="fa-solid fa-triangle-exclamation"></i></div><div class="stat-label">Expiring (7d)</div><div class="stat-value"><?= $stats['expiring'] ?></div></div>
    <div class="stat-card red"><div class="stat-ico"><i class="fa-solid fa-circle-xmark"></i></div><div class="stat-label">Expired</div><div class="stat-value"><?= $stats['expired'] ?></div></div>
    <div class="stat-card purple"><div class="stat-ico"><i class="fa-solid fa-money-bill-wave"></i></div><div class="stat-label">Hosting Revenue</div><div class="stat-value" style="font-size:20px">KES <?= number_format($stats['revenue']) ?></div></div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">

<!-- Plans Manager -->
<div class="panel">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-calendar-check" style="color:#a78bfa;margin-right:7px"></i>Hosting Plans</div>
    </div>
    <div style="padding:16px;display:flex;flex-direction:column;gap:10px">
        <?php foreach ($plans as $p): ?>
        <div style="background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:12px 14px">
            <form method="POST" style="display:flex;flex-direction:column;gap:8px">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <div style="display:grid;grid-template-columns:1fr 80px 100px;gap:8px">
                    <input type="text" name="name" value="<?= htmlspecialchars($p['name']) ?>" class="form-control" style="height:36px" placeholder="Plan name">
                    <input type="number" name="duration_days" value="<?= $p['duration_days'] ?>" class="form-control" style="height:36px" placeholder="Days">
                    <input type="number" name="price" step="0.01" value="<?= $p['price'] ?>" class="form-control" style="height:36px" placeholder="KES">
                </div>
                <div style="display:grid;grid-template-columns:1fr 70px 36px 36px;gap:6px;align-items:center">
                    <input type="text" name="description" value="<?= htmlspecialchars($p['description'] ?? '') ?>" class="form-control" style="height:32px;font-size:11px" placeholder="Description">
                    <select name="is_active" class="form-control" style="height:32px;font-size:11px">
                        <option value="1" <?= $p['is_active']?'selected':'' ?>>Active</option>
                        <option value="0" <?= !$p['is_active']?'selected':'' ?>>Hidden</option>
                    </select>
                    <button type="submit" class="btn sm success" title="Save"><i class="fa-solid fa-save"></i></button>
                    <button type="button" class="btn sm danger" title="Delete" onclick="if(confirm('Delete this plan?')){this.form.querySelector('[name=action]').value='delete';this.form.submit()}"><i class="fa-solid fa-trash"></i></button>
                </div>
            </form>
        </div>
        <?php endforeach; ?>

        <!-- Add new plan -->
        <form method="POST" style="background:rgba(124,58,237,.06);border:1px dashed rgba(124,58,237,.3);border-radius:10px;padding:12px 14px">
            <input type="hidden" name="action" value="add">
            <div style="font-size:11px;font-weight:700;color:var(--text2);margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px">+ Add New Plan</div>
            <div style="display:grid;grid-template-columns:1fr 80px 100px;gap:8px;margin-bottom:8px">
                <input type="text" name="name" class="form-control" style="height:36px" placeholder="e.g. 2 Years" required>
                <input type="number" name="duration_days" class="form-control" style="height:36px" placeholder="Days" required>
                <input type="number" name="price" step="0.01" class="form-control" style="height:36px" placeholder="KES" required>
            </div>
            <div style="display:grid;grid-template-columns:1fr 80px;gap:8px">
                <input type="text" name="description" class="form-control" style="height:32px;font-size:11px" placeholder="e.g. Best value — save 50%">
                <button type="submit" class="btn sm primary"><i class="fa-solid fa-plus"></i> Add</button>
            </div>
        </form>
    </div>
</div>

<!-- Cron info -->
<div class="panel">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-clock" style="color:var(--gold);margin-right:7px"></i>Auto-Expiry Setup</div>
    </div>
    <div style="padding:16px;display:flex;flex-direction:column;gap:14px">
        <div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);border-radius:10px;padding:14px">
            <div style="font-size:12px;font-weight:800;color:var(--gold);margin-bottom:8px"><i class="fa-solid fa-triangle-exclamation"></i> Set Up Cron Job</div>
            <div style="font-size:12px;color:var(--text2);line-height:1.65;margin-bottom:10px">Add this to cPanel → Cron Jobs to auto-expire sites every hour:</div>
            <div style="background:var(--bg3);border-radius:7px;padding:10px;font-family:monospace;font-size:11px;color:#a78bfa;word-break:break-all">0 * * * * php <?= $_SERVER['DOCUMENT_ROOT'] ?>/cron/expire_sites.php</div>
        </div>
        <div style="background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.15);border-radius:10px;padding:14px">
            <div style="font-size:12px;font-weight:800;color:var(--green);margin-bottom:6px"><i class="fa-solid fa-circle-info"></i> How It Works</div>
            <ul style="font-size:12px;color:var(--text2);line-height:1.8;padding-left:14px">
                <li>User pays → site goes live with expiry date</li>
                <li>Cron runs hourly → checks expired sites</li>
                <li>Expired sites show "Hosting Expired" page</li>
                <li>3-day warning before expiry (logged)</li>
                <li>User renews → site comes back instantly</li>
            </ul>
        </div>
    </div>
</div>

</div>

<!-- Hosted Sites Table -->
<div class="panel">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-globe" style="color:#60a5fa;margin-right:7px"></i>All Hosted Sites</div>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>Site</th><th>Owner</th><th>Status</th><th>Expires</th><th>Days Left</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if (empty($hostedSites)): ?>
        <tr><td colspan="7"><div class="empty"><i class="fa-solid fa-globe"></i>No hosted sites yet</div></td></tr>
        <?php else: ?>
        <?php foreach ($hostedSites as $s):
            $dl = intval($s['days_left']);
            $statusColor = $s['status']==='expired' ? 'failed' : ($dl <= 3 ? 'pending' : 'completed');
        ?>
        <tr>
            <td><strong>#<?= $s['id'] ?></strong></td>
            <td>
                <strong><?= htmlspecialchars($s['name']) ?></strong><br>
                <span style="font-size:11px;font-family:monospace;color:var(--text3)"><?= htmlspecialchars($s['slug']) ?></span>
            </td>
            <td style="font-size:12px;color:var(--text2)"><?= htmlspecialchars($s['user_name']) ?></td>
            <td><span class="badge <?= $statusColor ?>"><?= $s['status'] ?></span></td>
            <td style="font-size:12px;white-space:nowrap"><?= $s['hosting_expires_at'] ? date('M j, Y', strtotime($s['hosting_expires_at'])) : '—' ?></td>
            <td style="font-weight:700;color:<?= $dl <= 0 ? 'var(--red)' : ($dl <= 7 ? 'var(--gold)' : 'var(--green)') ?>">
                <?= $dl <= 0 ? 'Expired' : $dl . 'd' ?>
            </td>
            <td>
                <div style="display:flex;gap:5px;align-items:center;flex-wrap:wrap">
                    <!-- Quick extend -->
                    <form method="POST" style="display:inline-flex;gap:4px;align-items:center">
                        <input type="hidden" name="action" value="extend">
                        <input type="hidden" name="site_id" value="<?= $s['id'] ?>">
                        <select name="days" class="form-control" style="height:28px;font-size:11px;width:80px">
                            <option value="30">+30 days</option>
                            <option value="90">+90 days</option>
                            <option value="180">+180 days</option>
                            <option value="365">+1 year</option>
                        </select>
                        <button type="submit" class="btn sm success" title="Extend hosting">Go</button>
                    </form>
                    <!-- Expire now -->
                    <?php if ($s['status'] === 'published'): ?>
                    <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="expire_site">
                        <input type="hidden" name="site_id" value="<?= $s['id'] ?>">
                        <button type="submit" class="btn sm danger" onclick="return confirm('Force expire this site now?')">
                            <i class="fa-solid fa-ban"></i>
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

</div></div>
</body></html>