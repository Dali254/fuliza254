<?php
require_once __DIR__ . '/auth_check.php';
$admin    = requireAdmin();
$pageTitle = 'Dashboard';
$db       = getDB();

// Stats
$totalUsers    = $db->query("SELECT COUNT(*) FROM users WHERE is_admin=0")->fetchColumn();
$totalSites    = $db->query("SELECT COUNT(*) FROM sites")->fetchColumn();
$totalRevenue  = $db->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='completed'")->fetchColumn();
$totalPayments = $db->query("SELECT COUNT(*) FROM payments WHERE status='completed'")->fetchColumn();
$pendingPay    = $db->query("SELECT COUNT(*) FROM payments WHERE status='pending'")->fetchColumn();
$todayRevenue  = $db->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='completed' AND DATE(created_at)=CURDATE()")->fetchColumn();
$todayUsers    = $db->query("SELECT COUNT(*) FROM users WHERE DATE(created_at)=CURDATE() AND is_admin=0")->fetchColumn();
$paidSites     = $db->query("SELECT COUNT(*) FROM sites WHERE status='paid' OR status='published'")->fetchColumn();

// Recent payments
$recentPayments = $db->query("
    SELECT p.*, u.name as user_name, u.email, s.name as site_name
    FROM payments p
    JOIN users u ON p.user_id=u.id
    LEFT JOIN sites s ON p.site_id=s.id
    ORDER BY p.created_at DESC LIMIT 8
")->fetchAll();

// Recent users
$recentUsers = $db->query("
    SELECT * FROM users WHERE is_admin=0 ORDER BY created_at DESC LIMIT 6
")->fetchAll();

include __DIR__ . '/sidebar.php';
?>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card purple">
        <div class="stat-ico"><i class="fa-solid fa-users"></i></div>
        <div class="stat-label">Total Users</div>
        <div class="stat-value"><?= number_format($totalUsers) ?></div>
        <div class="stat-sub">+<?= $todayUsers ?> today</div>
    </div>
    <div class="stat-card green">
        <div class="stat-ico"><i class="fa-solid fa-money-bill-wave"></i></div>
        <div class="stat-label">Total Revenue</div>
        <div class="stat-value">KES <?= number_format($totalRevenue) ?></div>
        <div class="stat-sub">KES <?= number_format($todayRevenue) ?> today</div>
    </div>
    <div class="stat-card gold">
        <div class="stat-ico"><i class="fa-solid fa-globe"></i></div>
        <div class="stat-label">Total Sites</div>
        <div class="stat-value"><?= number_format($totalSites) ?></div>
        <div class="stat-sub"><?= $paidSites ?> paid</div>
    </div>
    <div class="stat-card pink">
        <div class="stat-ico"><i class="fa-solid fa-receipt"></i></div>
        <div class="stat-label">Payments</div>
        <div class="stat-value"><?= number_format($totalPayments) ?></div>
        <div class="stat-sub"><?= $pendingPay ?> pending</div>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

<!-- Recent Payments -->
<div class="panel" style="grid-column:1/-1">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-money-bill-wave" style="color:var(--green);margin-right:7px"></i>Recent Payments</div>
        <a href="<?= SITE_URL ?>/admin/payments.php" class="panel-action">View All</a>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>User</th><th>Site</th><th>Amount</th><th>Type</th><th>Receipt</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
        <?php if (empty($recentPayments)): ?>
        <tr><td colspan="8"><div class="empty"><i class="fa-solid fa-receipt"></i>No payments yet</div></td></tr>
        <?php else: ?>
        <?php foreach ($recentPayments as $p): ?>
        <tr>
            <td><strong>#<?= $p['id'] ?></strong></td>
            <td><?= htmlspecialchars($p['user_name']) ?></td>
            <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($p['site_name'] ?? '—') ?></td>
            <td><strong>KES <?= number_format($p['amount']) ?></strong></td>
            <td><?= ucfirst($p['type']) ?></td>
            <td style="font-family:monospace;font-size:11px"><?= $p['mpesa_receipt'] ?: '—' ?></td>
            <td><span class="badge <?= $p['status'] ?>"><?= $p['status'] ?></span></td>
            <td style="color:var(--text2);font-size:12px"><?= date('M j, H:i', strtotime($p['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- Recent Users -->
<div class="panel">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-users" style="color:#a78bfa;margin-right:7px"></i>Recent Users</div>
        <a href="<?= SITE_URL ?>/admin/users.php" class="panel-action">View All</a>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Joined</th></tr></thead>
        <tbody>
        <?php if (empty($recentUsers)): ?>
        <tr><td colspan="4"><div class="empty"><i class="fa-solid fa-users"></i>No users yet</div></td></tr>
        <?php else: ?>
        <?php foreach ($recentUsers as $u): ?>
        <tr>
            <td>#<?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['name']) ?></td>
            <td style="font-size:12px;color:var(--text2)"><?= htmlspecialchars($u['email']) ?></td>
            <td style="font-size:12px;color:var(--text2)"><?= date('M j', strtotime($u['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- Quick Actions -->
<div class="panel">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-bolt-lightning" style="color:var(--gold);margin-right:7px"></i>Quick Actions</div>
    </div>
    <div style="padding:16px;display:flex;flex-direction:column;gap:10px">
        <a href="<?= SITE_URL ?>/admin/settings.php" class="btn primary" style="justify-content:flex-start">
            <i class="fa-solid fa-gear"></i> Manage Settings
        </a>
        <a href="<?= SITE_URL ?>/admin/users.php" class="btn ghost" style="justify-content:flex-start">
            <i class="fa-solid fa-users"></i> Manage Users
        </a>
        <a href="<?= SITE_URL ?>/admin/sites.php" class="btn ghost" style="justify-content:flex-start">
            <i class="fa-solid fa-globe"></i> Manage Sites
        </a>
        <a href="<?= SITE_URL ?>/admin/payments.php" class="btn ghost" style="justify-content:flex-start">
            <i class="fa-solid fa-money-bill-wave"></i> View Payments
        </a>
        <a href="<?= SITE_URL ?>" target="_blank" class="btn ghost" style="justify-content:flex-start">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> Visit Live Site
        </a>
    </div>
</div>

</div>

</div></div>
</body></html>