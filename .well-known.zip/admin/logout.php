<?php
if (session_status() === PHP_SESSION_NONE) session_start();
session_destroy();
require_once __DIR__ . '/../config/db.php';
header('Location: ' . SITE_URL . '/admin/login.php');
exit;