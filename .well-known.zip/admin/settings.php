<?php
require_once __DIR__ . '/auth_check.php';
$admin     = requireAdmin();
$pageTitle = 'Settings';
$db        = getDB();
$saved     = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = [
        'site_name','site_url','anthropic_api_key',
        'mpesa_consumer_key','mpesa_consumer_secret',
        'mpesa_shortcode','mpesa_passkey','mpesa_env',
        'download_price','hosting_price','currency',
    ];
    foreach ($fields as $f) {
        $val = trim($_POST[$f] ?? '');
        $db->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?")
           ->execute([$f, $val, $val]);
    }
    $saved = true;
}

// Load all settings
$rows = $db->query("SELECT `key`, `value` FROM settings")->fetchAll();
$cfg  = [];
foreach ($rows as $r) $cfg[$r['key']] = $r['value'];

function sv($cfg, $key, $default='') {
    return htmlspecialchars($cfg[$key] ?? $default);
}

include __DIR__ . '/sidebar.php';
?>

<?php if ($saved): ?>
<div style="margin-bottom:18px;padding:12px 16px;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.25);border-radius:10px;color:#4ade80;font-size:13px;display:flex;align-items:center;gap:8px">
    <i class="fa-solid fa-circle-check"></i> Settings saved successfully!
</div>
<?php endif; ?>

<form method="POST">

<!-- General -->
<div class="panel" style="margin-bottom:18px">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-sliders" style="color:#a78bfa;margin-right:7px"></i>General Settings</div>
    </div>
    <div style="padding:20px">
        <div class="form-row">
            <div class="form-group">
                <label>Site Name</label>
                <input type="text" name="site_name" class="form-control" value="<?= sv($cfg,'site_name','BuildKE') ?>">
            </div>
            <div class="form-group">
                <label>Site URL (no trailing slash)</label>
                <input type="text" name="site_url" class="form-control" value="<?= sv($cfg,'site_url') ?>" placeholder="https://yourdomain.co.ke">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Download Price (KES)</label>
                <input type="number" name="download_price" class="form-control" value="<?= sv($cfg,'download_price','499') ?>">
            </div>
            <div class="form-group">
                <label>Hosting Price (KES/month)</label>
                <input type="number" name="hosting_price" class="form-control" value="<?= sv($cfg,'hosting_price','299') ?>">
            </div>
            <div class="form-group">
                <label>Currency</label>
                <input type="text" name="currency" class="form-control" value="<?= sv($cfg,'currency','KES') ?>">
            </div>
        </div>
    </div>
</div>

<!-- Claude AI -->
<div class="panel" style="margin-bottom:18px">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-robot" style="color:#60a5fa;margin-right:7px"></i>Claude AI (Anthropic)</div>
    </div>
    <div style="padding:20px">
        <div class="form-group">
            <label>Anthropic API Key</label>
            <input type="text" name="anthropic_api_key" class="form-control" value="<?= sv($cfg,'anthropic_api_key') ?>" placeholder="sk-ant-api03-...">
            <div style="font-size:11px;color:var(--text3);margin-top:4px">Get your key at console.anthropic.com — used for AI website generation</div>
        </div>
    </div>
</div>

<!-- M-Pesa -->
<div class="panel" style="margin-bottom:18px">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-mobile-screen" style="color:var(--green);margin-right:7px"></i>M-Pesa Daraja Settings</div>
    </div>
    <div style="padding:20px">
        <div style="padding:10px 14px;background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.2);border-radius:9px;font-size:12px;color:rgba(147,197,253,.8);margin-bottom:18px;display:flex;align-items:flex-start;gap:8px">
            <i class="fa-solid fa-circle-info" style="color:#60a5fa;margin-top:1px"></i>
            Get credentials at <a href="https://developer.safaricom.co.ke" target="_blank" style="color:#60a5fa">developer.safaricom.co.ke</a> → Create App → M-Pesa Express
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Consumer Key</label>
                <input type="text" name="mpesa_consumer_key" class="form-control" value="<?= sv($cfg,'mpesa_consumer_key') ?>">
            </div>
            <div class="form-group">
                <label>Consumer Secret</label>
                <input type="text" name="mpesa_consumer_secret" class="form-control" value="<?= sv($cfg,'mpesa_consumer_secret') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Shortcode (Paybill/Till)</label>
                <input type="text" name="mpesa_shortcode" class="form-control" value="<?= sv($cfg,'mpesa_shortcode') ?>" placeholder="174379">
            </div>
            <div class="form-group">
                <label>Passkey (Lipa Na M-Pesa)</label>
                <input type="text" name="mpesa_passkey" class="form-control" value="<?= sv($cfg,'mpesa_passkey') ?>">
            </div>
            <div class="form-group">
                <label>Environment</label>
                <select name="mpesa_env" class="form-control">
                    <option value="sandbox" <?= ($cfg['mpesa_env']??'sandbox')==='sandbox'?'selected':'' ?>>Sandbox (Testing)</option>
                    <option value="live" <?= ($cfg['mpesa_env']??'')==='live'?'selected':'' ?>>Live (Production)</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>Callback URL (add this in Safaricom portal)</label>
            <input type="text" class="form-control" value="<?= sv($cfg,'site_url') ?>/mpesa/callback.php" readonly style="opacity:.6;cursor:copy" onclick="this.select()">
        </div>
    </div>
</div>

<button type="submit" class="btn primary" style="height:46px;padding:0 32px;font-size:14px">
    <i class="fa-solid fa-floppy-disk"></i> Save All Settings
</button>

</form>

</div></div>
</body></html>