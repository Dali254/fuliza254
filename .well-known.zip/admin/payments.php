<?php
require_once __DIR__ . '/auth_check.php';
$admin     = requireAdmin();
$pageTitle = 'Payments';
$db        = getDB();

// Handle manual mark complete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payId  = intval($_POST['pay_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($action === 'complete' && $payId) {
        $db->prepare("UPDATE payments SET status='completed' WHERE id=?")->execute([$payId]);
        // Also mark site paid
        $p = $db->prepare("SELECT site_id FROM payments WHERE id=? LIMIT 1"); $p->execute([$payId]);
        $row = $p->fetch();
        if ($row && $row['site_id']) {
            $db->prepare("UPDATE sites SET status='paid' WHERE id=?")->execute([$row['site_id']]);
        }
    }
    if ($action === 'delete' && $payId) {
        $db->prepare("DELETE FROM payments WHERE id=?")->execute([$payId]);
    }
    header('Location: ' . SITE_URL . '/admin/payments.php'); exit;
}

$status = $_GET['status'] ?? '';
$where  = $status ? "WHERE p.status=?" : "";
$params = $status ? [$status] : [];

$stmt = $db->prepare("
    SELECT p.*, u.name as user_name, u.email, u.phone as user_phone, s.name as site_name
    FROM payments p
    JOIN users u ON p.user_id=u.id
    LEFT JOIN sites s ON p.site_id=s.id
    $where
    ORDER BY p.created_at DESC
    LIMIT 200
");
$stmt->execute($params);
$payments = $stmt->fetchAll();

$totals = $db->query("
    SELECT
        COALESCE(SUM(CASE WHEN status='completed' THEN amount ELSE 0 END),0) as revenue,
        COUNT(CASE WHEN status='completed' THEN 1 END) as completed,
        COUNT(CASE WHEN status='pending' THEN 1 END) as pending,
        COUNT(CASE WHEN status='failed' THEN 1 END) as failed
    FROM payments
")->fetch();

include __DIR__ . '/sidebar.php';
?>

<!-- Revenue stats -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
    <div class="stat-card green">
        <div class="stat-ico"><i class="fa-solid fa-circle-check"></i></div>
        <div class="stat-label">Total Revenue</div>
        <div class="stat-value" style="font-size:22px">KES <?= number_format($totals['revenue']) ?></div>
    </div>
    <div class="stat-card purple">
        <div class="stat-ico"><i class="fa-solid fa-receipt"></i></div>
        <div class="stat-label">Completed</div>
        <div class="stat-value"><?= $totals['completed'] ?></div>
    </div>
    <div class="stat-card gold">
        <div class="stat-ico"><i class="fa-solid fa-clock"></i></div>
        <div class="stat-label">Pending</div>
        <div class="stat-value"><?= $totals['pending'] ?></div>
    </div>
    <div class="stat-card red">
        <div class="stat-ico"><i class="fa-solid fa-circle-xmark"></i></div>
        <div class="stat-label">Failed</div>
        <div class="stat-value"><?= $totals['failed'] ?></div>
    </div>
</div>

<!-- Filter -->
<div style="display:flex;gap:8px;margin-bottom:16px">
    <a href="<?= SITE_URL ?>/admin/payments.php" class="btn <?= !$status?'primary':'ghost' ?>">All</a>
    <a href="?status=completed" class="btn <?= $status==='completed'?'success':'ghost' ?>">Completed</a>
    <a href="?status=pending" class="btn <?= $status==='pending'?'primary':'ghost' ?>">Pending</a>
    <a href="?status=failed" class="btn <?= $status==='failed'?'danger':'ghost' ?>">Failed</a>
</div>

<div class="panel">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-money-bill-wave" style="color:var(--green);margin-right:7px"></i>Payment Records</div>
        <span style="font-size:12px;color:var(--text2)"><?= count($payments) ?> records</span>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>User</th><th>Phone</th><th>Site</th><th>Amount</th><th>Type</th><th>M-Pesa Receipt</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if (empty($payments)): ?>
        <tr><td colspan="10"><div class="empty"><i class="fa-solid fa-receipt"></i>No payments found</div></td></tr>
        <?php else: ?>
        <?php foreach ($payments as $p): ?>
        <tr>
            <td><strong>#<?= $p['id'] ?></strong></td>
            <td><?= htmlspecialchars($p['user_name']) ?></td>
            <td style="font-size:12px;color:var(--text2)"><?= htmlspecialchars($p['phone']) ?></td>
            <td style="font-size:12px;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($p['site_name'] ?? '—') ?></td>
            <td><strong style="color:var(--green)">KES <?= number_format($p['amount']) ?></strong></td>
            <td style="text-transform:capitalize"><?= $p['type'] ?></td>
            <td style="font-family:monospace;font-size:11px;color:var(--text2)"><?= $p['mpesa_receipt'] ?: '<span style="color:var(--text3)">—</span>' ?></td>
            <td><span class="badge <?= $p['status'] ?>"><?= $p['status'] ?></span></td>
            <td style="font-size:12px;color:var(--text2);white-space:nowrap"><?= date('M j, H:i', strtotime($p['created_at'])) ?></td>
            <td>
                <div style="display:flex;gap:5px">
                <?php if ($p['status'] === 'pending'): ?>
                <form method="POST" style="display:inline">
                    <input type="hidden" name="action" value="complete">
                    <input type="hidden" name="pay_id" value="<?= $p['id'] ?>">
                    <button class="btn sm success" onclick="return confirm('Mark this payment as completed manually?')">
                        <i class="fa-solid fa-check"></i> Complete
                    </button>
                </form>
                <?php endif; ?>
                <form method="POST" style="display:inline">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="pay_id" value="<?= $p['id'] ?>">
                    <button class="btn sm danger" onclick="return confirm('Delete this payment record?')">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

</div></div>
</body></html>