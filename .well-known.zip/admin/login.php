<?php
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Already logged in as admin
if (!empty($_SESSION['admin_id'])) {
    header('Location: ' . SITE_URL . '/admin/dashboard.php'); exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';

    if (!$email || !$pass) {
        $error = 'Please enter email and password.';
    } else {
        $s = getDB()->prepare("SELECT * FROM users WHERE email=? AND is_admin=1 LIMIT 1");
        $s->execute([$email]);
        $admin = $s->fetch();

        if ($admin && password_verify($pass, $admin['password'])) {
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            $_SESSION['admin_email']= $admin['email'];
            header('Location: ' . SITE_URL . '/admin/dashboard.php');
            exit;
        } else {
            $error = 'Invalid email or password, or you are not an admin.';
        }
    }
}

$siteName = getSetting('site_name', 'BuildKE');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Admin Login — <?= $siteName ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0a0a12;--bg2:#12121e;--bg3:#1a1a28;--border:rgba(255,255,255,.09);--border2:rgba(255,255,255,.15);--text:#e8e8f0;--text2:rgba(232,232,240,.55);--purple:#7c3aed;--blue:#3b82f6;--red:#ef4444}
body{min-height:100vh;background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;display:flex;align-items:center;justify-content:center;padding:20px;
background-image:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(124,58,237,.15) 0%,transparent 65%)}

.card{width:100%;max-width:400px;background:var(--bg2);border:1px solid var(--border);border-radius:20px;padding:40px 32px;box-shadow:0 40px 80px rgba(0,0,0,.5);position:relative;overflow:hidden}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--purple),var(--blue))}

.logo{text-align:center;margin-bottom:8px}
.logo-icon{font-size:36px;display:block;margin-bottom:8px}
.logo-text{font-size:22px;font-weight:900;background:linear-gradient(135deg,#7c3aed,#3b82f6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.logo-sub{font-size:13px;color:var(--text2);text-align:center;margin-bottom:30px}
.badge{display:inline-flex;align-items:center;gap:5px;padding:4px 12px;background:rgba(124,58,237,.12);border:1px solid rgba(124,58,237,.3);border-radius:20px;font-size:11px;font-weight:700;color:#a78bfa;margin-bottom:24px}

.form-group{margin-bottom:16px}
label{display:block;font-size:11.5px;font-weight:700;color:var(--text2);margin-bottom:6px;text-transform:uppercase;letter-spacing:.5px}
.input-wrap{position:relative}
.input-ico{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--text2);font-size:14px;pointer-events:none}
input{width:100%;height:48px;background:var(--bg3);border:1.5px solid var(--border2);border-radius:11px;padding:0 14px 0 40px;color:var(--text);font-size:14px;outline:none;transition:.2s;font-family:inherit}
input:focus{border-color:var(--purple);background:rgba(124,58,237,.06);box-shadow:0 0 0 3px rgba(124,58,237,.12)}
input::placeholder{color:rgba(232,232,240,.25)}

.btn{width:100%;height:48px;border-radius:11px;border:none;cursor:pointer;font-size:15px;font-weight:800;color:#fff;background:linear-gradient(135deg,var(--purple),var(--blue));box-shadow:0 6px 20px rgba(124,58,237,.45);transition:.2s;display:flex;align-items:center;justify-content:center;gap:8px;margin-top:4px}
.btn:hover{transform:translateY(-2px);box-shadow:0 10px 28px rgba(124,58,237,.6)}
.btn:active{transform:translateY(0)}

.alert{padding:11px 14px;border-radius:10px;font-size:13px;margin-bottom:18px;display:flex;align-items:center;gap:8px}
.alert.error{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#fca5a5}

.back{text-align:center;margin-top:20px;font-size:12px;color:var(--text2)}
.back a{color:#a78bfa;text-decoration:none;font-weight:600}
.back a:hover{color:#c4b5fd}
</style>
</head>
<body>
<div class="card">
    <div class="logo">
        <span class="logo-icon">⚡</span>
        <div class="logo-text"><?= $siteName ?> Admin</div>
    </div>
    <div style="text-align:center">
        <div class="badge"><i class="fa-solid fa-shield-halved"></i> Restricted Access</div>
    </div>
    <div class="logo-sub">Sign in with your admin credentials</div>

    <?php if ($error): ?>
    <div class="alert error"><i class="fa-solid fa-circle-exclamation"></i><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
        <div class="form-group">
            <label>Email Address</label>
            <div class="input-wrap">
                <i class="fa-solid fa-envelope input-ico"></i>
                <input type="email" name="email" placeholder="admin@example.com" required autofocus value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
        </div>
        <div class="form-group">
            <label>Password</label>
            <div class="input-wrap">
                <i class="fa-solid fa-lock input-ico"></i>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>
        </div>
        <button type="submit" class="btn">
            <i class="fa-solid fa-right-to-bracket"></i> Sign In to Admin
        </button>
    </form>

    <div class="back"><a href="<?= SITE_URL ?>">← Back to site</a></div>
</div>
</body>
</html>