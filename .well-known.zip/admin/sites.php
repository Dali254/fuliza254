<?php
require_once __DIR__ . '/auth_check.php';
$admin     = requireAdmin();
$pageTitle = 'Sites';
$db        = getDB();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $siteId = intval($_POST['site_id'] ?? 0);
    if ($action === 'delete' && $siteId) {
        $db->prepare("DELETE FROM payments WHERE site_id=?")->execute([$siteId]);
        $db->prepare("DELETE FROM chat_history WHERE site_id=?")->execute([$siteId]);
        $db->prepare("DELETE FROM sites WHERE id=?")->execute([$siteId]);
    }
    if ($action === 'mark_paid' && $siteId) {
        $db->prepare("UPDATE sites SET status='paid' WHERE id=?")->execute([$siteId]);
    }
    if ($action === 'publish' && $siteId) {
        // Save HTML to file for hosting
        $site = $db->prepare("SELECT * FROM sites WHERE id=? LIMIT 1");
        $site->execute([$siteId]);
        $site = $site->fetch();
        if ($site) {
            $dir = __DIR__ . '/../sites/' . $site['slug'] . '/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            file_put_contents($dir . 'index.html', $site['html_content']);
            $db->prepare("UPDATE sites SET status='published' WHERE id=?")->execute([$siteId]);
        }
    }
    header('Location: ' . SITE_URL . '/admin/sites.php'); exit;
}

$search = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';

$where = "WHERE 1=1";
$params = [];
if ($search) { $where .= " AND (s.name LIKE ? OR s.slug LIKE ? OR u.name LIKE ?)"; $params = array_merge($params,["%$search%","%$search%","%$search%"]); }
if ($status) { $where .= " AND s.status=?"; $params[] = $status; }

$stmt = $db->prepare("
    SELECT s.*, u.name as user_name, u.email as user_email
    FROM sites s
    JOIN users u ON s.user_id=u.id
    $where
    ORDER BY s.created_at DESC
");
$stmt->execute($params);
$sites = $stmt->fetchAll();

include __DIR__ . '/sidebar.php';
?>

<div style="display:flex;align-items:center;gap:10px;margin-bottom:18px;flex-wrap:wrap">
    <form method="GET" style="display:flex;gap:8px;flex:1;min-width:200px">
        <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search site name, owner…" class="form-control" style="flex:1">
        <select name="status" class="form-control" style="width:140px">
            <option value="">All Status</option>
            <option value="draft" <?= $status==='draft'?'selected':'' ?>>Draft</option>
            <option value="paid" <?= $status==='paid'?'selected':'' ?>>Paid</option>
            <option value="published" <?= $status==='published'?'selected':'' ?>>Published</option>
        </select>
        <button type="submit" class="btn primary"><i class="fa-solid fa-search"></i></button>
        <?php if ($search||$status): ?><a href="<?= SITE_URL ?>/admin/sites.php" class="btn ghost">Clear</a><?php endif; ?>
    </form>
    <div style="font-size:13px;color:var(--text2)"><?= count($sites) ?> sites</div>
</div>

<div class="panel">
    <div class="panel-header">
        <div class="panel-title"><i class="fa-solid fa-globe" style="color:#60a5fa;margin-right:7px"></i>All Sites</div>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>Site Name</th><th>Owner</th><th>Slug/URL</th><th>Status</th><th>Downloads</th><th>Created</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if (empty($sites)): ?>
        <tr><td colspan="8"><div class="empty"><i class="fa-solid fa-globe"></i>No sites found</div></td></tr>
        <?php else: ?>
        <?php foreach ($sites as $s): ?>
        <tr>
            <td><strong>#<?= $s['id'] ?></strong></td>
            <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><strong><?= htmlspecialchars($s['name']) ?></strong></td>
            <td style="font-size:12px;color:var(--text2)"><?= htmlspecialchars($s['user_name']) ?></td>
            <td style="font-size:11px;font-family:monospace;color:var(--text2)"><?= htmlspecialchars($s['slug']) ?></td>
            <td><span class="badge <?= $s['status'] ?>"><?= $s['status'] ?></span></td>
            <td><?= $s['downloads'] ?></td>
            <td style="font-size:12px;color:var(--text2)"><?= date('M j, Y', strtotime($s['created_at'])) ?></td>
            <td>
                <div style="display:flex;gap:5px;flex-wrap:wrap">
                    <a href="<?= SITE_URL ?>/builder.php?site=<?= $s['id'] ?>" target="_blank" class="btn sm ghost" title="Edit in Builder">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </a>
                    <?php if ($s['status'] === 'draft'): ?>
                    <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="mark_paid">
                        <input type="hidden" name="site_id" value="<?= $s['id'] ?>">
                        <button class="btn sm success" title="Mark as Paid"><i class="fa-solid fa-check"></i> Paid</button>
                    </form>
                    <?php endif; ?>
                    <?php if ($s['status'] === 'paid'): ?>
                    <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="publish">
                        <input type="hidden" name="site_id" value="<?= $s['id'] ?>">
                        <button class="btn sm primary" title="Publish site"><i class="fa-solid fa-globe"></i> Publish</button>
                    </form>
                    <?php endif; ?>
                    <?php if ($s['status'] === 'published'): ?>
                    <a href="<?= SITE_URL ?>/sites/<?= $s['slug'] ?>/" target="_blank" class="btn sm ghost">
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                    </a>
                    <?php endif; ?>
                    <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="site_id" value="<?= $s['id'] ?>">
                        <button class="btn sm danger" onclick="return confirm('Delete this site permanently?')"><i class="fa-solid fa-trash"></i></button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>

</div></div>
</body></html>