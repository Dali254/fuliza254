<?php
// admin/auth_check.php — include at top of every admin page
require_once __DIR__ . '/../config/db.php';

if (session_status() === PHP_SESSION_NONE) session_start();

function requireAdmin(): array {
    if (empty($_SESSION['admin_id'])) {
        header('Location: ' . SITE_URL . '/admin/login.php');
        exit;
    }
    $s = getDB()->prepare("SELECT * FROM users WHERE id=? AND is_admin=1 LIMIT 1");
    $s->execute([$_SESSION['admin_id']]);
    $admin = $s->fetch();
    if (!$admin) {
        session_destroy();
        header('Location: ' . SITE_URL . '/admin/login.php');
        exit;
    }
    return $admin;
}

function adminLogout(): void {
    session_destroy();
    header('Location: ' . SITE_URL . '/admin/login.php');
    exit;
}